#include "groupvars.h"
#include "mathstat.cpp"

GroupVars::GroupVars(ExternVariables *vars) :
    QThread()
{
    mutex.lock(); 

    p = vars->getFileCountVars();
    n = vars->getFileCountStepV();
    m = vars->getFileCountView();
    nn = n * m;

    in_data = _create(p, nn);
    in_data = vars->getData();

    mode = vars->getModeChanged();

    if (mode == 0)
        count = 3;
    if (mode == 2)
    {
        count = 1;
        regression.clear();
        regression = vars->getRegression();
    }


    mutex.unlock();
}

GroupVars::~GroupVars()
{
    mutex.lock();    
    p = __null;  n = __null;  m = __null;  nn = __null; count = __null;
    data.clear();corr_data.clear();in_data.clear();gr_data.clear();regression.clear();
    cond.wakeAll();
    mutex.unlock();
    wait();
}

void GroupVars::run()
{
    if (mode == 0)
    {
        corr_data = _correlation(in_data);

        gr_data.resize(count);
        for (int i = 0; i < count; i++) gr_data[i].resize(p);

        for (int i = 0; i < p; i++)
            for (int j = i + 1; j < p; j++)
            {
                mutex.lock();
                bool sign = _Corr_Signification(corr_data[i][j], nn);
                float corr = fabs(corr_data[i][j]);
                mutex.unlock();

                if ((sign) && (corr > 0.75))
                {
                    gr_data[0][j] = j + 1;
                    gr_data[0][i] = i + 1;
                }
                if ((sign) && (corr > 0.5))
                {
                    gr_data[1][j] = j + 1;
                    gr_data[1][i] = i + 1;
                }
                sign = __null; corr = __null;
                gr_data[2][j] = j + 1;
                gr_data[2][i] = i + 1;
            }

        data.resize(count);

        for (int i = 0; i < count; i++)
            for (int j = 0; j < p; j++)
            {
                if (gr_data[i][j] > 0)
                    data[i].push_back(gr_data[i][j] - 1);
            }
    }

    if (mode == 2)
    {
        data.resize(count);

        for (int j = 0; j < regression.count(); j++)
            //data[0].push_back(regression[j]->response);
            data[0].push_back(j);
    }




    emit getData(data);
    emit terminate();
    exec();
}
