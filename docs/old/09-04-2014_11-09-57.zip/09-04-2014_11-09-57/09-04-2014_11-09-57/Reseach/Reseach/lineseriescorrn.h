#ifndef LINESERIESCORRN_H
#define LINESERIESCORRN_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"
#include "linesvariables.h"

class LineSeriesCorrN : public QThread
{
    Q_OBJECT

    int p, n, m, nn, iterCount, beginView, modeChanged;
    vecFF data;
    vecII groups;
    vecF sigma;
    QString nameWorkDirF, currenTime;
    float alyfa;
    qreal intensity;

    ExternVariables *Vars;
    vecLines *LinesW, *Lines;

    vecRegression regression;

    QMutex mutex;

    volatile bool flag, forDelta;

    QWaitCondition cond;

    void run();
    void calcLines(const QString &str_in, const vecFF &in_data, const int &iter, const int &mode, const int &modeW);
    void calcLinesR(const QString &str_in, const vecFF &in_data, const int &iter, const int &mode, const int &modeW);
    void saveLines(const QString &str_in, vecLines *LinesHW, const int &iter, const int &mode);

public:

    explicit LineSeriesCorrN(ExternVariables *Vars_);
    ~LineSeriesCorrN();

signals:

    void processChanged(int iter);
    void processSetTextBt(const QString &str);
    void processRanged(int minn, int maxx);
    void finishedThread(const QString &str);

    void getLinesW(const vecLines *lines);
    void getLines(const vecLines *lines);
    void getResLinesW(const vecLines *lines);
    void getResLines(const vecLines *lines);

public slots:

    void setFlag(){QMutexLocker locker(&mutex); flag = true;}

};

#endif // LINESERIESCORRN_H
