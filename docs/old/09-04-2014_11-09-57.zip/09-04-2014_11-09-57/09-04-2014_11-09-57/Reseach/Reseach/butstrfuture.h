#ifndef BUTSTRFUTURE_H
#define BUTSTRFUTURE_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"


class ButstrTread : public QThread
{
    Q_OBJECT

    QString nameWorkDirF, currenTime;
    vecFF data;
    int p, n, m, nn, iterCount;

    QMutex mutex;

    volatile bool flag;

    QWaitCondition cond;

    void run();

public:

    explicit ButstrTread(ExternVariables *vars);
    ~ButstrTread();

signals:

    void processChanged(int iter);
    void processSetTextBt(const QString &str);
    void processRanged(int minn, int maxx);
    void finishedThread(const QString &str);

public slots:

    void setFlag(){QMutexLocker locker(&mutex); flag = true;}

};

#endif // BUTSTRFUTURE_H
