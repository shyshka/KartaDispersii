#include "mainwin.h"
#include "mathstat.h"
#include "servisUnit.h"
#include "mathstat.cpp"
#include "externvariables.h"


#include<QModelIndex>



#define tr QObject::tr

MainWin *My;

void MainWin::calc_begin()
{
    _delete(tvn);
    tvn = new QTableView(tabN[0]);

    tvn->setModel(model);

    _delete(MOSKO); MOSKO = new TableModel(this, "MO SKO");

    _delete(NORMIR); NORMIR = new TableModel(this, "Normirovka");

    _delete(CORR); CORR = new TableModel(this, "Correlations");

    _delete(COVV); COVV = new TableModel(this, "Covariations");

    _delete(CHANGE); CHANGE = new TableModel(this, "Cholesky");

    _delete(INVERSE); INVERSE = new TableModel(this, "Inverse");

//*************************����������*******************************************
    vecFF loadData = model->toArray();

    int nnn = loadData[0].count();

    vecFF tempN = _normirovka(loadData);

    vecFF temp = _mean_sigma(loadData);

    vecFF corrm = _correlation(loadData);

    vecFF covvm = _covariation(loadData);
    //vecFF covvm = _createNorm(loadData.count(), loadData.at(0).count());

    vecFF changed = _cholesky(loadData);

    vecFF inv = _inverse(covvm);
    loadData.clear();

    MOSKO->toModel(temp, 1, nnn);
    NORMIR->toModel(tempN, 1, nnn);
    CORR->toModel(corrm, 1, nnn);
    COVV->toModel(covvm, 1, nnn);
    CHANGE->toModel(changed, 1, nnn);
    INVERSE->toModel(inv, 1, nnn);

    tempN.clear();    temp.clear();    corrm.clear();    covvm.clear();    changed.clear();    inv.clear();
    nnn = __null;

//*************************����������*******************************************

    _delete(tvMOSKO); tvMOSKO = new QTableView(tabN[0]); tvMOSKO->setModel(MOSKO);

    _delete(tvNORMIR); tvNORMIR = new QTableView(tabN[1]); tvNORMIR->setModel(NORMIR);

    _delete(tvCORR); tvCORR = new QTableView(tabN[2]); tvCORR->setModel(CORR);

    _delete(tvCOVV); tvCOVV = new QTableView(tabN[3]); tvCOVV->setModel(COVV);

    _delete(tvCHANGE); tvCHANGE = new QTableView(tabN[4]); tvCHANGE->setModel(CHANGE);

    _delete(tvINVERSE); tvINVERSE = new QTableView(tabN[5]); tvINVERSE->setModel(INVERSE);

    _delete(d); d = new MyDelegate;
    tvn->setItemDelegate(d); tvMOSKO->setItemDelegate(d); tvNORMIR->setItemDelegate(d);
    tvCORR->setItemDelegate(d); tvCOVV->setItemDelegate(d); tvCHANGE->setItemDelegate(d); tvINVERSE->setItemDelegate(d);

    _delete(sp); sp = new QSplitter(Qt::Vertical,tabN[0]);
    sp->addWidget(tvn);
    sp->addWidget(tvMOSKO);
    tvMOSKO->setFixedHeight(85);
    sp->setStretchFactor(0, 15);
    sp->setStretchFactor(1, 3);

    _delete(layout); layout = new QVBoxLayout(tabN[0]);
    layout->addWidget(sp);
    tabN[0]->setLayout(layout);

    _delete(layout1); layout1 = new QVBoxLayout(tabN[1]);
    layout1->addWidget(tvNORMIR);
    tabN[1]->setLayout(layout1);

    _delete(layout2); layout2 = new QVBoxLayout(tabN[2]);
    layout2->addWidget(tvCORR);
    tabN[2]->setLayout(layout2);

    _delete(layout3); layout3 = new QVBoxLayout(tabN[3]);
    layout3->addWidget(tvCOVV);
    tabN[3]->setLayout(layout3);

    _delete(layout4); layout4 = new QVBoxLayout(tabN[4]);
    layout4->addWidget(tvCHANGE);
    tabN[4]->setLayout(layout4);

    _delete(layout5); layout5 = new QVBoxLayout(tabN[5]);
    layout5->addWidget(tvINVERSE);
    tabN[5]->setLayout(layout5);
}

void MainWin::clearAll()
{//
}

MainWin::MainWin() : QMainWindow()
{
    m_settings = new QSettings(tr("z1.ini"), QSettings::IniFormat, this);
    readSettings();


    lwremainsRegre = __null; tvRemains = __null; btnClearRegre = __null;


    root = __null; countCorr = __null; rootCl = __null; countCl = __null;
    //rootModCorr = __null;

    countWinHot = __null; dialog = __null;
    spbFactors = __null;

    lbLambda = __null; listLinesVar = __null; lbLambdaCl = __null; listLinesVarCl = __null;

    mainWidget = __null;
    listStage = __null; listState = __null;

    free_factorList = __null; factorsList = __null;

    model = __null; tvn = __null;  NORMIR = __null;  CORR = __null;  COVV = __null;  CHANGE = __null;  INVERSE = __null;
    linesModelB = __null; linesModelBW = __null; linesModelN = __null; linesModelNW = __null;
    linesModel = __null; linesModelW = __null;
    linesModelCLB = __null; linesModelCLBW = __null; linesModelCLN = __null; linesModelCLNW = __null;
    loadModelH = __null; loadModelW = __null;
    loadSecondData = __null;
    listModelCorr = __null; listModelCl = __null;
    treeListChangedModel = __null;

    listCorrLambda = __null;
    modelCorrModel = __null;

    linesCorrResult = __null; linesCorrResultW = __null;
    treeResultCorr = __null; treeResultWCorr = __null;

    linesClResult = __null; linesClResultW = __null;
    treeResultCl = __null; treeResultWCl = __null;


    mmodel = __null; treeview = __null; tableview = __null; treeProxyModel = __null; tableProxyModel = __null; split = __null; layCorr = __null;
    mmodelCl = __null; treeviewCl = __null; tableviewCl = __null; treeProxyModelCl = __null; tableProxyModelCl = __null; splitCl = __null; layCl = __null;
    treeModProxyModel = __null; tableModProxyModel = __null;

    nextStackP = __null;

    MOSKO = __null; tvMOSKO = __null; tvNORMIR = __null; tvCORR = __null; tvCOVV = __null; tvCHANGE = __null; tvINVERSE = __null;

    d = __null;
    sp = __null; sp_list = __null; sp_main = __null;
    layout = __null;
    layout1 = __null; layout2 = __null; layout3 = __null; layout4 = __null; layout5 = __null; lay1WT = __null; lay2WT = __null;
    mainlay = __null;  lay0L = __null;  lay = __null;  lay00R = __null;  lay0R = __null;
    stackmy = __null;  stack0 = __null; tabs = __null; tabsGeneration = __null; tabsLines = __null; tabsCor = __null; CorrTabs = __null; CorrTabModelling = __null;
    ClTabModelling = __null; tabsCl = __null; ClasterTabs = __null;
    //�������
    graphL = __null; LinesLayGr = __null; corrGraph = __null; LinesLayGrCorr = __null; clGraph = __null;
    checkGraphs = __null; checkGraphsCl = __null;

    inList = __null; groupList = __null;
    ChangeGrB = __null; HotGrB = __null;
    tabsGraph = __null; tabsHot = __null;graphD = __null;
    graph = __null; t2 = new QCheckBox; t2w = new QCheckBox;

    inMList = __null; groupMList = __null;
    graphM = __null; sceneM = __null; viewM = __null;
    ChangeWEMGrB = __null; MEWGrB = __null;
    tabsMew = __null; me2 = new QCheckBox; me2w = new QCheckBox;
    //--------

    vvv1 = __null; vvv2 = __null; vvv3 = __null; vvv4 = __null;
    vvv5 = __null; vvv6 = __null; vvv7 = __null; vvv8 = __null;
    treeCorr = __null; treeCorrW = __null;

    mymain = __null;

    m_tubw = __null;    m_tubw0 = __null;

    butstrrun = __null; normrun = __null;
    normPrB = __null; normDirBt = __null; butstrPrB = __null; butstrDirBt = __null;

    //������ �����-����������
    butsLinesRun = __null; normLinesRun = __null;
    linesCorrBPrB = __null;linesCorrNPrB = __null;
    normDirLine = __null; butstrDirLine = __null;
    treeCorrModel = __null; tableModelling = __null;
    workDirectory = __null;Vars = __null;grCorr = __null;
    listLambda = __null;
    clockTimer = __null;timeLabel = __null;
    modelBtRun = __null;

    modelSimplePrB = __null; modelNSimplePrB = __null;
    //������ ���������
    butsCLThread = __null;
    butsLinesRunCL = __null;normLinesRunCL = __null;
    linesCLBPrB = __null;linesCLNPrB = __null;
    grCl = __null;spbCl = __null;createDendro = __null;clastersForDendro = __null; lbLambdaCl = __null;
    spbLambdaCl = __null; listLinesVarCl = __null; layCl = __null;
    listLambdaCl = __null;
    listClLambda = __null;

    modelClModel = __null; treeModProxyModelCl = __null; treeClModel = __null;
    modelSimplePrBCl = __null; modelBtRunCl = __null;
    rootModCl = __null;
    layClModel = __null;

    meanLambdaCorr = __null; meanLambdaCl = __null;

    createActions();
    createMenus();
    createToolBars();

    createStatusBar();
    setWindowTitle(tr("������������"));
    setWindowIcon(qApp->style()->standardIcon(QStyle::SP_ComputerIcon));
}

void MainWin::about()
{
    QMessageBox::about(this, tr("About"), tr("<font size=\"+1\" color=\"#000000\"> <b>������ ���������� �� ������� ��� �����. 2011 ���.</b><br>"
                                             "<b>������� ������������: �.�.�., ��������� ������� �. �.</b><br>"
                                             "<b>�����������         : �������� ������� ��� ������ �. �.</b><font>"));
}

void MainWin::createActions()
{
    openAct = new QAction(qApp->style()->standardIcon(QStyle::SP_FileDialogNewFolder), tr("&������� ����"), this);
    openAct->setShortcut(tr("Ctrl+O"));
    openAct->setStatusTip(tr("������� ����"));
    connect(openAct, SIGNAL(triggered()), this, SLOT(openFile()));

    saveAct = new QAction(qApp->style()->standardIcon(QStyle::SP_DriveDVDIcon), tr("&��������� � ����"), this);
    saveAct->setShortcut(tr("Ctrl+S"));
    saveAct->setStatusTip(tr("��������� � ����"));
    connect(saveAct, SIGNAL(triggered()), this, SLOT(saveFile()));

    quitAct = new QAction(qApp->style()->standardIcon(QStyle::SP_DialogCancelButton), tr("&�����"), this);
    quitAct->setShortcut(tr("CTRL+Q"));
    quitAct->setStatusTip(tr("���������� ������"));
    connect(quitAct, SIGNAL(triggered()), this, SLOT(close()));

    helpAct = new QAction(qApp->style()->standardIcon(QStyle::SP_DialogHelpButton), tr("&� ���������"), this);
    helpAct->setShortcut(tr("F1"));
    helpAct->setStatusTip(tr("� ���������"));
    connect(helpAct, SIGNAL(triggered()), this, SLOT(about()));

    aboutQtAct = new QAction(qApp->style()->standardIcon(QStyle::SP_TitleBarMenuButton), tr("&� ��������� Qt"), this);
    aboutQtAct->setShortcut(tr("CTRL+F1"));
    aboutQtAct->setStatusTip(tr("� ��������� Qt"));
    connect(aboutQtAct, SIGNAL(triggered()), qApp, SLOT(aboutQt()));

    createHotAct = new QAction(qApp->style()->standardIcon(QStyle::SP_TitleBarMenuButton), tr("&����� ����������"), this);
    createHotAct->setShortcut(tr("CTRL+H"));
    createHotAct->setStatusTip(tr("����� ����������"));
    connect(createHotAct, SIGNAL(triggered()), this, SLOT(drawHotelling()));

}

void MainWin::createWin()
{

}

void MainWin::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&����"));
    fileMenu->addAction(openAct);
    fileMenu->addSeparator();
    fileMenu->addAction(saveAct);
    fileMenu->addSeparator();
    fileMenu->addAction(quitAct);

    /*chartsMenu = menuBar()->addMenu(tr("&����������� �����"));
    chartsMenu->addAction(createHotAct);
    chartsMenu->addSeparator();*/
    //viewMenu->addAction(aboutQtAct);

    viewMenu = menuBar()->addMenu(tr("&�������"));
    viewMenu->addAction(helpAct);
    viewMenu->addSeparator();
    viewMenu->addAction(aboutQtAct);
}

void MainWin::createToolBars()
{
    m_tb = addToolBar(tr("General"));

    m_tb->setAllowedAreas(Qt::LeftToolBarArea | Qt::TopToolBarArea );

    m_tb->addAction(openAct);
    m_tb->addSeparator();
    m_tb->addAction(saveAct);
    m_tb->addSeparator();
    m_tb->addAction(quitAct);
}

QString MainWin::getCurrentTime()
{
    QMutexLocker locker(&mutex);
    QTime time = QTime::currentTime();
    return time.toString("hh:mm:ss:zzzz");
}

void MainWin::showTime()
{
    QTime time = QTime::currentTime();
    QString text = time.toString("hh:mm:ss:zzz");
    QMutexLocker locker(&mutex);
    timeLabel->setText(text);
    text = "";
}

void MainWin::createStatusBar()
{
    statusBar()->showMessage(tr("�������� :   ' ") + QCoreApplication::applicationFilePath() + tr(" '"));
    timeLabel = new QLabel(statusBar());

    clockTimer = new QTimer(this);
    QObject::connect(clockTimer, SIGNAL(timeout()), this, SLOT(showTime()));
    clockTimer->start();

    statusBar()->addPermanentWidget(timeLabel);
}

void MainWin::createTableView()
{}

void MainWin::createStack()
{
    mainWidget = new QWidget(this);
    setCentralWidget(mainWidget);

    //�������� ��������� � ������� ���� - �������� (����� �����������)
    stack0 = new QStackedWidget;
    stack0->addWidget(tabs = new QWidget);
    stack0->addWidget(tabsGeneration = new QWidget);
    stack0->addWidget(tabsLines = new QWidget);
    stack0->addWidget(tabsCor = new QWidget);
    stack0->addWidget(CorrTabs = new QWidget);
    stack0->addWidget(CorrTabModelling = new QWidget);
    stack0->addWidget(tabsCl = new QWidget);
    stack0->addWidget(ClasterTabs = new QWidget);
    stack0->addWidget(ClTabModelling = new QWidget);
    stack0->addWidget(tabsGraph = new QWidget);
    stack0->addWidget(tabsHot = new QWidget);
    stack0->addWidget(tabsMew = new QWidget);



    _delete(listStage); listStage = new QListWidget;
    listStage->setFont(QFont("Arial", 10, QFont::Bold));
    listStage->setFixedWidth(150);
    //listStage->setD
    new QListWidgetItem(tr("��������"), listStage);
    new QListWidgetItem(tr("���������"), listStage);
    new QListWidgetItem(tr("�����"), listStage);
    new QListWidgetItem(tr(" ����������"), listStage);
    new QListWidgetItem(tr(" ���������� ������."), listStage);
    new QListWidgetItem(tr(" ������ ������."), listStage);
    new QListWidgetItem(tr(" �������������"), listStage);
    new QListWidgetItem(tr(" ���������� �������."), listStage);
    new QListWidgetItem(tr(" ������ ���������"), listStage);
    new QListWidgetItem(tr("����������� �����"), listStage);
    new QListWidgetItem(tr(" HOTELLING"), listStage);
    new QListWidgetItem(tr(" MEWMA"), listStage);

    QObject::connect(listStage, SIGNAL(currentRowChanged(int)), stack0, SLOT(setCurrentIndex(int)));    

    _delete(sp_list); sp_list = new QSplitter(Qt::Vertical);
    _delete(listState);
    listState = new QListWidget;listState->setFont(QFont("Arial", 10, QFont::Black));

    sp_list->addWidget(stack0);
    sp_list->addWidget(listState);
    sp_list->setStretchFactor(0, 15);
    sp_list->setStretchFactor(1, 1);

    _delete(sp_main); sp_main = new QSplitter(Qt::Horizontal);
    sp_main->addWidget(listStage);
    sp_main->addWidget(sp_list);
    sp_main->setStretchFactor(0, 5);
    sp_main->setStretchFactor(1, 10);

    //�������� �������������� ���� ��� �������� ������ ���� ����������� ������ �
    //��� ������� ���� - ������� ��������� ���� - ������� (��������� ���� - ��������)
    _delete(lay); lay = new QHBoxLayout;
    lay->addWidget(sp_main);

    mainWidget->setLayout(lay);
}

void MainWin::createBegin()
{
  //*********������ ���������********************************************

  //�������� Tab ������
    _delete(m_tubw); m_tubw = new QTabWidget(tabs);

  //�������� ������ ��� �������� ������� ���-�������. ����������!!!!!!!!!!!
    tabN.resize(6);
    for (int i = 0; i < tabN.count(); i++)
        tabN[i] =  new QWidget(m_tubw);

    m_tubw->addTab(tabN[0], tr("������"));
    m_tubw->addTab(tabN[1], tr("������������"));
    m_tubw->addTab(tabN[2], tr("����������"));
    m_tubw->addTab(tabN[3], tr("����������"));
    m_tubw->addTab(tabN[4], tr("������� ��������������"));
    m_tubw->addTab(tabN[5], tr("�������� �������"));

  //�������� �������������� ���� ��� �������� ��� - �������
    _delete(lay1WT); lay1WT = new QHBoxLayout(tabs);
    lay1WT->addWidget(m_tubw);
    tabs->setLayout(lay1WT);
}

void MainWin::createGeneration()
{
    //*********������ ���������*************************************************
    //-----������ ��� �������� - �������----------------------------------------

    //QGroupBox *butstrGrB = new QGroupBox(tr("<font size=\"+1\" color=\#000000\">��������� �������� - �������</font>"), tabsGeneration);
    QGroupBox *butstrGrB = new QGroupBox(tr("��������� �������� - �������"), tabsGeneration);

    QGridLayout *butstrlay = new QGridLayout(butstrGrB);

    QLabel *butstrDirLab = new QLabel(tr("�������: "));
    //tstrDirLab->setW
    butstrDirLab->setFont(QFont("Arial", 10, QFont::Bold));

    _delete(butstrDirLine); butstrDirLine = new QLineEdit(tr("������"));
    QObject::connect(butstrDirLine, SIGNAL(textChanged(QString)), Vars, SLOT(setDirForButs(QString)));

    QLabel *butstrCountLab = new QLabel(tr("���������� ������: "));
    butstrCountLab->setFont(QFont("Arial", 10, QFont::Bold));

    QSpinBox *butstrCountSp = new QSpinBox;
    butstrCountSp->setMaximum(Vars->getFileCountButStr() * 1000);
    butstrCountSp->setValue(Vars->getFileCountButStr());
    QObject::connect(butstrCountSp, SIGNAL(valueChanged(int)), Vars, SLOT(setFileCountButs(int)));

    _delete(butstrDirBt); butstrDirBt = new QPushButton(tr("�����"));
    QObject::connect(butstrDirBt, SIGNAL(clicked()), this, SLOT(setDirForButs()));

    _delete(butstrrun); butstrrun = new QPushButton(tr("Create"));
    QObject::connect(butstrrun, SIGNAL(clicked()), this, SLOT(createButsThread()));

    //QLabel *chbb = new QLabel;
    QPushButton *loadFile = new QPushButton(tr("Load"));
    loadFile->setText(tr("��������� ����"));
    loadFile->setStatusTip(tr("��������� ���� ������������ ������� � �������� ������� ����������."));
    loadFile->setToolTip(tr("��������� ���� ������������ ������� � �������� ������� ����������"));
    QObject::connect(loadFile, SIGNAL(clicked()), this, SLOT(openFileFor()));

    _delete(butstrPrB); butstrPrB = new QProgressBar;

    QHBoxLayout *butstrDirlay = new QHBoxLayout;
    butstrDirlay->addWidget(butstrDirLab, 0, Qt::AlignRight | Qt::AlignVCenter);
    butstrDirlay->addWidget(butstrDirLine, 10, Qt::AlignVCenter);
    butstrDirlay->addWidget(butstrDirBt, 1, Qt::AlignCenter);

    QHBoxLayout *butstrCountlay = new QHBoxLayout;
    butstrCountlay->addWidget(butstrCountLab, 0, Qt::AlignRight | Qt::AlignVCenter);
    butstrCountlay->addWidget(butstrCountSp, 10, Qt::AlignVCenter);
    butstrCountlay->addWidget(butstrrun, 1, Qt::AlignCenter);

    QHBoxLayout *butstrchbb = new QHBoxLayout;
    //butstrchbb->addWidget(loadFile, 10, Qt::AlignCenter);

    QHBoxLayout *butstrPrlay = new QHBoxLayout;
    //butstrPrlay->addStretch(2);
    butstrPrlay->addWidget(butstrPrB, 10, Qt::AlignBottom);

    butstrlay->addLayout(butstrDirlay, 0, 0, 1, 5);
    butstrlay->addLayout(butstrCountlay, 1, 0, 1, 5);
    butstrlay->addLayout(butstrchbb, 2, 0, 1, 5);
    butstrlay->addLayout(butstrPrlay, 3, 0, 1, 5);

    butstrGrB->setLayout(butstrlay);

    //-----������ ��� ����������...- �������-------------------------------------

    QGroupBox *normGrB = new QGroupBox(tr("��������� ������� ������������ ����������� �������������"), tabsGeneration);

    QGridLayout *normlay = new QGridLayout(normGrB);

    QLabel *normDirLab = new QLabel(tr("�������: "));
    normDirLab->setFont(QFont("Arial", 10, QFont::Bold));

    _delete(normDirLine); normDirLine = new QLineEdit(tr("�������"));
    QObject::connect(normDirLine, SIGNAL(textChanged(QString)), Vars, SLOT(setDirForNorm(QString)));

    QLabel *normCountLab = new QLabel(tr("���������� ������: "));
    normCountLab->setFont(QFont("Arial", 10, QFont::Bold));

    QSpinBox *normCountSp = new QSpinBox;
    normCountSp->setMaximum(Vars->getFileCountNorm() * 1000);
    normCountSp->setValue(Vars->getFileCountNorm());
    QObject::connect(normCountSp, SIGNAL(valueChanged(int)), Vars, SLOT(setFileCountNorm(int)));

    _delete(normDirBt); normDirBt = new QPushButton(tr("�����"));
    QObject::connect(normDirBt, SIGNAL(clicked()), this, SLOT(setDirForNorm()));

    _delete(normrun); normrun = new QPushButton(tr("Create"));
    QObject::connect(normrun, SIGNAL(clicked()), this, SLOT(createNormThread()));

    _delete(normPrB); normPrB = new QProgressBar;

    QRadioButton *chb = new QRadioButton(tr("������ ���������� ����������: "));
    chb->setFont(QFont("Arial", 10, QFont::Bold));
    chb->setChecked(false);
    QSpinBox * spb = new QSpinBox;
    spb->setEnabled(false);
    spb->setMaximum(100);
    spb->setSingleStep(1);
    spb->setValue(25);
    spb->setSuffix("%");
    QObject::connect(chb, SIGNAL(toggled(bool)), spb, SLOT(setEnabled(bool)));
    QObject::connect(spb, SIGNAL(valueChanged(int)), Vars, SLOT(setVarCorrNorm(int)));
    QObject::connect(chb, SIGNAL(toggled(bool)), Vars, SLOT(setVarChNorm(bool)));

    QRadioButton *covvchb = new QRadioButton(tr("��������� ���������� �������������� ������. "));
    covvchb->setFont(QFont("Arial", 10, QFont::Bold));
    covvchb->setChecked(false);
    QObject::connect(covvchb, SIGNAL(toggled(bool)), Vars, SLOT(setVarCovvNorm(bool)));

    QHBoxLayout *normDirlay = new QHBoxLayout;
    normDirlay->addWidget(normDirLab, 0, Qt::AlignRight | Qt::AlignVCenter);
    normDirlay->addWidget(normDirLine, 10, Qt::AlignVCenter);
    normDirlay->addWidget(normDirBt, 1, Qt::AlignCenter);

    QHBoxLayout *normCountlay = new QHBoxLayout;
    normCountlay->addWidget(normCountLab, 0, Qt::AlignRight | Qt::AlignVCenter);
    normCountlay->addWidget(normCountSp, 10, Qt::AlignVCenter);
    normCountlay->addWidget(normrun, 1, Qt::AlignCenter);

    QHBoxLayout *normVarCorr = new QHBoxLayout;
    normVarCorr->addWidget(chb, 1, Qt::AlignRight | Qt::AlignVCenter);
    normVarCorr->addWidget(spb, 10, Qt::AlignVCenter);

    QHBoxLayout *normVarCovv = new QHBoxLayout;
    normVarCovv->addWidget(covvchb, 1, Qt::AlignLeft | Qt::AlignVCenter);

    QHBoxLayout *normPrlay = new QHBoxLayout;
    normPrlay->addWidget(normPrB, 10, Qt::AlignBottom);

    normlay->addLayout(normDirlay, 0, 0, 1, 5);
    normlay->addLayout(normCountlay, 1, 0, 1, 5);
    //normlay->addLayout(normVarCorr, 2, 0, 1, 5);
    //normlay->addLayout(normVarCovv, 3, 0, 1, 5);
    normlay->addLayout(normPrlay, 3, 0, 1, 5);

    normGrB->setLayout(normlay);

    //-----������ - QSplitter ��� ����������� �������� �������------------------
    QSplitter *sp_generation = new QSplitter(Qt::Horizontal, tabsGeneration);
    sp_generation->addWidget(butstrGrB);
    sp_generation->addWidget(normGrB);

    _delete(lay2WT); lay2WT = new QHBoxLayout(tabsGeneration);
    lay2WT->addWidget(sp_generation);

    tabsGeneration->setLayout(lay2WT);
}

bool MainWin::openFileFor()
{
    QString fileName = QFileDialog::getOpenFileName(
                            this,
                            tr("����� �����"),
                            QString(),
                            tr("��������� (*.txt);;��� ����� (*.*)")
                        );
    if (!fileName.isEmpty())
    {
        _delete(loadSecondData);
        loadSecondData = new TableModel(this, "Load");
        loadSecondData->loadData(fileName);

        vecFF temp1 = model->toArray(), temp2 = loadSecondData->toArray();
        //hotMon = true;
        //bool hhhhh = _compareCovvDiff(temp1, temp2);
        return true;
    }
    else
        return false;
}


void MainWin::createLinesSeries()
{
    //*********������ ���������*************************************************
    //-----������ ��� "������� ����� �����"----------------------------------------
/*
    QLabel *lblIntro = new QLabel(tr("� ������ ������ �� ������ �������������� �������� - ������� � ������� ������������ ����������� ������������� �������� :"));
    lblIntro->setFont(QFont("Arial", 10, QFont::Bold));

    QLabel *lblIntro1 = new QLabel(tr(" 1. � ������ ��������������� ������� : "));
    lblIntro1->setFont(QFont("Arial", 10, QFont::Bold));

    QHBoxLayout *lineIntroCorr = new QHBoxLayout;
    lineIntroCorr->addWidget(lblIntro1, 10, Qt::AlignRight | Qt::AlignTop);

    QVBoxLayout *lineIntroLay = new QVBoxLayout;
    lineIntroLay->addWidget(lblIntro, 10, Qt::AlignCenter);
    lineIntroLay->addLayout(lineIntroCorr);

    QGridLayout *linelay = new QGridLayout(tabsLines);
    linelay->addLayout(lineIntroLay, 0, 0, 1, 5);

    tabsLines->setLayout(linelay);*/
    //QGroupBox *gblinesChanged = new QGroupBox(tr("����� ����������:"), tabsLines);
    //QGroupBox *gblinesGraph = new QGroupBox(tr("������� ����� ����� (������������� ������):"), tabsLines);

    graphL = new Curve();

    LinesLayGr = new QHBoxLayout;
    LinesLayGr->addWidget(graphL);

    //gblinesGraph->setLayout(LinesLayGr);

    //QHBoxLayout *hblinesCalc = new QHBoxLayout;
    //hblinesCalc->addWidget(gblinesChanged, 3);
    //hblinesCalc->addWidget(gblinesGraph,8);

    //tabsLines->setLayout(hblinesCalc);
    tabsLines->setLayout(LinesLayGr);

    //emit drawLinesCalc();
}

void MainWin::drawLinesCalc()
{
    _delete(graphL);
    graphL = new Curve();

    graphL->setVarsName(tr("������� ����� ����� (������������� ������)"));
    graphL->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));

    vecR ggg;
    for (int i = 1; i <= 20; i++)
    {
        float t2h = _GetHOTTELING_Kr_High(Vars->getFileCountVars());
        float res = _simpson(0, t2h, float(i*0.1), Vars->getFileCountVars(), Vars->getFileCountStepV());
        ggg << QPointF(float(i*0.1), 1 / (1 - res));
        res = __null; t2h = __null;
    }

    graphL->setCurveData(0, ggg);

    _delete(LinesLayGr);
    LinesLayGr = new QHBoxLayout;

    LinesLayGr->addWidget(graphL);

    tabsLines->setLayout(LinesLayGr);


    graphL->hasFocus();
    graphL->show();
}

void MainWin::setLbLambda(const int &count)
{
    vecI changeList = _genRandomInt(0, Vars->getFileCountVars() - 1, count);

    vecF listChange(Vars->getFileCountVars());

    for (int i = 0; i < listChange.count(); i++)
        for (int j = 0; j < changeList.count(); j++)
            if (changeList[j] == i) listChange[i] = 1.0;

    Vars->setListVar(listChange);
    listChange.clear();changeList.clear();
    resetLbLambda();
}

void MainWin::setListBLambda(const QModelIndex &index)
{
    vecF listChange = Vars->getListVar();    

    listChange[index.row()] = listModelCorr->data(listModelCorr->index(index.row(), 1, index), Qt::EditRole).toFloat();

    Vars->setListVar(listChange);

    resetLbLambda();
    lbLambda->setFocus();
}

void MainWin::setLambdaCbCorr(const bool &in)
{
    Vars->setForDelta(in);
    if (in)
    {
        vecFF in_data = Vars->getData();
        vecF result(vecGr.count());
        vecLamda fff = _getGroupsRegreNonCentral(vecGr, in_data, Vars->getFileCountStepV());

        for (int i = 0; i < vecGr.count(); i++)
            result[i] = fff[i].Lamda;

        in_data.clear(); fff.clear();
        lbLambda->setText(tr(" l = %1").arg(result[result.count() - 1]));
        Vars->setLambdaCorr(result);
        result.clear();
    }
}


void MainWin::resetLbLambda()
{
    vecFF in_data = Vars->getData();
    vecF SKO = _sko(in_data), listChange = Vars->getListVar(), result(vecGr.count());

    for (int i = 0; i < Vars->getFileCountVars(); i++)
    {
        listModelCorr->setData(listModelCorr->index(i, 0, QModelIndex()), tr("X%1").arg(i + 1), Qt::EditRole);
        listModelCorr->setData(listModelCorr->index(i, 1, QModelIndex()), tr("%1").arg(listChange[i]), Qt::EditRole);

    }

    listLinesVar->reset();
    listLinesVar->setModel(listModelCorr);

    for (int i = 0; i < vecGr.count(); i++)
    {
        vecFF temp_data = _CopyNeedColsFromArray2D(in_data, vecGr[i]);
        vecF temp_sko = _CopyNeedColsFromArray1D(SKO, vecGr[i]), temp_list = _CopyNeedColsFromArray1D(listChange, vecGr[i]);
        vecFF corr = _correlation(temp_data);
        vecF delta = _getDeltaForLambda(temp_list, corr, temp_sko);
        result[i] = _getNonCentralVar(temp_data, delta, Vars->getFileCountStepV());
        corr.clear();temp_data.clear();temp_sko.clear();temp_list.clear();delta.clear();
    }
    SKO.clear();in_data.clear();listChange.clear();
    lbLambda->setText(tr(" l = %1").arg(result[result.count() - 1]));
    Vars->setLambdaCorr(result);    
    result.clear();
}
/*
vecR MainWin::_getListSimpleNoncentral(const vecFF &in_data, const int& vib) const
{
    int pp = in_data.count();
    vecF SKO = _sko(in_data);
    vecR result(pp);
    for (int i = 0; i < pp; i++)
    {
        vecF tempLambda = _createF(pp);
        tempLambda[i] = SKO[i];
        float lll = _getNonCentralVar(in_data, tempLambda, vib);
        result[i] = QPointF((qreal)i, (qreal)lll);
        tempLambda.clear();
        lll = __null;
    }
    SKO.clear();
    float tempX = 0.0, tempY = 0.0;

    for (int ii = 0; ii < pp; ii++)
       for (int jj = ii; jj < pp; jj++)
            if (result[jj].y() < result[ii].y())
            {
                tempX = result[ii].x(); tempY = result[ii].y();
                result[ii].setX(result[jj].x());
                result[ii].setY(result[jj].y());
                result[jj].setX(tempX);
                result[jj].setY(tempY);
            }
    tempX = __null; tempY = __null;
    pp = __null;
    return result;
}*/

void MainWin::createLinesSerCorr(const int &countGroups)
{
    //*********�������� ���������*************************************************
    //vecLamda fff = _getGroupsRegreNonCentral(vecGr, Vars->getData(), Vars->getFileCountStepV());
    //int vv = _getCountVars(Vars->getFileCountVars());

    //������ ��� ��������������� �������
    _delete(linesModelB); linesModelB = new LinesSeriesModel(this, "Lines");    
    _delete(linesModelBW); linesModelBW = new LinesSeriesModel(this, "Lines");
    _delete(linesModelN); linesModelN = new LinesSeriesModel(this, "Lines");    
    _delete(linesModelNW); linesModelNW = new LinesSeriesModel(this, "Lines");
    _delete(listModelCorr); listModelCorr = new ListChangedModel(this, "ListChanged");
    _delete(listCorrLambda); listCorrLambda = new ListChangedModel(this, "ListLambda");
    vecSS tempm = _createS(2, Vars->getFileCountVars());
    listModelCorr->toModel(tempm);
    listCorrLambda->toModel(tempm);
    tempm.clear();

    //treeListChangedModel->setFilterFixedString("1"); //������ ��� ���������

    //-----������ ��� ������ ����������----------------------------------------

    QGroupBox *lineGrB = new QGroupBox(tr("����� ����������:"), tabsCor);


    QGridLayout *linelay = new QGridLayout(lineGrB);

    QLabel *lblL = new QLabel(tr("������������� ���������: "));
    lblL->setFont(QFont("Arial", 9, QFont::Bold));

    QDoubleSpinBox *spbCh = new QDoubleSpinBox;
    QObject::connect(spbCh, SIGNAL(valueChanged(double)), Vars, SLOT(setIntensity(double)));
    spbCh->setValue(0.1);
    spbCh->setMaximum(10.);
    spbCh->setToolTip(tr("������ ������������� ��������� ���������."));
    spbCh->setStatusTip(tr("������ ������������� ��������� ���������."));


    QLabel *lbLambdaTitle = new QLabel(tr("������������� ���������: "));
    lbLambdaTitle->setFont(QFont("Arial", 9, QFont::Bold));

    _delete(lbLambda);lbLambda = new QLabel(tr(" l = "));
    lbLambda->setFont(QFont("Arial", 9, QFont::Bold));
    lbLambda->setToolTip(tr("�������� ��������� ��������������� ��� ��������� ��������� ���������� � ���������������� ����������"));
    lbLambda->setStatusTip(tr("�������� ��������� ��������������� ��� ��������� ��������� ���������� � ���������������� ����������"));

    QPushButton *btGraphLambda = new QPushButton(tr("������"));
    btGraphLambda->setToolTip(tr("������������ ������ �������� ��������� ��������������� �� ��������� ����������, ��� ������� �������� ��������������� ��������"));
    btGraphLambda->setStatusTip(tr("������ ���������� ����������, ��� ������� �������� ��������������� ��������"));


    _delete(spbLambda);spbLambda = new QSpinBox;
    spbLambda->setMaximum(Vars->getFileCountVars());
    spbLambda->setToolTip(tr("������ ���������� ����������, ��� ������� �������� ��������������� ��������"));
    spbLambda->setStatusTip(tr("������ ���������� ����������, ��� ������� �������� ��������������� ��������"));
    //QObject::connect(spbLambda, SIGNAL(valueChanged(int)), this, SLOT(setLbLambda(int)));



    QHBoxLayout *lineLambdaCorr = new QHBoxLayout;
    lineLambdaCorr->addWidget(lbLambda);
    lineLambdaCorr->addWidget(spbLambda);

    _delete(meanLambdaCorr);meanLambdaCorr = new QCheckBox;
    meanLambdaCorr->setChecked(false);
    meanLambdaCorr->setText(tr("�������������� ��������"));
    meanLambdaCorr->setToolTip(tr("���������� �������������� �������� ��������� ��������������� � ��������������� ������� ����� ����� ��� ��������� ��������� ���������� ��� ���� ��������� ��������� ��������"));
    meanLambdaCorr->setStatusTip(tr("���������� �������������� �������� ��������� ��������������� � ��������������� ������� ����� ����� ��� ��������� ��������� ���������� ��� ���� ��������� ��������� ��������"));
    connect( meanLambdaCorr, SIGNAL(toggled(bool)), this, SLOT(setLambdaCbCorr(bool)) );


    QVBoxLayout *lineSCorr = new QVBoxLayout;
    lineSCorr->addWidget(lblL, 0, Qt::AlignCenter);
    lineSCorr->addWidget(spbCh, 0, Qt::AlignCenter);

    //lineSCorr->addWidget(lbLambdaTitle, 0, Qt::AlignCenter);
    //lineSCorr->addLayout(lineLambdaCorr);
    //lineSCorr->addWidget(meanLambdaCorr, 0, Qt::AlignCenter);




    _delete(listLinesVar);listLinesVar = new QTreeView;
    listLinesVar->setSelectionMode(QAbstractItemView::SingleSelection);
    listLinesVar->setSelectionBehavior(QAbstractItemView::SelectRows);
    listLinesVar->setModel(listModelCorr);
    //connect( listLinesVar, SIGNAL(clicked(const QModelIndex &)), this, SLOT(setListBLambda(const QModelIndex &)) );
    //connect( listLinesVar, SIGNAL(doubleClicked(QModelIndex &)), this, SLOT(deleteRow(QModelIndex&)) );


    listLambdaVars = _getListSimpleNoncentral(Vars->getData(), Vars->getFileCountStepV());

    for (int i = 0; i < listLambdaVars.count(); i++)
    {
        listCorrLambda->setData(listCorrLambda->index(i, 0, QModelIndex()), tr("X%1").arg(listLambdaVars[i].x() + 1), Qt::EditRole);
        listCorrLambda->setData(listCorrLambda->index(i, 1, QModelIndex()), tr("%1").arg(listLambdaVars[i].y()), Qt::EditRole);
    }

    _delete(listLambda);listLambda = new QTreeView;
    listLambda->setSelectionMode(QAbstractItemView::SingleSelection);
    listLambda->setSelectionBehavior(QAbstractItemView::SelectRows);
    listLambda->setModel(listCorrLambda);
    //listLambda->sortByColumn(1, Qt::AscendingOrder);
    //listLambda->setSortingEnabled(true);



    //spbLambda->setValue(Vars->getFileCountVars());

    QVBoxLayout *lineListVar = new QVBoxLayout;
    lineListVar->addWidget(listLinesVar);
    //lineListVar->addWidget(listLambda);

    linelay->addLayout(lineSCorr, 0, 0, 1, 1);
    linelay->addLayout(lineListVar, 1, 0, 5, 1);

    lineGrB->setLayout(linelay);


    //-----������ ��� �������� - �������----------------------------------------

    QGroupBox *lineBGrB = new QGroupBox(tr("��� �������� - �������:"), tabsCor);
    QGridLayout *lineBlay = new QGridLayout(lineBGrB);

    _delete(vvv1); vvv1 = new QTreeView;
    /*vvv1->setModel(linesModelB);vvv1->setFont(QFont("Arial", 10, QFont::Bold));
    vvv1->resizeColumnToContents(1);vvv1->resizeColumnToContents(3);
    vvv1->header()->setDefaultAlignment(Qt::AlignCenter);*/
    _delete(vvv2); vvv2 = new QTreeView;
    /*vvv2->setModel(linesModelBW);vvv2->setFont(QFont("Arial", 10, QFont::Bold));
    vvv2->resizeColumnToContents(1);vvv2->resizeColumnToContents(3);
    vvv2->header()->setDefaultAlignment(Qt::AlignCenter);*/

    QGroupBox *lineGrB1 = new QGroupBox(tr("������ ����������� ���� � ��������������� ��������:"));
    QHBoxLayout *lineBRun1 = new QHBoxLayout;
    lineBRun1->addWidget(vvv2);
    lineGrB1->setLayout(lineBRun1);

    lineBlay->addWidget(vvv1, 0, 0, 2, 5);
    lineBlay->addWidget(lineGrB1, 2, 0, 2, 5);

    //_delete(butsLinesRun); butsLinesRun = new QPushButton(tr("Create"));
    //QObject::connect(butsLinesRun, SIGNAL(clicked()), this, SLOT(createButsCorrThread()));
    //QObject::connect(butsLinesRun, SIGNAL(clicked()), this, SLOT(createNormCorrThread()));
    QHBoxLayout *lineBRun = new QHBoxLayout;
    //lineBRun->addWidget(butsLinesRun, 1, Qt::AlignCenter);

    _delete(linesCorrBPrB); linesCorrBPrB = new QProgressBar;

    lineBlay->addLayout(lineBRun, 4, 0 , 1, 5);
    lineBlay->addWidget(linesCorrBPrB, 5, 0, 1, 5);

    lineBGrB->setLayout(lineBlay);

    //-----������ ��� ����������...- �������-------------------------------------

    QGroupBox *lineNGrB = new QGroupBox(tr("��� ������� ������������ ����������� �������������"), tabsCor);

    QGridLayout *lineNlay = new QGridLayout(lineNGrB);

    linesModelNW->setData(linesModelNW->index(1, 0, QModelIndex()), "NormW", Qt::EditRole);
    linesModelN->setData(linesModelN->index(1, 0, QModelIndex()), "NormW", Qt::EditRole);

    _delete(vvv3);
    vvv3 = new QTreeView;
    /*vvv3->setModel(linesModelN);vvv3->setFont(QFont("Arial", 10, QFont::Bold));
    vvv3->header()->setDefaultAlignment(Qt::AlignCenter);*/
    _delete(vvv4);
    vvv4 = new QTreeView; /*vvv4->setModel(linesModelNW);vvv4->setFont(QFont("Arial", 10, QFont::Bold));
    vvv4->header()->setDefaultAlignment(Qt::AlignCenter);*/

    QGroupBox *lineNGrB1 = new QGroupBox(tr("������ ����������� ���� � ��������������� ��������:"));
    QHBoxLayout *lineNRun1 = new QHBoxLayout;
    lineNRun1->addWidget(vvv4);
    lineNGrB1->setLayout(lineNRun1);

    lineNlay->addWidget(vvv3, 0, 0, 2, 5);
    lineNlay->addWidget(lineNGrB1, 2, 0, 2, 5);

    /*_delete(normLinesRun); normLinesRun = new QPushButton(tr("Create"));
    QObject::connect(normLinesRun, SIGNAL(clicked()), this, SLOT(createNormCorrThread()));
    QHBoxLayout *lineNRun = new QHBoxLayout;*/
    //lineNRun->addWidget(normLinesRun, 1, Qt::AlignCenter);

    _delete(linesCorrNPrB); linesCorrNPrB = new QProgressBar;

    //lineNlay->addLayout(lineNRun, 4, 0 , 1, 5);
    lineNlay->addWidget(linesCorrNPrB, 5, 0 , 1, 5);

    lineNGrB->setLayout(lineNlay);

    //-----������ - QSplitter ��� ����������� �������� �������------------------
    _delete(butsLinesRun); butsLinesRun = new QPushButton(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
    butsLinesRun->setFont(QFont("Arial", 10, QFont::Bold));
    QObject::connect(butsLinesRun, SIGNAL(clicked()), this, SLOT(createButsCorrThread()));

    QSplitter *sp_linesCorr = new QSplitter(Qt::Horizontal, tabsCor);

    sp_linesCorr->addWidget(lineGrB);sp_linesCorr->setStretchFactor(0, 0);
    sp_linesCorr->addWidget(lineBGrB);sp_linesCorr->setStretchFactor(1, 4);
    sp_linesCorr->addWidget(lineNGrB);sp_linesCorr->setStretchFactor(2, 4);
    //sp_linesCorr->addWidget(butsLinesRun);//sp_linesCorr->setStretchFactor(2, 4);

    QVBoxLayout *lineSeriesCorr = new QVBoxLayout;
    lineSeriesCorr->addWidget(sp_linesCorr);
    lineSeriesCorr->addWidget(butsLinesRun);

    QTabWidget *corrTabs = new QTabWidget(tabsCor);

    QWidget *corrTab = new QWidget;
    corrTab->setLayout(lineSeriesCorr);

    QWidget *corrMGKTab = new QWidget;
    createMGKCorr(corrMGKTab);

    QWidget *corrRegreTab = new QWidget;
    createRegreCorr(corrRegreTab);

    corrTabs->addTab(corrTab, tr("������� � ���������� ��������"));
    corrTabs->setFont(QFont("Arial", 9, QFont::Bold));
    corrTabs->addTab(corrMGKTab, tr("������� ����������"));
    corrTabs->addTab(corrRegreTab, tr("������������� �������"));

    corrTabs->setTabShape(QTabWidget::Triangular);

    connect( corrTabs, SIGNAL(currentChanged(int)), Vars, SLOT(setModeChanged(int)) );

    QVBoxLayout *allcorr = new QVBoxLayout;
    allcorr->addWidget(corrTabs);

    tabsCor->setLayout(allcorr);

    calc_groups();
}

void MainWin::createMGKCorr(QWidget *in_Widget)
{
    QVBoxLayout *MGKwidget = new QVBoxLayout(in_Widget);

    QCheckBox *chbMGK = new QCheckBox(in_Widget);
    chbMGK->setFont(QFont("Arial", 12, QFont::Bold));
    chbMGK->setText(tr("������� ����� �� ������ ������ ������� ��������"));

    MGKwidget->addWidget(chbMGK, Qt::AlignCenter);

    in_Widget->setLayout(MGKwidget);

    connect(chbMGK, SIGNAL(stateChanged(int)), Vars, SLOT(setModeChangedM(int)));
}

void MainWin::createDialogFWidget(QListWidgetItem *in_item)
{
    _delete(dialog);dialog = new QWidget;

    QLabel *lSpB = new QLabel(dialog); lSpB->setText(tr("�������� ������������:"));
    lSpB->setToolTip(tr("���� �������� - � �������� �������, ����� �������� ������� ����������� (���������)."));

    spbFactors = new QDoubleSpinBox(this);
    spbFactors->setValue(0.0);
    spbFactors->setToolTip(tr("���� �������� - � �������� �������, ����� �������� ������� ����������� (���������)."));
    spbFactors->setMaximum(10000000000.0);
    spbFactors->setMinimum(-10000000000.0);
    spbFactors->setDecimals(5);

    QPushButton *okButton = new QPushButton(dialog); okButton->setText(tr("�������"));
    connect(okButton, SIGNAL(clicked()), this, SLOT(acceptChanges()));
    QPushButton *canselButton = new QPushButton(dialog); canselButton->setText(tr("��������"));
    connect(canselButton, SIGNAL(clicked()), this, SLOT(deleteChangesRegre()));

    QGridLayout *gridRegression = new QGridLayout(dialog);

    gridRegression->addWidget(lSpB, 0, 0, 1, 1, Qt::AlignCenter);
    gridRegression->addWidget(spbFactors, 0, 1, 1, 1, Qt::AlignVCenter);
    gridRegression->addWidget(okButton, 1, 0, 1, 1, Qt::AlignCenter);
    gridRegression->addWidget(canselButton, 1, 1, 1, 1, Qt::AlignCenter);

    dialog->setLayout(gridRegression);

    dialog->setFocus();

    temp_index = in_item->text().remove('x').toInt() - 1;
    dialog->setWindowTitle(tr("��� x%1 ���������:").arg(temp_index + 1));


    dialog->show();
}

void MainWin::acceptChanges()
{
    temp_Factors[temp_index] = (float)spbFactors->value();

    if (b_Response)
        tempResponse = temp_index;


    regressorsList->clear(); factorsList->clear(); varsList->clear(); responseList->clear(); free_factorList->clear();
    temp_Ind_Regressors.clear();
    for (int i = 0; i < temp_Factors.count(); i++)
        if (temp_Factors[i] != 0.)
            if (i != tempResponse)
            {
                temp_Ind_Regressors.push_back(i);
                new QListWidgetItem(tr("x%1").arg(i + 1), regressorsList);
                new QListWidgetItem(tr("%1").arg(temp_Factors[i]), factorsList);
            }
            else
            {
                new QListWidgetItem(tr("x%1").arg(i + 1), responseList);
                new QListWidgetItem(tr("%1").arg(temp_Factors[i]), free_factorList);
            }
        else
            new QListWidgetItem(tr("x%1").arg(i + 1), varsList);

    if ( (tempResponse > -1) && (temp_Ind_Regressors.count() > 0) )
        btnSetRegre->setEnabled(true);
    else
        btnSetRegre->setEnabled(false);

    dialog->close();
}

void MainWin::deleteChangesRegre()
{
    regressorsList->clear(); factorsList->clear(); varsList->clear(); responseList->clear(); free_factorList->clear();
    temp_Ind_Regressors.clear();
    for (int i = 0; i < temp_Factors.count(); i++)    
        if (temp_Factors[i] != 0.)
            if (i != tempResponse)
            {
                temp_Ind_Regressors.push_back(i);
                new QListWidgetItem(tr("x%1").arg(i + 1), regressorsList);
                new QListWidgetItem(tr("%1").arg(temp_Factors[i]), factorsList);
            }
            else
            {
                new QListWidgetItem(tr("x%1").arg(i + 1), responseList);
                new QListWidgetItem(tr("%1").arg(temp_Factors[i]), free_factorList);
            }        
        else
            new QListWidgetItem(tr("x%1").arg(i + 1), varsList);

    if ( (tempResponse > -1) && (temp_Ind_Regressors.count() > 0) )
        btnSetRegre->setEnabled(true);
    else
        btnSetRegre->setEnabled(false);

    dialog->close();
}

void MainWin::createDialogFreeFWidget(const int &ind)
{
    b_Response = true;
}

void MainWin::createDialogFactorsWidget(const int &ind)
{
    b_Response = false;
}

void MainWin::deleteItem(QListWidgetItem *in_item)
{
    int temp_ = in_item->text().remove('x').toInt() - 1;
    temp_Factors[temp_] = 0.;

    factorsList->clear();

    if (temp_ != tempResponse)
        temp_Ind_Regressors.clear();
    else
    {
        free_factorList->clear();
        tempResponse = -1;
    }

    for (int i = 0; i < temp_Factors.count(); i++)
        if (temp_Factors[i] != 0.)
            if (i != tempResponse)
            {
                temp_Ind_Regressors.push_back(i);
                new QListWidgetItem(tr("%1").arg(temp_Factors[i]), factorsList);
            }
    if ( (tempResponse > -1) && (temp_Ind_Regressors.count() > 0) )
        btnSetRegre->setEnabled(true);
    else
        btnSetRegre->setEnabled(false);
}

void MainWin::createResression()
{
    TRegre *tempRegression = new TRegre;
    tempRegression->ind_regressors = temp_Ind_Regressors;
    tempRegression->response = tempResponse;
    for (int i = 0; i < temp_Factors.count(); i++)
        if (temp_Factors[i] != 0.)
            if (i != tempResponse)
                tempRegression->factors.push_back(temp_Factors[i]);
            else
                tempRegression->free_factor = temp_Factors[tempResponse];

    regression.push_back(tempRegression);

    regressorsList->clear(); factorsList->clear(); responseList->clear(); free_factorList->clear();
    temp_Ind_Regressors.clear(); varsList->clear();
    temp_Factors.clear(); temp_Factors = _createF(temp_Balance.count());
    tempResponse = -1; b_Response = false;
    for (int i = 0; i < temp_Balance.count(); i++)
        new QListWidgetItem(QString("x%1").arg(i + 1), varsList);
    btnSetRegre->setEnabled(false);

    lwremainsRegre->clear();

    Vars->setRegression(regression);

    for (int i = 0; i < regression.count(); i++)
    {
        QString str_temp = tr("x%1 = %2").arg(regression[i]->response + 1).arg(regression[i]->free_factor);

        for (int j = 0; j < regression[i]->ind_regressors.count(); j++)
            if (regression[i]->factors[j] > 0)
                str_temp += tr(" +%1x%2").arg(regression[i]->factors[j]).arg(regression[i]->ind_regressors[j] + 1);
            else
                str_temp += tr(" %1x%2").arg(regression[i]->factors[j]).arg(regression[i]->ind_regressors[j] + 1);

        new QListWidgetItem(str_temp, lwremainsRegre);
    }

    Vars->setModeChangedR();
    calc_groups();
}

void MainWin::clearResression()
{
    lwremainsRegre->clear();
    regression.clear();

    regressorsList->clear(); factorsList->clear(); varsList->clear(); responseList->clear(); free_factorList->clear();
    temp_Ind_Regressors.clear();
    for (int i = 0; i < temp_Factors.count(); i++)
    {
        temp_Factors[i] = 0.;
        new QListWidgetItem(tr("x%1").arg(i + 1), varsList);
    }

    btnSetRegre->setEnabled(false);
    Vars->setModeChangedX();
    calc_groups();
}

void MainWin::createRegreCorr(QWidget *in_Widget)
{
    //QTabWidget *regreTabs = new QTabWidget(in_Widget);
    //regreTabs->setTabPosition(t::We West);

    vecFF in_data = model->toArray();

    temp_Balance.clear(); temp_Balance = in_data;
    temp_Factors.clear(); temp_Factors = _createF(temp_Balance.count());
    temp_Ind_Regressors.clear();// temp_Ind_Regressors = _createI(in_data.count());
    b_Response = false;
    tempResponse = -1;


        QGroupBox *grB_CheckRegre = new QGroupBox(tr("����� ����������:"), in_Widget);

            _delete(btnSetRegre);btnSetRegre = new QPushButton(tr("��������� ����� ����������"));
            btnSetRegre->setFont(QFont("Arial", 10, QFont::Bold));
            btnSetRegre->setEnabled(false);
            QObject::connect(btnSetRegre, SIGNAL(clicked()), this, SLOT(createResression()));

            QLabel *listVars = new QLabel; listVars->setText(tr("����������:"));

            _delete(varsList); varsList = new ProjectListWidget(this);
            varsList->setFixedSize(80, 220);
            varsList->setSortingEnabled(true);
            varsList->setFont(QFont("Arial", 10, QFont::Bold));
            varsList->setStatusTip(tr("��������� ������ �������� ����� ������� ���� � ���������� ��� � ������ ������."));
            varsList->setToolTip(tr("������ ��������� ����������"));
            for (int i = 0; i < in_data.count(); i++)
                new QListWidgetItem(QString("x%1").arg(i + 1), varsList);
            connect(varsList, SIGNAL(itemMoved(QListWidgetItem*)), this, SLOT(createDialogFWidget(QListWidgetItem*)));

            QLabel *response = new QLabel; response->setText(tr("������:"));

            _delete(responseList); responseList = new ProjectListWidget(this);
            responseList->setFixedSize(80, 20);
            //responseList->setSortingEnabled(true);
            responseList->setFont(QFont("Arial", 10, QFont::Bold));
            responseList->setStatusTip(tr("�� ������ ������� �������� �� ��������� ���������: �������� �������� �, ��������� ��� ����� ������� ����, �������� ��� �� ������� ������� ����."));
            responseList->setToolTip(tr("������ �������� ���������� ������ � ��������� ���������"));
            connect(responseList, SIGNAL(itemMoved(QListWidgetItem*)), this, SLOT(deleteItem(QListWidgetItem*)));


            QLabel *regressors = new QLabel; regressors->setText(tr("����������:"));

            _delete(regressorsList); regressorsList = new ProjectListWidget(this);
            regressorsList->setFixedSize(80, 200);
            //regressorsList->setSortingEnabled(true);
            regressorsList->setFont(QFont("Arial", 10, QFont::Bold));
            regressorsList->setStatusTip(tr("�� ������ ������� �������� �� ��������� ���������: �������� �������� �, ��������� ��� ����� ������� ����, �������� ��� �� ������� ������� ����."));
            regressorsList->setToolTip(tr("������ ����������� - ��������� ���������� ��������� ���������"));
            connect(regressorsList, SIGNAL(itemMoved(QListWidgetItem*)), this, SLOT(deleteItem(QListWidgetItem*)));


            QLabel *free_factor = new QLabel; free_factor->setText(tr("���������:"));

            _delete(free_factorList); free_factorList = new QListWidget(this);
            //free_factorList->sortItems();
            free_factorList->setFixedSize(80, 20);
            //free_factorList->setSortingEnabled(true);
            free_factorList->setFont(QFont("Arial", 10, QFont::Bold));
            //free_factorList->setStatusTip(tr("�� ������ ������� �������� �� ��������� ���������: �������� �������� �, ��������� ��� ����� ������� ����, ������� ��� �������."));
            free_factorList->setToolTip(tr("������ �������� ���������� ������� ����������� ����� (���������) � ��������� ���������"));
            connect(responseList, SIGNAL(itemDropped(int)), this, SLOT(createDialogFreeFWidget(int)));

            QLabel *factors = new QLabel; factors->setText(tr("������������:"));

            _delete(factorsList); factorsList = new QListWidget(this);
            factorsList->setFixedSize(80, 200);
            //factorsList->setSortingEnabled(true);
            factorsList->setFont(QFont("Arial", 10, QFont::Bold));
            //factorsList->setStatusTip(tr("�� ������ ������� �������� �� ��������� ���������: �������� �������� �, ��������� ��� ����� ������� ����, ������� ��� �������."));
            factorsList->setToolTip(tr("������ ������������� ��� ��������������� ���������� ��������� ���������"));
            connect(regressorsList, SIGNAL(itemDropped(int)), this, SLOT(createDialogFactorsWidget(int)));

            _delete(btnClearRegre);btnClearRegre = new QPushButton(tr("�������� ������ ��������� ���������"));
            btnClearRegre->setFont(QFont("Arial", 10, QFont::Bold));
            QObject::connect(btnClearRegre, SIGNAL(clicked()), this, SLOT(clearResression()));

            QGridLayout *gridRegre = new QGridLayout;
            gridRegre->addWidget(btnSetRegre, 0, 0, 1, 3, Qt::AlignCenter);

            gridRegre->addWidget(listVars, 1, 0, 1, 1, Qt::AlignBottom);
            gridRegre->addWidget(varsList, 2, 0, 4, 1, Qt::AlignTop);

            gridRegre->addWidget(response, 1, 1, 1, 1, Qt::AlignBottom);
            gridRegre->addWidget(responseList, 2, 1, 1, 1, Qt::AlignTop);

            gridRegre->addWidget(regressors, 3, 1, 1, 1, Qt::AlignBottom);
            gridRegre->addWidget(regressorsList, 4, 1, 2, 1, Qt::AlignTop);

            gridRegre->addWidget(free_factor, 1, 2, 1, 1, Qt::AlignBottom);
            gridRegre->addWidget(free_factorList, 2, 2, 1, 1, Qt::AlignTop);

            gridRegre->addWidget(factors, 3, 2, 1, 1, Qt::AlignBottom);
            gridRegre->addWidget(factorsList, 4, 2, 2, 1, Qt::AlignTop);

        grB_CheckRegre->setLayout(gridRegre);

        QGroupBox *grB_RegreResult = new QGroupBox(tr("��������� ���������:"), in_Widget);

            _delete(lwremainsRegre); lwremainsRegre = new QListWidget(this);
            lwremainsRegre->setFont(QFont("Arial", 12, QFont::Bold));

            QVBoxLayout *gridRemainsRegre = new QVBoxLayout;

            gridRemainsRegre->addWidget(lwremainsRegre, 5);
            gridRemainsRegre->addWidget(btnClearRegre, 1);

        grB_RegreResult->setLayout(gridRemainsRegre);

    QHBoxLayout *grB_Lay = new QHBoxLayout;
    grB_Lay->addWidget(grB_CheckRegre, 0);
    grB_Lay->addWidget(grB_RegreResult, 10);

    in_Widget->setLayout(grB_Lay);


    //QWidget *remainsRegre = new QWidget;

    //QWidget *corrRemainsRegre = new QWidget;
/*
    QWidget *corrRemainsModel = new QWidget;

    regreTabs->addTab(checkRegre, tr("����� ���������"));
    //regreTabs->addTab(remainsRegre, tr("�������"));
    //regreTabs->addTab(corrRemainsRegre, tr("���������� ��������"));
    regreTabs->addTab(corrRemainsModel, tr("����������� ������� ����� �����"));

    regreTabs->setTabShape(QTabWidget::Triangular);

    QVBoxLayout *allRegre = new QVBoxLayout;
    allRegre->addWidget(regreTabs);

    in_Widget->setLayout(allRegre);*/

    in_data.clear();

}

/*
void MainWin::setCorrTree(vecII in)
{
    vecS str(in.count());
    for (int i = 0; i < in.count(); i++)
        for (int j = 0; j < in[i].count(); j++)
            str[i] += QString("x%1").arg(in[i][j] + 1);

    for (int i = 0; i < str.count(); i++)
    {
        linesModelBW->setData(linesModelBW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelB->setData(linesModelB->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelNW->setData(linesModelNW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelN->setData(linesModelN->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
    }
    str.clear();
}*/


//--------------------------------------------------------
Node* MainWin::InitTree(){

    vecII groupVar;
    groupVar = vecGr;

    int countGroups = groupVar.count();

    Node *root = new Node();

    Node *group1 = new Node( root,  tr("1"), tr("������� ����������� �����"), "","", "", GROUP);
    root->children.append(group1);

        Node *group11 = new Node( group1,  tr("1.1"), tr("HOTELLING"), "","", "", GROUP);
        group1->children.append(group11);

        groupsH.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsH[i] = new Node( group11,  tr("1.1.%1").arg(i+1), str, "", "", "", GROUP);
            group11->children.append(groupsH[i]);
            str = "";
        }


        Node *group12 = new Node( group1, tr("1.2"), tr("MEWMA"), "", "", "", GROUP);
        group1->children.append(group12);

        groupsM.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsM[i] = new Node( group12, tr("1.2.%1").arg(i+1), str, "", "", "", GROUP);
            group12->children.append(groupsM[i]);
            str = "";
        }

    Node *group2 = new Node( root, tr("2"), tr("����������� ����� � ��������������� ��������"), "", "", "", GROUP);
    root->children.append(group2);

        Node *group21 = new Node( group2, tr("2.1"), tr("HOTELLING"), "", "", "", GROUP);
        group2->children.append(group21);

        groupsHW.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHW[i] = new Node( group21, tr("2.1.%1").arg(i+1), str, "", "", "", GROUP);
            group21->children.append(groupsHW[i]);
            str = "";
        }

        Node *group22 = new Node( group2, tr("2.2"), tr("MEWMA"), "", "", "", GROUP);
        group2->children.append(group22);

        groupsMW.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMW[i] = new Node( group22, tr("2.2.%1").arg(i+1), str, "", "", "", GROUP);
            group22->children.append(groupsMW[i]);
            str = "";
        }



    return root;
}

void MainWin::groupChanged(const QModelIndex& index){

    QModelIndex i = treeProxyModel->mapToSource(index);
    iCorr = i;

    int countRows = mmodel->rowCount(i);
    if (countRows > 0)
    {

        QModelIndex j = tableProxyModel->mapFromSource(i);
        tableview->setRootIndex(j);


        vecR temp_data, temp_sp; temp_data.resize(countRows);
        for (int ii = 0; ii < countRows; ii++)
        {
            temp_data[ii].setX(mmodel->data(mmodel->index(ii, 4, i),Qt::EditRole).toFloat());
            temp_data[ii].setY(mmodel->data(mmodel->index(ii, 2, i),Qt::EditRole).toFloat());            
        }

        float tempX = 0.0, tempY = 0.0;

        for (int ii = 0; ii < countRows; ii++)
           for (int jj = ii; jj < countRows; jj++)
                if (temp_data[jj].x() < temp_data[ii].x())
                {
                    tempX = temp_data[ii].x(); tempY = temp_data[ii].y();
                    temp_data[ii].setX(temp_data[jj].x());
                    temp_data[ii].setY(temp_data[jj].y());
                    temp_data[jj].setX(tempX);
                    temp_data[jj].setY(tempY);
                }
        tempX = __null; tempY = __null;

        if (!corrCheckedGraphs)
        {
            _delete(corrGraph);
            corrGraph = new Curve();
            countGraphs = 0;
        }
        if (temp_data.count() < 3)
            corrGraph->setCurveData(countGraphs, temp_data);
        else
        {
            /*cubic_spline *spline = new cubic_spline;

            vecF XX, YY;

            for (int j = 0; j < temp_data.count(); j++)
            {
                XX.push_back(temp_data[j].x()); YY.push_back(temp_data[j].y());
            }
            spline->build_spline(XX, YY);

            for (qreal j = XX[0];j <= XX[XX.count()-1]; j+=0.01 )
            {

                temp_sp.push_back(QPointF(j, (qreal)spline->f(j)));
            }*/

            power_funct *power = new power_funct;
            power->build_funct(temp_data);
            for (qreal j = temp_data[0].x();j <= temp_data[temp_data.count()-1].x(); j+=0.01 )
                temp_sp.push_back(QPointF(j, power->f(j)));

            corrGraph->setCurveData(countGraphs, temp_sp);
        }
        countGraphs++;
        temp_data.clear();temp_sp.clear();
        corrGraph->setVarsName(tr("������� ����� �����"));
        corrGraph->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));

        split->addWidget(corrGraph);split->setStretchFactor(1, 2);

        corrGraph->hasFocus();

    }
    countRows = __null;


}

void MainWin::updateCorrLS()
{

    vecF avSLHot, avSLMewma, avSLWHot, avSLWMewma, skoSLHot, skoSLMewma, skoSLWHot, skoSLWMewma, lambda;
    float tmin = 0.0, tmax = 0.0, sqrtn = sqrt(linesHotCorr[0].count());
    {
        avSLHot = _mean(linesHotCorr); skoSLHot = _sko(linesHotCorr);
        avSLMewma = _mean(linesMewmaCorr); skoSLMewma = _sko(linesMewmaCorr);
        avSLWHot = _mean(linesHotWCorr); skoSLWHot = _sko(linesHotWCorr);
        avSLWMewma = _mean(linesMewmaWCorr); skoSLWMewma = _sko(linesMewmaWCorr);
        lambda = Vars->getLambdaCorr();

    }
    /*countCorr++;
    for (int i = 0; i < vecGr.count(); i++)
    {
        tmin = avSLHot[i] - (1.67 * skoSLHot[i] / sqrtn); tmax = avSLHot[i] + (1.67 * skoSLHot[i] / sqrtn);
        groupsH[i]->children.append( new Node( groupsH[i], tr("1.1.%1   �%2").arg(i + 1).arg(countCorr), tr("%1").arg(tmin), tr("%1").arg(avSLHot[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
        tmin = avSLMewma[i] - (1.67 * skoSLMewma[i] / sqrtn); tmax = avSLMewma[i] + (1.67 * skoSLMewma[i] / sqrtn);
        groupsM[i]->children.append( new Node( groupsM[i], tr("1.2.%1   �%2").arg(i + 1).arg(countCorr), tr("%1").arg(tmin), tr("%1").arg(avSLMewma[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
        tmin = avSLWHot[i] - (1.67 * skoSLWHot[i] / sqrtn); tmax = avSLWHot[i] + (1.67 * skoSLWHot[i] / sqrtn);
        groupsHW[i]->children.append( new Node( groupsHW[i], tr("2.1.%1   �%2").arg(i + 1).arg(countCorr), tr("%1").arg(tmin), tr("%1").arg(avSLWHot[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
        tmin = avSLWMewma[i] - (1.67 * skoSLWMewma[i] / sqrtn); tmax = avSLWMewma[i] + (1.67 * skoSLWMewma[i] / sqrtn);
        groupsMW[i]->children.append( new Node( groupsMW[i], tr("2.2.%1   �%2").arg(i + 1).arg(countCorr), tr("%1").arg(tmin), tr("%1").arg(avSLWMewma[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
    }




    _delete(treeProxyModel);treeProxyModel = new QSortFilterProxyModel(this);
    treeProxyModel->setSourceModel(mmodel);
    treeProxyModel->setFilterRole(Qt::DisplayRole);
    treeProxyModel->setFilterKeyColumn(5);
    treeProxyModel->setFilterFixedString("1"); //������ ��� ���������

    _delete(tableProxyModel);tableProxyModel = new QSortFilterProxyModel(this);
    tableProxyModel->setSourceModel(mmodel);

    treeview->reset();treeview->setModel(treeProxyModel);treeview->expandAll();

    tableview->reset();tableview->setModel(tableProxyModel);*/

    vecS str(vecGr.count());

    for (int i = 0; i < vecGr.count(); i++)
        for (int j = 0; j < vecGr[i].count(); j++)
            str[i] += QString("x%1").arg(vecGr[i][j] + 1);

    vecSS tempS = _createS(7, vecGr.count());

    _delete(linesCorrResult); linesCorrResult = new LinesResultsModel(this, "LinesResults");
    linesCorrResult->toModel(tempS);
    _delete(linesCorrResultW); linesCorrResultW = new LinesResultsModel(this, "LinesResults");
    linesCorrResultW->toModel(tempS);
    tempS.clear();

    for (int i = 0; i < vecGr.count(); i++)
    {
        tmin = avSLHot[i] - (1.67 * skoSLHot[i] / sqrtn); tmax = avSLHot[i] + (1.67 * skoSLHot[i] / sqrtn);
        linesCorrResult->setData(linesCorrResult->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesCorrResult->setData(linesCorrResult->index(i, 1, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesCorrResult->setData(linesCorrResult->index(i, 2, QModelIndex()), QString("%1").arg(avSLHot[i]), Qt::EditRole);
        linesCorrResult->setData(linesCorrResult->index(i, 3, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

        tmin = avSLMewma[i] - (1.67 * skoSLMewma[i] / sqrtn); tmax = avSLMewma[i] + (1.67 * skoSLMewma[i] / sqrtn);;
        linesCorrResult->setData(linesCorrResult->index(i, 4, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesCorrResult->setData(linesCorrResult->index(i, 5, QModelIndex()), QString("%1").arg(avSLMewma[i]), Qt::EditRole);
        linesCorrResult->setData(linesCorrResult->index(i, 6, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

        tmin = avSLWHot[i] - (1.67 * skoSLWHot[i] / sqrtn); tmax = avSLWHot[i] + (1.67 * skoSLWHot[i] / sqrtn);
        linesCorrResultW->setData(linesCorrResultW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesCorrResultW->setData(linesCorrResultW->index(i, 1, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesCorrResultW->setData(linesCorrResultW->index(i, 2, QModelIndex()), QString("%1").arg(avSLWHot[i]), Qt::EditRole);
        linesCorrResultW->setData(linesCorrResultW->index(i, 3, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

        tmin = avSLWMewma[i] - (1.67 * skoSLWMewma[i] / sqrtn); tmax = avSLWMewma[i] + (1.67 * skoSLWMewma[i] / sqrtn);
        linesCorrResultW->setData(linesCorrResultW->index(i, 4, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesCorrResultW->setData(linesCorrResultW->index(i, 5, QModelIndex()), QString("%1").arg(avSLWMewma[i]), Qt::EditRole);
        linesCorrResultW->setData(linesCorrResultW->index(i, 6, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

    }
    str.clear();
    //treeResultCorr->reset();treeResultCorr->setModel(linesCorrResult);
    //treeResultWCorr->reset();treeResultWCorr->setModel(linesCorrResultW);


    //_delete(treeResultCorr);
    QTreeView *treeResultCorr = new QTreeView; treeResultCorr->setModel(linesCorrResult);treeResultCorr->setFont(QFont("Arial", 10, QFont::Bold));
    treeResultCorr->resizeColumnToContents(0);
    treeResultCorr->resizeColumnToContents(1);
    treeResultCorr->resizeColumnToContents(2);
    treeResultCorr->resizeColumnToContents(3);
    treeResultCorr->resizeColumnToContents(4);
    treeResultCorr->resizeColumnToContents(5);
    treeResultCorr->resizeColumnToContents(6);
    treeResultCorr->header()->setDefaultAlignment(Qt::AlignCenter);

    QVBoxLayout *lineCorr = new QVBoxLayout;
    lineCorr->addWidget(treeResultCorr);

    QGroupBox *lineGrB = new QGroupBox(tr("���������� ���������� ������� ���� �����:"));
    lineGrB->setLayout(lineCorr);

    //-------------------------------

    //_delete(treeResultWCorr);
    QTreeView *treeResultWCorr = new QTreeView; treeResultWCorr->setModel(linesCorrResultW);treeResultWCorr->setFont(QFont("Arial", 10, QFont::Bold));
    treeResultWCorr->resizeColumnToContents(0);
    treeResultWCorr->resizeColumnToContents(1);
    treeResultWCorr->resizeColumnToContents(2);
    treeResultWCorr->resizeColumnToContents(3);
    treeResultWCorr->resizeColumnToContents(4);
    treeResultWCorr->resizeColumnToContents(5);
    treeResultWCorr->resizeColumnToContents(6);
    treeResultWCorr->header()->setDefaultAlignment(Qt::AlignCenter);

    QVBoxLayout *lineCorrW = new QVBoxLayout;
    lineCorrW->addWidget(treeResultWCorr);

    QGroupBox *lineGrBW = new QGroupBox(tr("���������� ���������� ������� ���� ����� ��� ����������� ���� � ��������������� ��������:"));
    lineGrBW->setLayout(lineCorrW);

    //----------------------------------

    QSplitter *sp_linesCorr = new QSplitter(Qt::Vertical, CorrTabs);
    sp_linesCorr->addWidget(lineGrB);
    sp_linesCorr->addWidget(lineGrBW);

    _delete(lineSeriesCorr);lineSeriesCorr = new QVBoxLayout;
    lineSeriesCorr->addWidget(sp_linesCorr);

    CorrTabs->setLayout(lineSeriesCorr);

    avSLHot.clear(); avSLMewma.clear(); avSLWHot.clear(); avSLWMewma.clear();
    skoSLHot.clear(); skoSLMewma.clear(); skoSLWHot.clear(); skoSLWMewma.clear();
    lambda.clear(); tmin = __null; tmax = __null;

}

void MainWin::setCheckedGraphs(const bool &in)
{
    corrCheckedGraphs = in;
}

void MainWin::deleteRow()
{
    int hhh = iCorr.row(), ggg = tableview->selectionModel()->currentIndex().row();
    groupsH[hhh]->children.remove(ggg, 1);
    groupsM[hhh]->children.remove(ggg, 1);
    groupsHW[hhh]->children.remove(ggg, 1);
    groupsMW[hhh]->children.remove(ggg, 1);
    _delete(treeProxyModel);treeProxyModel = new QSortFilterProxyModel(this);
    treeProxyModel->setSourceModel(mmodel);
    treeProxyModel->setFilterRole(Qt::DisplayRole);
    treeProxyModel->setFilterKeyColumn(5);
    treeProxyModel->setFilterFixedString("1"); //������ ��� ���������

    _delete(tableProxyModel);tableProxyModel = new QSortFilterProxyModel(this);
    tableProxyModel->setSourceModel(mmodel);

    treeview->reset();treeview->setModel(treeProxyModel);treeview->expandAll();
    tableview->reset();tableview->setModel(tableProxyModel);
}

void MainWin::mousePressEvent(QMouseEvent *event)
{


}

void MainWin::createLinesSCorr()
{
    //*********�������� ���������*************************************************
    /*countGraphs = 0;


    _delete(mmodel); mmodel = new TreeModel(this);
    mmodel->setRootNode(InitTree());

    _delete(treeProxyModel);treeProxyModel = new QSortFilterProxyModel(this);
    treeProxyModel->setSourceModel(mmodel);
    treeProxyModel->setFilterRole(Qt::DisplayRole);
    treeProxyModel->setFilterKeyColumn(5);
    treeProxyModel->setFilterFixedString("1"); //������ ��� ���������

    _delete(tableProxyModel);tableProxyModel = new QSortFilterProxyModel(this);
    tableProxyModel->setSourceModel(mmodel);

    _delete(treeview);treeview = new QTreeView(this);
    treeview->setSelectionMode(QAbstractItemView::SingleSelection);
    treeview->setSelectionBehavior(QAbstractItemView::SelectRows);
    treeview->setModel(treeProxyModel);
    treeview->hideColumn(2);
    treeview->hideColumn(3);
    treeview->hideColumn(4);
    treeview->hideColumn(5);
    treeview->expandAll();treeview->header()->hide();
    treeview->header()->setStretchLastSection(true);

    checkGraphs = new QCheckBox(this);
    checkGraphs->setText(tr("����� ���������� ��������"));
    checkGraphs->setChecked(false);
    QObject::connect(checkGraphs, SIGNAL(toggled(bool)), this, SLOT(setCheckedGraphs(bool)));

    QSplitter *__split = new QSplitter(Qt::Vertical, this);
    __split->addWidget(treeview);
    __split->addWidget(checkGraphs);

    //QColor color = QColor(200, 230, 240);
    //treeview->setStyleSheet(QString("QTreeView{ background-color: %1 }").arg(color.name()));

    _delete(tableview);tableview = new MyTableView(this);
    tableview->setModel(tableProxyModel);
    tableview->hideColumn(5);
    tableview->hideColumn(6);
    tableview->resizeColumnsToContents();    
    tableview->horizontalHeader()->setStretchLastSection(true);


    QObject::connect(tableview->deleteRow, SIGNAL(triggered()), this, SLOT(deleteRow()));


    _delete(corrGraph);corrGraph = new Curve();

    QSplitter *_split = new QSplitter(Qt::Vertical, this);

    _delete(split);split = new QSplitter(Qt::Horizontal, _split);
    split->addWidget(__split);split->setStretchFactor(0, 2);
    split->addWidget(corrGraph);split->setStretchFactor(1, 2);

    _split->addWidget(split);
    _split->addWidget(tableview);
    _split->setStretchFactor(0, 2);
    _split->setStretchFactor(1, 1);

    connect( treeview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(groupChanged(const QModelIndex &)) );

    //30.03.2012   ���������� ������� ����������� ������� ���� �����

    /*vecSS tempS = _createS(7, vecGr.count());

    _delete(linesCorrResult); linesCorrResult = new LinesResultsModel(this, "LinesResults");
    linesCorrResult->toModel(tempS);
    _delete(linesCorrResultW); linesCorrResultW = new LinesResultsModel(this, "LinesResults");
    linesCorrResultW->toModel(tempS);
    tempS.clear();

    _delete(treeResultCorr);
    treeResultCorr = new QTreeView; treeResultCorr->setModel(linesCorrResult);treeResultCorr->setFont(QFont("Arial", 10, QFont::Bold));
    treeResultCorr->resizeColumnToContents(0);
    treeResultCorr->resizeColumnToContents(1);
    treeResultCorr->resizeColumnToContents(2);
    treeResultCorr->resizeColumnToContents(3);
    treeResultCorr->resizeColumnToContents(4);
    treeResultCorr->resizeColumnToContents(5);
    treeResultCorr->resizeColumnToContents(6);
    treeResultCorr->header()->setDefaultAlignment(Qt::AlignCenter);

    QVBoxLayout *lineCorr = new QVBoxLayout;
    lineCorr->addWidget(treeResultCorr);

    QGroupBox *lineGrB = new QGroupBox(tr("���������� ���������� ������� ���� �����:"));
    lineGrB->setLayout(lineCorr);

    //-------------------------------

    _delete(treeResultWCorr);
    treeResultWCorr = new QTreeView; treeResultWCorr->setModel(linesCorrResultW);treeResultWCorr->setFont(QFont("Arial", 10, QFont::Bold));
    treeResultWCorr->resizeColumnToContents(0);
    treeResultWCorr->resizeColumnToContents(1);
    treeResultWCorr->resizeColumnToContents(2);
    treeResultWCorr->resizeColumnToContents(3);
    treeResultWCorr->resizeColumnToContents(4);
    treeResultWCorr->resizeColumnToContents(5);
    treeResultWCorr->resizeColumnToContents(6);
    treeResultWCorr->header()->setDefaultAlignment(Qt::AlignCenter);

    QVBoxLayout *lineCorrW = new QVBoxLayout;
    lineCorrW->addWidget(treeResultWCorr);


    QGroupBox *lineGrBW = new QGroupBox(tr("���������� ���������� ������� ���� ����� ��� ����������� ���� � ��������������� ��������:"));
    lineGrBW->setLayout(lineCorrW);

    //----------------------------------

    QSplitter *sp_linesCorr = new QSplitter(Qt::Vertical, CorrTabs);
    sp_linesCorr->addWidget(lineGrB);
    sp_linesCorr->addWidget(lineGrBW);

    QVBoxLayout *lineSeriesCorr = new QVBoxLayout;
    lineSeriesCorr->addWidget(sp_linesCorr);


    CorrTabs->repaint();
    CorrTabs->setLayout(lineSeriesCorr);*/
}



void MainWin::calc_groups()
{
    int mode = Vars->getModeChanged();
    vecSS tempS;
    if (mode == 0)
        tempS = _createS(5, 3);
    if (mode == 1);
    if (mode == 2)
        tempS = _createS(5, 1);

    //������ ��� ��������������� �������
    linesModelB->toModel(tempS);
    linesModelBW->toModel(tempS);
    linesModelN->toModel(tempS);
    linesModelNW->toModel(tempS);

    tempS.clear();

    vvv1->reset();
    vvv1->setModel(linesModelB);vvv1->setFont(QFont("Arial", 10, QFont::Bold));
    vvv1->resizeColumnToContents(1);vvv1->resizeColumnToContents(3);
    vvv1->header()->setDefaultAlignment(Qt::AlignCenter);

    vvv2->reset();
    vvv2->setModel(linesModelBW);vvv2->setFont(QFont("Arial", 10, QFont::Bold));
    vvv2->resizeColumnToContents(1);vvv2->resizeColumnToContents(3);
    vvv2->header()->setDefaultAlignment(Qt::AlignCenter);

    vvv3->reset();
    vvv3->setModel(linesModelN);vvv3->setFont(QFont("Arial", 10, QFont::Bold));
    vvv3->header()->setDefaultAlignment(Qt::AlignCenter);

    vvv4->reset();
    vvv4->setModel(linesModelNW);vvv4->setFont(QFont("Arial", 10, QFont::Bold));
    vvv4->header()->setDefaultAlignment(Qt::AlignCenter);

    //����� �������������� ���� � ��������� ��������-������ ����� ��� ����������������
    qRegisterMetaType<vecII>("vecII");

    grCorr = new GroupVars(Vars);
    grCorr->start();

    QObject::connect(grCorr, SIGNAL(getData(vecII)), this, SLOT(setCorrStr(vecII)));
}

void MainWin::setCorrStr(vecII in)
{
    vecGr.clear(); vecGr = in;
    vecS str(in.count());

    for (int i = 0; i < in.count(); i++)
        for (int j = 0; j < in[i].count(); j++)
            str[i] += QString("x%1").arg(in[i][j] + 1);

    for (int i = 0; i < str.count(); i++)
    {
        linesModelBW->setData(linesModelBW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelB->setData(linesModelB->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelNW->setData(linesModelNW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelN->setData(linesModelN->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
    }
    str.clear();

    QObject::connect(spbLambda, SIGNAL(valueChanged(int)), this, SLOT(setLbLambda(int)));
    connect( listLinesVar, SIGNAL(clicked(const QModelIndex &)), this, SLOT(setListBLambda(const QModelIndex &)) );
    spbLambda->setValue(Vars->getFileCountVars());
    //createLinesSCorr();
    createLinesModCorr();
}

NodeModel* MainWin::InitTreeModelling(){

    vecII groupVar = vecGr;

    int countGroups = groupVar.count();

    NodeModel *rootModCorr = new NodeModel();

    NodeModel *group1 = new NodeModel( rootModCorr,  tr("1"), "", "", "", "", "", GROUP);
    rootModCorr->children.append(group1);

        NodeModel *group11 = new NodeModel( group1,  tr("1.1"), tr("HOTELLING"), "", "", "", "", GROUP);
        group1->children.append(group11);

        groupsHMod.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHMod[i] = new NodeModel( group11,  tr("1.1.%1").arg(i+1), str, "", "", "", "", GROUP);
            group11->children.append(groupsHMod[i]);
            str = "";
        }

        NodeModel *group12 = new NodeModel( group1, tr("1.2"), tr("MEWMA"), "", "", "", "", GROUP);
        group1->children.append(group12);

        groupsMMod.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMMod[i] = new NodeModel( group12, tr("1.2.%1").arg(i+1), str, "", "", "", "", GROUP);
            group12->children.append(groupsMMod[i]);
            str = "";
        }

        NodeModel *group13 = new NodeModel( group1, tr("1.3"), tr("HOTELLING with the warning boundary"), "", "", "", "", GROUP);
        group1->children.append(group13);

        groupsHWMod.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHWMod[i] = new NodeModel( group13, tr("1.3.%1").arg(i+1), str, "", "", "", "", GROUP);
            group13->children.append(groupsHWMod[i]);
            str = "";
        }

        NodeModel *group14 = new NodeModel( group1, tr("1.4"), tr("MEWMA with the warning boundary"), "", "", "", "", GROUP);
        group1->children.append(group14);

        groupsMWMod.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMWMod[i] = new NodeModel( group14, tr("1.4.%1").arg(i+1), str, "", "", "", "", GROUP);
            group14->children.append(groupsMWMod[i]);
            str = "";
        }

    groupVar.clear();
    countGroups = __null;
    return rootModCorr;
}

void MainWin::groupModChanged(const QModelIndex& index){

    /*QModelIndex i = treeModProxyModel->mapToSource(index);

    int countRows = modelCorrModel->rowCount(i);
    if (countRows > 0)
    {

        //QModelIndex j = tableModProxyModel->mapFromSource(i);
        //tableModelling->setRootIndex(j);


        vecR temp_data, temp_sp; temp_data.resize(countRows);
        for (int ii = 0; ii < countRows; ii++)
        {
            temp_data[ii].setX(modelCorrModel->data(modelCorrModel->index(ii, 4, i),Qt::EditRole).toFloat());
            temp_data[ii].setY(modelCorrModel->data(modelCorrModel->index(ii, 2, i),Qt::EditRole).toFloat());
        }

        float tempX = 0.0, tempY = 0.0;

        for (int ii = 0; ii < countRows; ii++)
           for (int jj = ii; jj < countRows; jj++)
                if (temp_data[jj].x() < temp_data[ii].x())
                {
                    tempX = temp_data[ii].x(); tempY = temp_data[ii].y();
                    temp_data[ii].setX(temp_data[jj].x());
                    temp_data[ii].setY(temp_data[jj].y());
                    temp_data[jj].setX(tempX);
                    temp_data[jj].setY(tempY);
                }
        tempX = __null; tempY = __null;

        if (!corrCheckedGraphs)
        {
            _delete(corrGraph);
            corrGraph = new Curve();
            countGraphs = 0;
        }
        if (temp_data.count() < 3)
            corrGraph->setCurveData(countGraphs, temp_data);
        else
        {
            cubic_spline *spline = new cubic_spline;

            vecF XX, YY;

            for (int j = 0; j < temp_data.count(); j++)
            {
                XX.push_back(temp_data[j].x()); YY.push_back(temp_data[j].y());
            }
            spline->build_spline(XX, YY);

            for (qreal j = XX[0];j <= XX[XX.count()-1]; j+=0.01 )
            {

                temp_sp.push_back(QPointF(j, (qreal)spline->f(j)));
            }

            corrGraph->setCurveData(countGraphs, temp_sp);
        }
        countGraphs++;
        temp_data.clear();temp_sp.clear();
        corrGraph->setVarsName(tr("������� ����� �����"));
        corrGraph->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));

        split->addWidget(corrGraph);split->setStretchFactor(1, 2);

        corrGraph->hasFocus();

    }
    countRows = __null;*/


}

void MainWin::createLinesModCorr()
{
    //vecLamda ttt = _getGroupsRegreNonCentral(vecGr, Vars->getData(), Vars->getFileCountStepV());

    _delete(modelCorrModel);modelCorrModel = new TreeModelling(this);
    modelCorrModel->setRootNode(InitTreeModelling());

    _delete(treeModProxyModel);treeModProxyModel = new QSortFilterProxyModel(this);
    treeModProxyModel->setSourceModel(modelCorrModel);
    treeModProxyModel->setFilterRole(Qt::DisplayRole);

    _delete(treeCorrModel);treeCorrModel = new QTreeView(CorrTabModelling);
    treeCorrModel->setModel(treeModProxyModel);
    treeCorrModel->expandAll();
    treeCorrModel->resizeColumnToContents(1);
    treeCorrModel->resizeColumnToContents(2);
    treeCorrModel->resizeColumnToContents(3);
    treeCorrModel->resizeColumnToContents(4);
    treeCorrModel->resizeColumnToContents(5);

    treeCorrModel->header()->setDefaultAlignment(Qt::AlignCenter);
    treeCorrModel->header()->setMovable(true);
    treeCorrModel->header()->setResizeMode(QHeaderView::ResizeToContents);
    treeCorrModel->header()->setResizeMode(QHeaderView::Interactive);
    treeCorrModel->setFont(QFont("Arial", 10, QFont::Bold));

    _delete(modelSimplePrB); modelSimplePrB = new QProgressBar;
    modelSimplePrB->setOrientation(Qt::Vertical);

    QGroupBox *modelGrB = new QGroupBox(tr("����� ���������� ��� �������:"), CorrTabModelling);

    QLabel *modelLb = new QLabel;
    modelLb->setText(tr("������ ������������ ���������� �������� ������� ���� ����� � �������:"));
    modelLb->setFont(QFont("Arial", 10, QFont::Bold));

    QSpinBox *modelSpB = new QSpinBox;
    connect(modelSpB, SIGNAL(valueChanged(int)), Vars, SLOT(setCountModelCorr(int)));        
    modelSpB->setMaximum(_getCountVars(Vars->getFileCountVars()));
    modelSpB->setValue(_getCountVars(Vars->getFileCountVars()));

    QHBoxLayout *layModel = new QHBoxLayout(CorrTabModelling);
    layModel->addWidget(modelLb, 1, Qt::AlignRight | Qt::AlignVCenter);
    layModel->addWidget(modelSpB, 1, Qt::AlignLeft | Qt::AlignVCenter);
    modelGrB->setLayout(layModel);

    QHBoxLayout *laySimpleModel = new QHBoxLayout(CorrTabModelling);
    laySimpleModel->addWidget(treeCorrModel, 10);
    laySimpleModel->addWidget(modelSimplePrB, 0);


    _delete(modelBtRun); modelBtRun = new QPushButton(tr("��������� ���������� ������� ���� ����� ��� �������� ���������"));
    modelBtRun->setFont(QFont("Arial", 11, QFont::Bold));
    QObject::connect(modelBtRun, SIGNAL(clicked()), this, SLOT(createModelThread()));

    QSplitter *split = new QSplitter(Qt::Horizontal, CorrTabModelling);
    split->setLayout(laySimpleModel);split->setLayoutDirection(Qt::LeftToRight);

    QVBoxLayout *layCorrModel = new QVBoxLayout(CorrTabModelling);

    layCorrModel->addWidget(modelGrB, 1);
    layCorrModel->addWidget(split, 10);
    layCorrModel->addWidget(modelBtRun, 1);

    CorrTabModelling->setLayout(layCorrModel);
}

void MainWin::setModelBtRun(const QString &str)
{
    modelBtRun->setText(str);
}

void MainWin::setModelPrBRun(const int &in_iter)
{
    countItersModelSimple++;
    modelSimplePrB->setValue(countItersModelSimple);
}

void MainWin::setModelRes(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelHotSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelMewmaSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelHotSimple[idGroup].count() - 1))
    {
        modelThread[idGroup] = true;
        if (modelThread[idGroup] && modelNThread[idGroup]) updateModelSimple(idGroup, idIter);
    }
}

void MainWin::setModelResW(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelHotWSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelMewmaWSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelHotWSimple[idGroup].count() - 1))
    {
        modelThreadW[idGroup] = true;
        if (modelThreadW[idGroup] && modelNThreadW[idGroup]) updateModelSimpleW(idGroup, idIter);
    }
}

void MainWin::setModelNRes(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelHotSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelMewmaSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelHotSimple[idGroup].count() - 1))
    {
        modelNThread[idGroup] = true;
        if (modelThread[idGroup] && modelNThread[idGroup]) updateModelSimple(idGroup, idIter);
    }
}

void MainWin::setModelNResW(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelHotWSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelMewmaWSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelHotWSimple[idGroup].count() - 1))
    {
        modelNThreadW[idGroup] = true;
        if (modelThreadW[idGroup] && modelNThreadW[idGroup]) updateModelSimpleW(idGroup, idIter);
    }
}

void MainWin::updateModelSimple(const int &idGroup, const int &idIter)
{
    int counts = idIter + 1, countGr = vecGr[idGroup].count(), i = 0, k = 0, s = 0;

    float tmin = 0., tmax = 0., minSLS = 0., minSLSM = 0., SKO = 0., SKOM = 0.;
    vecF SLS(counts), SLSM(counts);

    minSLS = _mean1V(modelHotSimple[idGroup][0]);minSLSM = _mean1V(modelMewmaSimple[idGroup][0]);
    SLS[0] = minSLS;SLSM[0] = minSLSM;
    for(i = 1; i < counts; i++)
    {
        SLS[i] = _mean1V(modelHotSimple[idGroup][i]);
        SLSM[i] = _mean1V(modelMewmaSimple[idGroup][i]);

        if (SLS[i] <= minSLS) minSLS = SLS[i];
        if (SLSM[i] <= minSLSM) minSLSM = SLSM[i];
    }

    float countMin = 0., countMinM = 0.;
    for(i = 0; i < counts; i++)
    {
        SKO = _sko1V(modelHotSimple[idGroup][i]);
        SKOM = _sko1V(modelMewmaSimple[idGroup][i]);

        if (SLS[i] == minSLS)
        {
            countMin++;
            tmin = SLS[i] - (1.67 * SKO / sqrt(modelHotSimple[idGroup][i].count()));
            tmax = SLS[i] + (1.67 * SKO / sqrt(modelHotSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecGr[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);
            for(s = 0; s < countGr; s++)
                if (simpleLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecGr[idGroup][s] + 1);
                else str += tr("x%1").arg(vecGr[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleLamdasList[idGroup][i][s]);
            tempList = _getDeltaForLambda(simpleLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());
            groupsHMod[idGroup]->children.append( new NodeModel(
                                      groupsHMod[idGroup],
                                      "",
                                      tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMin),
                                      tr("%1").arg(SLS[i]),
                                      tr("(%1, %2)").arg(tmin).arg(tmax),
                                      tr("%1").arg(lll),
                                      str,
                                      ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }
        if (SLSM[i] == minSLSM)
        {
            countMinM++;
            tmin = SLSM[i] - (1.67 * SKOM / sqrt(modelMewmaSimple[idGroup][i].count()));
            tmax = SLSM[i] + (1.67 * SKOM / sqrt(modelMewmaSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecGr[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);

            for(s = 0; s < countGr; s++)
                if (simpleLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecGr[idGroup][s] + 1);
                else str += tr("x%1").arg(vecGr[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleLamdasList[idGroup][i][s]);

            tempList = _getDeltaForLambda(simpleLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());

            groupsMMod[idGroup]->children.append( new NodeModel(
                                           groupsMMod[idGroup],
                                           "",
                                           tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMinM),
                                           tr("%1").arg(SLSM[i]),
                                           tr("(%1, %2)").arg(tmin).arg(tmax),
                                           tr("%1").arg(lll),
                                           str,
                                           ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }

        SKO = __null; SKOM = __null;
    }
    countMin = __null; countMinM = __null;

    SLS.clear(); minSLS = __null; tmin = __null; tmax = __null; counts = __null; countGr = __null;
    SLSM.clear(); minSLSM = __null;
    i = __null; k = __null; s = __null;
    _delete(treeModProxyModel);treeModProxyModel = new QSortFilterProxyModel(this);
    treeModProxyModel->setSourceModel(modelCorrModel);
    treeModProxyModel->setFilterRole(Qt::DisplayRole);
    treeCorrModel->reset();
    treeCorrModel->setModel(treeModProxyModel);treeCorrModel->expandAll();
}

void MainWin::updateModelSimpleW(const int &idGroup, const int &idIter)
{
    int counts = idIter + 1, countGr = vecGr[idGroup].count(), i = 0, k = 0, s = 0;

    float tmin = 0., tmax = 0., minSLS = 0., minSLSM = 0., SKO = 0., SKOM = 0.;
    vecF SLS(counts), SLSM(counts);

    minSLS = _mean1V(modelHotWSimple[idGroup][0]);minSLSM = _mean1V(modelMewmaWSimple[idGroup][0]);
    SLS[0] = minSLS;SLSM[0] = minSLSM;
    for(i = 1; i < counts; i++)
    {
        SLS[i] = _mean1V(modelHotWSimple[idGroup][i]);
        SLSM[i] = _mean1V(modelMewmaWSimple[idGroup][i]);

        if (SLS[i] <= minSLS) minSLS = SLS[i];
        if (SLSM[i] <= minSLSM) minSLSM = SLSM[i];
    }

    float countMin = 0., countMinM = 0.;
    for(i = 0; i < counts; i++)
    {
        SKO = _sko1V(modelHotSimple[idGroup][i]);
        SKOM = _sko1V(modelMewmaSimple[idGroup][i]);

        if (SLS[i] == minSLS)
        {
            countMin++;
            tmin = SLS[i] - (1.67 * SKO / sqrt(modelHotWSimple[idGroup][i].count()));
            tmax = SLS[i] + (1.67 * SKO / sqrt(modelHotWSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecGr[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);
            for(s = 0; s < countGr; s++)
                if (simpleLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecGr[idGroup][s] + 1);
                else str += tr("x%1").arg(vecGr[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleLamdasList[idGroup][i][s]);
            tempList = _getDeltaForLambda(simpleLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());
            groupsHWMod[idGroup]->children.append( new NodeModel(
                                          groupsHWMod[idGroup],
                                          "",
                                          tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMin),
                                          tr("%1").arg(SLS[i]),
                                          tr("(%1, %2)").arg(tmin).arg(tmax),
                                          tr("%1").arg(lll),
                                          str,
                                          ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }
        if (SLSM[i] == minSLSM)
        {
            countMinM++;
            tmin = SLSM[i] - (1.67 * SKOM / sqrt(modelMewmaWSimple[idGroup][i].count()));
            tmax = SLSM[i] + (1.67 * SKOM / sqrt(modelMewmaWSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecGr[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);

            for(s = 0; s < countGr; s++)
                if (simpleLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecGr[idGroup][s] + 1);
                else str += tr("x%1").arg(vecGr[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleLamdasList[idGroup][i][s]);

            tempList = _getDeltaForLambda(simpleLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());

            groupsMWMod[idGroup]->children.append( new NodeModel(
                                          groupsMWMod[idGroup],
                                          "",
                                          tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMinM),
                                          tr("%1").arg(SLSM[i]),
                                          tr("(%1, %2)").arg(tmin).arg(tmax),
                                          tr("%1").arg(lll),
                                          str,
                                          ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }

        SKO = __null; SKOM = __null;
    }
    countMin = __null; countMinM = __null;

    SLS.clear(); minSLS = __null; tmin = __null; tmax = __null; counts = __null; countGr = __null;
    SLSM.clear(); minSLSM = __null;
    i = __null; k = __null; s = __null;
    _delete(treeModProxyModel);treeModProxyModel = new QSortFilterProxyModel(this);
    treeModProxyModel->setSourceModel(modelCorrModel);
    treeModProxyModel->setFilterRole(Qt::DisplayRole);
    treeCorrModel->reset();
    treeCorrModel->setModel(treeModProxyModel);treeCorrModel->expandAll();
}

void MainWin::createModelThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    Vars->setGroups(vecGr);
    int ppp = Vars->getCountModelCorr(), i = 0, k = 0;

    _delete(modelCorrModel);modelCorrModel = new TreeModelling(this);
    modelCorrModel->setRootNode(InitTreeModelling());
    _delete(treeModProxyModel);treeModProxyModel = new QSortFilterProxyModel(this);
    treeModProxyModel->setSourceModel(modelCorrModel);
    treeModProxyModel->setFilterRole(Qt::DisplayRole);
    treeCorrModel->reset();
    treeCorrModel->setModel(treeModProxyModel);treeCorrModel->expandAll();

    countItersModelSimple = 0;
    countMSimpleH = 0;
    //modelSimplePrB->setMaximum(2 * ppp * (Vars->getFileCountButStr() + Vars->getFileCountNorm()));
    qRegisterMetaType<vecII>("vecII");


    modelThread.clear(); modelNThread.clear(); modelThreadW.clear(); modelNThreadW.clear();
    modelThread.resize(vecGr.count()); modelNThread.resize(vecGr.count()); modelThreadW.resize(vecGr.count()); modelNThreadW.resize(vecGr.count());
    for (i = 0; i < vecGr.count(); i++)
    {
        modelThread[i] = false;
        modelNThread[i] = false;
        modelThreadW[i] = false;
        modelNThreadW[i] = false;
    }
    modelHotWSimple.clear(); modelMewmaWSimple.clear(); modelHotSimple.clear(); modelMewmaSimple.clear();
    modelHotWSimple.resize(vecGr.count()); modelMewmaWSimple.resize(vecGr.count()); modelHotSimple.resize(vecGr.count()); modelMewmaSimple.resize(vecGr.count());
    simpleLamdasList.clear(); simpleLamdasList.resize(vecGr.count());

    int llll = _getCountVars(Vars->getFileCountVars()), countPrb = 0;

    for (i = 0; i < vecGr.count(); i++)
    {
        int countComb = _getCountVars(vecGr[i].count());
        if ( (ppp >= countComb) && (llll == ppp) )
        {
            //if
            {
                int kkkk = vecGr.count() - 1;

                if (kkkk == i)
                {
                    vecI listModelling = _genRandomInt(1, countComb, countComb);
                    int countIter = listModelling.count();

                    simpleLamdasList[kkkk].resize(countIter);

                    modelHotSimple[i].resize(countIter);
                    modelMewmaSimple[i].resize(countIter);
                    modelHotWSimple[i].resize(countIter);
                    modelMewmaWSimple[i].resize(countIter);

                    countPrb = countIter * (Vars->getFileCountButStr() + Vars->getFileCountNorm());
                    modelSimplePrB->setMaximum(countPrb);

                    for (k = 0; k < countIter; k++)
                    {
                        simpleLamdasList[i][k] = _getDexToBin(listModelling[k], vecGr[i].count());
                        Vars->setListVar(simpleLamdasList[i][k]);


                        modellingThread *modellThread = new modellingThread(Vars, i, k);

                        QObject::connect(modellThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setModelBtRun(QString)));
                        QObject::connect(modellThread, SIGNAL(processChanged(int)), this, SLOT(setModelPrBRun(int)));
                        QObject::connect(modellThread, SIGNAL(getLines(const vecLines*,int,int)), this, SLOT(setModelRes(const vecLines*,int,int)));
                        QObject::connect(modellThread, SIGNAL(getLinesW(const vecLines*,int,int)), this, SLOT(setModelResW(const vecLines*,int,int)));

                        modellingNThread *modellNThread = new modellingNThread(Vars, i, k);

                        QObject::connect(modellNThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setModelBtRun(QString)));
                        QObject::connect(modellNThread, SIGNAL(processChanged(int)), this, SLOT(setModelPrBRun(int)));
                        QObject::connect(modellNThread, SIGNAL(getLines(const vecLines*,int,int)), this, SLOT(setModelNRes(const vecLines*,int,int)));

                        QObject::connect(modellNThread, SIGNAL(getLinesW(const vecLines*,int,int)), this, SLOT(setModelNResW(const vecLines*,int,int)));

                        modellThread->start(QThread::LowPriority);
                        modellNThread->start(QThread::LowPriority);
                    }
                    listModelling.clear(); countIter = __null;
                }
                else{}

                kkkk = __null;
            }
        }
        else
        {
            countComb = ppp;
            vecI listModelling = _genRandomInt(1, countComb, countComb);
            int countIter = listModelling.count();

            simpleLamdasList[i].resize(countIter);

            modelHotSimple[i].resize(countIter);
            modelMewmaSimple[i].resize(countIter);
            modelHotWSimple[i].resize(countIter);
            modelMewmaWSimple[i].resize(countIter);

            countPrb += countIter * (Vars->getFileCountButStr() + Vars->getFileCountNorm());
            modelSimplePrB->setMaximum(countPrb);

            for (k = 0; k < listModelling.count(); k++)
            {
                simpleLamdasList[i][k] = _getDexToBin(listModelling[k], vecGr[i].count());
                Vars->setListVar(simpleLamdasList[i][k]);


                modellingThread *modellThread = new modellingThread(Vars, i, k);

                QObject::connect(modellThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setModelBtRun(QString)));
                QObject::connect(modellThread, SIGNAL(processChanged(int)), this, SLOT(setModelPrBRun(int)));
                QObject::connect(modellThread, SIGNAL(getLines(const vecLines*,int,int)), this, SLOT(setModelRes(const vecLines*,int,int)));
                QObject::connect(modellThread, SIGNAL(getLinesW(const vecLines*,int,int)), this, SLOT(setModelResW(const vecLines*,int,int)));

                modellingNThread *modellNThread = new modellingNThread(Vars, i, k);

                QObject::connect(modellNThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setModelBtRun(QString)));
                QObject::connect(modellNThread, SIGNAL(processChanged(int)), this, SLOT(setModelPrBRun(int)));
                QObject::connect(modellNThread, SIGNAL(getLines(const vecLines*,int,int)), this, SLOT(setModelNRes(const vecLines*,int,int)));
                QObject::connect(modellNThread, SIGNAL(getLinesW(const vecLines*,int,int)), this, SLOT(setModelNResW(const vecLines*,int,int)));

                modellThread->start(QThread::LowPriority);
                modellNThread->start(QThread::LowPriority);
            }
            listModelling.clear(); countIter = __null;
        }
        countComb = __null;
    }
    i = __null; k = __null; llll = __null; countPrb = __null;
}



void MainWin::createLinesModCl()
{
    _delete(modelClModel);modelClModel = new TreeModelling(this);
    modelClModel->setRootNode(InitTreeModellingCl());

    _delete(treeModProxyModelCl);treeModProxyModelCl = new QSortFilterProxyModel(this);
    treeModProxyModelCl->setSourceModel(modelClModel);
    treeModProxyModelCl->setFilterRole(Qt::DisplayRole);

    _delete(treeClModel);treeClModel = new QTreeView(ClTabModelling);
    treeClModel->setModel(treeModProxyModelCl);
    treeClModel->expandAll();
    treeClModel->resizeColumnToContents(1);
    treeClModel->resizeColumnToContents(2);
    treeClModel->resizeColumnToContents(3);
    treeClModel->resizeColumnToContents(4);
    treeClModel->resizeColumnToContents(5);

    treeClModel->header()->setDefaultAlignment(Qt::AlignCenter);
    treeClModel->header()->setMovable(true);
    treeClModel->header()->setResizeMode(QHeaderView::ResizeToContents);
    treeClModel->header()->setResizeMode(QHeaderView::Interactive);
    treeClModel->setFont(QFont("Arial", 10, QFont::Bold));

    _delete(modelSimplePrBCl); modelSimplePrBCl = new QProgressBar;
    modelSimplePrBCl->setOrientation(Qt::Vertical);
    //modelSimplePrB->setValue(50);


    //QGroupBox *modelGrB = new QGroupBox(tr("������������ �������� ������� ���� ����� ��� ������� ���������"), tabsCor);

    QGroupBox *modelGrB = new QGroupBox(tr("����� ���������� ��� �������:"), ClTabModelling);

    QLabel *modelLb = new QLabel;
    modelLb->setText(tr("������ ������������ ���������� �������� ������� ���� ����� � �������:"));
    modelLb->setFont(QFont("Arial", 10, QFont::Bold));

    QSpinBox *modelSpB = new QSpinBox;
    connect(modelSpB, SIGNAL(valueChanged(int)), Vars, SLOT(setCountModelCl(int)));
    modelSpB->setMaximum(_getCountVars(Vars->getFileCountVars()));
    modelSpB->setValue(_getCountVars(Vars->getFileCountVars()));

    QHBoxLayout *layModel = new QHBoxLayout(CorrTabModelling);
    layModel->addWidget(modelLb, 1, Qt::AlignRight | Qt::AlignVCenter);
    layModel->addWidget(modelSpB, 1, Qt::AlignLeft | Qt::AlignVCenter);
    modelGrB->setLayout(layModel);

    QHBoxLayout *laySimpleModel = new QHBoxLayout(ClTabModelling);
    laySimpleModel->addWidget(treeClModel, 10);
    laySimpleModel->addWidget(modelSimplePrBCl, 0);


    _delete(modelBtRunCl); modelBtRunCl = new QPushButton(tr("��������� ���������� ������� ���� ����� ��� �������� ���������"));
    modelBtRunCl->setFont(QFont("Arial", 11, QFont::Bold));
    QObject::connect(modelBtRunCl, SIGNAL(clicked()), this, SLOT(createModelClThread()));

    QSplitter *split = new QSplitter(Qt::Horizontal, ClTabModelling);
    split->setLayout(laySimpleModel);split->setLayoutDirection(Qt::LeftToRight);



    _delete(layClModel);layClModel = new QVBoxLayout(ClTabModelling);

    layClModel->addWidget(modelGrB, 1);
    layClModel->addWidget(split, 10);
    layClModel->addWidget(modelBtRunCl, 1);



    ClTabModelling->setLayout(layClModel);
}

NodeModel* MainWin::InitTreeModellingCl(){

    vecII groupVar = vecClas;

    int countGroups = groupVar.count();

    NodeModel *_rootModCl = new NodeModel();

    NodeModel *group1 = new NodeModel( _rootModCl,  tr("1"), "", "", "", "", "", GROUP);
    _rootModCl->children.append(group1);

        NodeModel *group11 = new NodeModel( group1,  tr("1.1"), tr("HOTELLING"), "", "", "", "", GROUP);
        group1->children.append(group11);

        groupsHModCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHModCl[i] = new NodeModel( group11,  tr("1.1.%1").arg(i+1), str, "", "", "", "", GROUP);
            group11->children.append(groupsHModCl[i]);
            str = "";
        }

        NodeModel *group12 = new NodeModel( group1, tr("1.2"), tr("MEWMA"), "", "", "", "", GROUP);
        group1->children.append(group12);

        groupsMModCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMModCl[i] = new NodeModel( group12, tr("1.2.%1").arg(i+1), str, "", "", "", "", GROUP);
            group12->children.append(groupsMModCl[i]);
            str = "";
        }

        NodeModel *group13 = new NodeModel( group1, tr("1.3"), tr("HOTELLING with the warning boundary"), "", "", "", "", GROUP);
        group1->children.append(group13);

        groupsHWModCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHWModCl[i] = new NodeModel( group13, tr("1.3.%1").arg(i+1), str, "", "", "", "", GROUP);
            group13->children.append(groupsHWModCl[i]);
            str = "";
        }

        NodeModel *group14 = new NodeModel( group1, tr("1.4"), tr("MEWMA with the warning boundary"), "", "", "", "", GROUP);
        group1->children.append(group14);

        groupsMWModCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMWModCl[i] = new NodeModel( group14, tr("1.4.%1").arg(i+1), str, "", "", "", "", GROUP);
            group14->children.append(groupsMWModCl[i]);
            str = "";
        }

    groupVar.clear();
    countGroups = __null;
    return _rootModCl;
}

void MainWin::createModelClThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    Vars->setGroups(vecClas);
    int ppp = Vars->getCountModelCorr(), i = 0, k = 0;

    _delete(modelClModel);modelClModel = new TreeModelling(this);
    modelClModel->setRootNode(InitTreeModellingCl());

    _delete(treeModProxyModelCl);treeModProxyModelCl = new QSortFilterProxyModel(this);
    treeModProxyModelCl->setSourceModel(modelClModel);
    treeModProxyModelCl->setFilterRole(Qt::DisplayRole);
    treeClModel->reset();
    treeClModel->setModel(treeModProxyModelCl);treeClModel->expandAll();

    countItersModelClSimple = 0;
    //countMSimpleHCl = 0;

    qRegisterMetaType<vecII>("vecII");


    modelClThread.clear(); modelClNThread.clear(); modelClThreadW.clear(); modelClNThreadW.clear();
    modelClThread.resize(vecClas.count()); modelClNThread.resize(vecClas.count()); modelClThreadW.resize(vecClas.count()); modelClNThreadW.resize(vecClas.count());
    for (i = 0; i < vecClas.count(); i++)
    {
        modelClThread[i] = false;
        modelClNThread[i] = false;
        modelClThreadW[i] = false;
        modelClNThreadW[i] = false;
    }

    modelClHotWSimple.clear(); modelClMewmaWSimple.clear(); modelClHotSimple.clear(); modelClMewmaSimple.clear();
    modelClHotWSimple.resize(vecClas.count()); modelClMewmaWSimple.resize(vecClas.count()); modelClHotSimple.resize(vecClas.count()); modelClMewmaSimple.resize(vecClas.count());
    simpleClLamdasList.clear();simpleClLamdasList.resize(vecClas.count());

    int countIter = 0, countPrb = 0;

    for(int i = 0; i < vecClas.count(); i++)
    {
        int countComb = _getCountVars(vecClas[i].count());
        if (ppp < countComb) countComb = ppp;

        vecI listModelling = _genRandomInt(1, countComb, countComb);
        int countIter = listModelling.count();

        simpleClLamdasList[i].resize(countIter);

        modelClHotSimple[i].resize(countIter);
        modelClMewmaSimple[i].resize(countIter);
        modelClHotWSimple[i].resize(countIter);
        modelClMewmaWSimple[i].resize(countIter);

        countPrb += countIter * (Vars->getFileCountButStr() + Vars->getFileCountNorm());
        modelSimplePrBCl->setMaximum(countPrb);

        for (k = 0; k < listModelling.count(); k++)
        {
            simpleClLamdasList[i][k] = _getDexToBin(listModelling[k], vecClas[i].count());
            Vars->setListVar(simpleClLamdasList[i][k]);


            modellingThread *modellClThread = new modellingThread(Vars, i, k);

            QObject::connect(modellClThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setModelClBtRun(QString)));
            QObject::connect(modellClThread, SIGNAL(processChanged(int)), this, SLOT(setModelClPrBRun(int)));
            QObject::connect(modellClThread, SIGNAL(getLines(const vecLines*,int,int)), this, SLOT(setModelClRes(const vecLines*,int,int)));
            QObject::connect(modellClThread, SIGNAL(getLinesW(const vecLines*,int,int)), this, SLOT(setModelClResW(const vecLines*,int,int)));

            modellingNThread *modellNClThread = new modellingNThread(Vars, i, k);

            QObject::connect(modellNClThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setModelClBtRun(QString)));
            QObject::connect(modellNClThread, SIGNAL(processChanged(int)), this, SLOT(setModelClPrBRun(int)));
            QObject::connect(modellNClThread, SIGNAL(getLines(const vecLines*,int,int)), this, SLOT(setModelClNRes(const vecLines*,int,int)));
            QObject::connect(modellNClThread, SIGNAL(getLinesW(const vecLines*,int,int)), this, SLOT(setModelClNResW(const vecLines*,int,int)));

            modellClThread->start(QThread::NormalPriority);
            modellNClThread->start(QThread::NormalPriority);
        }
    }
    countIter = __null;countPrb = __null;
}

void MainWin::setModelClBtRun(const QString &str)
{
    modelBtRunCl->setText(str);
}

void MainWin::setModelClPrBRun(const int &in_iter)
{
    countItersModelClSimple++;
    modelSimplePrBCl->setValue(countItersModelClSimple);
}

void MainWin::setModelClRes(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelClHotSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelClMewmaSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelClHotSimple[idGroup].count() - 1))
    {
        modelClThread[idGroup] = true;
        if (modelClThread[idGroup] && modelClNThread[idGroup]) updateModelClSimple(idGroup, idIter);
    }
}
void MainWin::setModelClResW(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelClHotWSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelClMewmaWSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelClHotWSimple[idGroup].count() - 1))
    {
        modelClThreadW[idGroup] = true;
        if (modelClThreadW[idGroup] && modelClNThreadW[idGroup]) updateModelClSimpleW(idGroup, idIter);
    }
}

void MainWin::setModelClNRes(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelClHotSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelClMewmaSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelClHotSimple[idGroup].count() - 1))
    {
        modelClNThread[idGroup] = true;
        if (modelClThread[idGroup] && modelClNThread[idGroup]) updateModelClSimple(idGroup, idIter);
    }
}
void MainWin::setModelClNResW(const vecLines *in, const int &idGroup, const int &idIter)
{
    modelClHotWSimple[idGroup][idIter] += in->Line_SeriesHArray[idGroup];
    modelClMewmaWSimple[idGroup][idIter] += in->Line_SeriesWArray[idGroup];

    if (idIter == (modelClHotWSimple[idGroup].count() - 1))
    {
        modelClNThreadW[idGroup] = true;
        if (modelClThreadW[idGroup] && modelClNThreadW[idGroup]) updateModelClSimpleW(idGroup, idIter);
    }
}

void MainWin::updateModelClSimple(const int &idGroup, const int &idIter)
{
    int counts = idIter + 1, countGr = vecClas[idGroup].count(), i = 0, k = 0, s = 0;

    float tmin = 0., tmax = 0., minSLS = 0., minSLSM = 0., SKO = 0., SKOM = 0.;
    vecF SLS(counts), SLSM(counts);

    minSLS = _mean1V(modelClHotSimple[idGroup][0]);
    minSLSM = _mean1V(modelClMewmaSimple[idGroup][0]);
    SLS[0] = minSLS;SLSM[0] = minSLSM;
    for(i = 1; i < counts; i++)
    {
        SLS[i] = _mean1V(modelClHotSimple[idGroup][i]);
        SLSM[i] = _mean1V(modelClMewmaSimple[idGroup][i]);

        if (SLS[i] <= minSLS) minSLS = SLS[i];
        if (SLSM[i] <= minSLSM) minSLSM = SLSM[i];
    }

    float countMin = 0., countMinM = 0.;
    for(i = 0; i < counts; i++)
    {
        SKO = _sko1V(modelClHotSimple[idGroup][i]);
        SKOM = _sko1V(modelClMewmaSimple[idGroup][i]);

        if (SLS[i] == minSLS)
        {
            countMin++;
            tmin = SLS[i] - (1.67 * SKO / sqrt(modelClHotSimple[idGroup][i].count()));
            tmax = SLS[i] + (1.67 * SKO / sqrt(modelClHotSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecClas[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);
            for(s = 0; s < countGr; s++)
                if (simpleClLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecClas[idGroup][s] + 1);
                else str += tr("x%1").arg(vecClas[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleClLamdasList[idGroup][i][s]);
            tempList = _getDeltaForLambda(simpleClLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());
            groupsHModCl[idGroup]->children.append( new NodeModel(
                                      groupsHModCl[idGroup],
                                      "",
                                      tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMin),
                                      tr("%1").arg(SLS[i]),
                                      tr("(%1, %2)").arg(tmin).arg(tmax),
                                      tr("%1").arg(lll),
                                      str,
                                      ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }
        if (SLSM[i] == minSLSM)
        {
            countMinM++;
            tmin = SLSM[i] - (1.67 * SKOM / sqrt(modelClMewmaSimple[idGroup][i].count()));
            tmax = SLSM[i] + (1.67 * SKOM / sqrt(modelClMewmaSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecClas[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);

            for(s = 0; s < countGr; s++)
                if (simpleClLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecClas[idGroup][s] + 1);
                else str += tr("x%1").arg(vecClas[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleClLamdasList[idGroup][i][s]);

            tempList = _getDeltaForLambda(simpleClLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());

            groupsMModCl[idGroup]->children.append( new NodeModel(
                                           groupsMModCl[idGroup],
                                           "",
                                           tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMinM),
                                           tr("%1").arg(SLSM[i]),
                                           tr("(%1, %2)").arg(tmin).arg(tmax),
                                           tr("%1").arg(lll),
                                           str,
                                           ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }

        SKO = __null; SKOM = __null;
    }
    countMin = __null; countMinM = __null;

    SLS.clear(); minSLS = __null; tmin = __null; tmax = __null; counts = __null; countGr = __null;
    SLSM.clear(); minSLSM = __null;
    i = __null; k = __null; s = __null;

    _delete(treeModProxyModelCl);treeModProxyModelCl = new QSortFilterProxyModel(this);
    treeModProxyModelCl->setSourceModel(modelClModel);
    treeModProxyModelCl->setFilterRole(Qt::DisplayRole);
    treeClModel->reset();
    treeClModel->setModel(treeModProxyModelCl);treeClModel->expandAll();
}

void MainWin::updateModelClSimpleW(const int &idGroup, const int &idIter)
{
    int counts = idIter + 1, countGr = vecClas[idGroup].count(), i = 0, k = 0, s = 0;

    float tmin = 0., tmax = 0., minSLS = 0., minSLSM = 0., SKO = 0., SKOM = 0.;
    vecF SLS(counts), SLSM(counts);

    minSLS = _mean1V(modelClHotWSimple[idGroup][0]);minSLSM = _mean1V(modelClMewmaWSimple[idGroup][0]);
    SLS[0] = minSLS;SLSM[0] = minSLSM;
    for(i = 1; i < counts; i++)
    {
        SLS[i] = _mean1V(modelClHotWSimple[idGroup][i]);
        SLSM[i] = _mean1V(modelClMewmaWSimple[idGroup][i]);

        if (SLS[i] <= minSLS) minSLS = SLS[i];
        if (SLSM[i] <= minSLSM) minSLSM = SLSM[i];
    }

    float countMin = 0., countMinM = 0.;
    for(i = 0; i < counts; i++)
    {
        SKO = _sko1V(modelClHotWSimple[idGroup][i]);
        SKOM = _sko1V(modelClMewmaWSimple[idGroup][i]);

        if (SLS[i] == minSLS)
        {
            countMin++;
            tmin = SLS[i] - (1.67 * SKO / sqrt(modelClHotWSimple[idGroup][i].count()));
            tmax = SLS[i] + (1.67 * SKO / sqrt(modelClHotWSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecClas[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);
            for(s = 0; s < countGr; s++)
                if (simpleClLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecClas[idGroup][s] + 1);
                else str += tr("x%1").arg(vecClas[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleClLamdasList[idGroup][i][s]);
            tempList = _getDeltaForLambda(simpleClLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());
            groupsHWModCl[idGroup]->children.append( new NodeModel(
                                          groupsHWModCl[idGroup],
                                          "",
                                          tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMin),
                                          tr("%1").arg(SLS[i]),
                                          tr("(%1, %2)").arg(tmin).arg(tmax),
                                          tr("%1").arg(lll),
                                          str,
                                          ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }
        if (SLSM[i] == minSLSM)
        {
            countMinM++;
            tmin = SLSM[i] - (1.67 * SKOM / sqrt(modelClMewmaWSimple[idGroup][i].count()));
            tmax = SLSM[i] + (1.67 * SKOM / sqrt(modelClMewmaWSimple[idGroup][i].count()));
            QString str = "";
            vecFF need_data = _CopyNeedColsFromArray2D(Vars->getData(), vecClas[idGroup]);
            vecFF corr = _correlation(need_data);
            vecF tempList, listSKO = _sko(need_data);

            for(s = 0; s < countGr; s++)
                if (simpleClLamdasList[idGroup][i][s] != 0) str += tr("  X%1  ").arg(vecClas[idGroup][s] + 1);
                else str += tr("x%1").arg(vecClas[idGroup][s] + 1);
            str += tr(" :");

            for(s = 0; s < countGr; s++)
                str += tr(" %1").arg(simpleClLamdasList[idGroup][i][s]);

            tempList = _getDeltaForLambda(simpleClLamdasList[idGroup][i], corr, listSKO);

            float lll = _getNonCentralVar(need_data, tempList, Vars->getFileCountStepV());

            groupsMWModCl[idGroup]->children.append( new NodeModel(
                                          groupsMWModCl[idGroup],
                                          "",
                                          tr("1.1.%1  �%2").arg(idGroup + 1).arg(countMinM),
                                          tr("%1").arg(SLSM[i]),
                                          tr("(%1, %2)").arg(tmin).arg(tmax),
                                          tr("%1").arg(lll),
                                          str,
                                          ELEMENT  ) );
            tmin = __null; tmax = __null; lll = __null;
            str = "";listSKO.clear();tempList.clear();corr.clear();need_data.clear();
        }

        SKO = __null; SKOM = __null;
    }
    countMin = __null; countMinM = __null;

    SLS.clear(); minSLS = __null; tmin = __null; tmax = __null; counts = __null; countGr = __null;
    SLSM.clear(); minSLSM = __null;
    i = __null; k = __null; s = __null;

    _delete(treeModProxyModelCl);treeModProxyModelCl = new QSortFilterProxyModel(this);
    treeModProxyModelCl->setSourceModel(modelClModel);
    treeModProxyModelCl->setFilterRole(Qt::DisplayRole);
    treeClModel->reset();
    treeClModel->setModel(treeModProxyModelCl);treeClModel->expandAll();
}

void MainWin::setLambdaCbCl(const bool &in)
{
    Vars->setForDelta(in);
    if (in)
    {
        vecFF in_data = Vars->getData();
        vecF result(vecClas.count());
        vecLamda fff = _getGroupsRegreNonCentral(vecClas, in_data, Vars->getFileCountStepV());

        for (int i = 0; i < vecClas.count(); i++)
            result[i] = fff[i].Lamda;

        in_data.clear(); fff.clear();
        lbLambdaCl->setText(tr(" l = %1").arg(result[result.count() - 1]));
        Vars->setLambdaClaster(result);
        result.clear();
    }
}

void MainWin::setLbLambdaCl(const int &count)
{
    vecI changeList = _genRandomInt(0, Vars->getFileCountVars() - 1, count);

    vecF listChange(Vars->getFileCountVars());

    for (int i = 0; i < listChange.count(); i++)
        for (int j = 0; j < changeList.count(); j++)
            if (changeList[j] == i) listChange[i] = 1.0;

    Vars->setListVar(listChange);
    listChange.clear();changeList.clear();
    resetLbLambdaCl();
}

void MainWin::setListBLambdaCl(const QModelIndex &index)
{
    vecF listChange = Vars->getListVar();

    float fff = listModelCl->data(listModelCl->index(index.row(), 1, index), Qt::EditRole).toFloat();
    listChange[index.row()] = fff;


    Vars->setListVar(listChange);

    resetLbLambdaCl();
    lbLambdaCl->setFocus();
}

void MainWin::resetLbLambdaCl()
{
    vecFF in_data = Vars->getData(), corr = _correlation(in_data);
    vecF SKO = _sko(in_data), listChange = Vars->getListVar(), result(vecClas.count());

    for (int i = 0; i < Vars->getFileCountVars(); i++)
    {
        listModelCl->setData(listModelCl->index(i, 0, QModelIndex()), tr("X%1").arg(i + 1), Qt::EditRole);
        listModelCl->setData(listModelCl->index(i, 1, QModelIndex()), tr("%1").arg(listChange[i]), Qt::EditRole);
    }

    listLinesVarCl->reset();
    listLinesVarCl->setModel(listModelCl);


    for (int i = 0; i < vecClas.count(); i++)
    {
        vecFF temp_data = _CopyNeedColsFromArray2D(in_data, vecClas[i]);
        vecF temp_sko = _CopyNeedColsFromArray1D(SKO, vecClas[i]), temp_list = _CopyNeedColsFromArray1D(listChange, vecClas[i]);
        vecFF corr = _correlation(temp_data);
        vecF delta = _getDeltaForLambda(temp_list, corr, temp_sko);
        result[i] = _getNonCentralVar(temp_data, delta, Vars->getFileCountStepV());
        corr.clear();temp_data.clear();temp_sko.clear();temp_list.clear();delta.clear();
    }
    SKO.clear();in_data.clear();listChange.clear();

    lbLambdaCl->setText(tr(" l = %1").arg(result[result.count() - 1]));
    Vars->setLambdaClaster(result);
    result.clear();
}



void MainWin::createLinesSerCl(const int &countGroups)
{
    //*********����� ���������*************************************************
    //������ ��� ����������� �������
    _delete(linesModelCLB); linesModelCLB = new LinesSeriesModel(this, "Lines");
    _delete(linesModelCLBW); linesModelCLBW = new LinesSeriesModel(this, "Lines");
    _delete(linesModelCLN); linesModelCLN = new LinesSeriesModel(this, "Lines");
    _delete(linesModelCLNW); linesModelCLNW = new LinesSeriesModel(this, "Lines");
    _delete(listModelCl); listModelCl = new ListChangedModel(this, "ListChanged");
    _delete(listClLambda); listClLambda = new ListChangedModel(this, "ListLambda");
    vecSS tempm = _createS(2, Vars->getFileCountVars());
    listModelCl->toModel(tempm);
    listClLambda->toModel(tempm);
    tempm.clear();

    //calc_clasters(3);

    //-----������ ��� ������ ����������----------------------------------------

    QGroupBox *lineGrB = new QGroupBox(tr("����� ����������:"), tabsCl);

    QGridLayout *linelay = new QGridLayout(lineGrB);

    QLabel *lblCl = new QLabel(tr(" ���������� ��������� : "));
    lblCl->setFont(QFont("Arial", 9, QFont::Bold));

    _delete(spbCl);
    spbCl = new QSpinBox;
    spbCl->setMaximum(Vars->getFileCountVars());
    spbCl->setToolTip(tr("������ ���������� ����� ����������"));
    spbCl->setStatusTip(tr("���������� ���������� ����� - ���������, � ������� ��� ��������� �������������� ������� ������������� (���� ����������� - \"������������� ����������\")."));
    QObject::connect(spbCl, SIGNAL(valueChanged(int)), this, SLOT(calc_clasters(int)));


    QLabel *lblL = new QLabel(tr("������������� ���������: "));
    lblL->setFont(QFont("Arial", 9, QFont::Bold));

    QDoubleSpinBox *spbCh = new QDoubleSpinBox;
    QObject::connect(spbCh, SIGNAL(valueChanged(double)), Vars, SLOT(setIntensity(double)));
    spbCh->setValue(0.1);
    spbCh->setMaximum(10.);
    spbCh->setToolTip(tr("������ ������������� ��������� ���������."));
    spbCh->setStatusTip(tr("������ ������������� ��������� ���������."));



    QLabel *lbLambdaTitle = new QLabel(tr(" �������� ���������������: "));
    lbLambdaTitle->setFont(QFont("Arial", 9, QFont::Bold));

    _delete(spbLambdaCl);spbLambdaCl = new QSpinBox;

    spbLambdaCl->setMaximum(Vars->getFileCountVars());
    spbLambdaCl->setToolTip(tr("������ ���������� ����������, ��� ������� �������� ��������������� ��������"));
    spbLambdaCl->setStatusTip(tr("������ ���������� ����������, ��� ������� �������� ��������������� ��������"));
    //QObject::connect(spbLambdaCl, SIGNAL(valueChanged(int)), this, SLOT(setLbLambdaCl(int)));

    _delete(lbLambdaCl);lbLambdaCl = new QLabel(tr(" l = "));
    lbLambdaCl->setFont(QFont("Arial", 9, QFont::Bold));
    lbLambdaCl->setToolTip(tr("�������� ��������� ��������������� ��� ��������� ��������� ���������� � ���������������� ����������"));
    lbLambdaCl->setStatusTip(tr("�������� ��������� ��������������� ��� ��������� ��������� ���������� � ���������������� ����������"));

    _delete(listLinesVarCl);listLinesVarCl = new QTreeView;
    listLinesVarCl->setSelectionMode(QAbstractItemView::SingleSelection);
    listLinesVarCl->setSelectionBehavior(QAbstractItemView::SelectRows);
    listLinesVarCl->setModel(listModelCorr);
    //connect( listLinesVarCl, SIGNAL(clicked(const QModelIndex &)), this, SLOT(setListBLambdaCl(const QModelIndex &)) );

    listLambdaClVars = _getListSimpleNoncentral(Vars->getData(), Vars->getFileCountStepV());

    for (int i = 0; i < listLambdaClVars.count(); i++)
    {
        listClLambda->setData(listClLambda->index(i, 0, QModelIndex()), tr("X%1").arg(listLambdaClVars[i].x() + 1), Qt::EditRole);
        listClLambda->setData(listClLambda->index(i, 1, QModelIndex()), tr("%1").arg(listLambdaClVars[i].y()), Qt::EditRole);
    }

    _delete(listLambdaCl);listLambdaCl = new QTreeView;
    listLambdaCl->setSelectionMode(QAbstractItemView::SingleSelection);
    listLambdaCl->setSelectionBehavior(QAbstractItemView::SelectRows);
    listLambdaCl->setModel(listClLambda);
    //listLambdaCl->sortByColumn(1, Qt::AscendingOrder);
    //listLambdaCl->setSortingEnabled(true);

    spbLambdaCl->setValue(Vars->getFileCountVars());

    _delete(createDendro);
    createDendro = new QPushButton;
    createDendro->setText(tr("������������"));
    createDendro->setToolTip(tr("������������ ����������� ����������� ������������ ��� ��������� ������ ����������."));
    createDendro->setStatusTip(tr("������������ ����������� ��� ��������� ������ ���������� �� ������ ������ ������������ ������������� (���� ����������� - \"������������� ����������\")"));
    QObject::connect(createDendro, SIGNAL(clicked()), this, SLOT(createDendrogramm()));

    QHBoxLayout *lineLambdaCl = new QHBoxLayout;
    lineLambdaCl->addWidget(lbLambdaCl);
    lineLambdaCl->addWidget(spbLambdaCl);

    QVBoxLayout *lineListVar = new QVBoxLayout;
    lineListVar->addWidget(listLinesVarCl);
    //lineListVar->addWidget(listLambdaCl);

    _delete(meanLambdaCl);meanLambdaCl = new QCheckBox;
    meanLambdaCl->setChecked(false);
    meanLambdaCl->setText(tr("�������������� ��������"));
    meanLambdaCl->setToolTip(tr("���������� �������������� �������� ��������� ��������������� � ��������������� ������� ����� ����� ��� ��������� ��������� ���������� ��� ���� ��������� ��������� ��������"));
    meanLambdaCl->setStatusTip(tr("���������� �������������� �������� ��������� ��������������� � ��������������� ������� ����� ����� ��� ��������� ��������� ���������� ��� ���� ��������� ��������� ��������"));
    connect( meanLambdaCl, SIGNAL(toggled(bool)), this, SLOT(setLambdaCbCl(bool)) );

    QVBoxLayout *lineSCorr = new QVBoxLayout;
    lineSCorr->addWidget(lblCl, 0, Qt::AlignCenter);
    lineSCorr->addWidget(spbCl, 0, Qt::AlignCenter);
    lineSCorr->addWidget(lblL, 0, Qt::AlignCenter);
    lineSCorr->addWidget(spbCh, 0, Qt::AlignCenter);
    //lineSCorr->addWidget(lbLambdaTitle, 0, Qt::AlignCenter);
    //lineSCorr->addLayout(lineLambdaCl);
    //lineSCorr->addWidget(meanLambdaCl, 0, Qt::AlignCenter);


    linelay->addLayout(lineSCorr, 0, 0, 1, 1);
    linelay->addWidget(createDendro, 1, 0, 1, 1);    
    linelay->addLayout(lineListVar, 2, 0, 4, 1);


    lineGrB->setLayout(linelay);

    spbCl->setValue(Vars->getCountClasters());
    spbLambdaCl->setValue(Vars->getFileCountVars());
    //setLbLambdaCl(Vars->getFileCountVars());

    //-----������ ��� �������� - �������----------------------------------------

    QGroupBox *lineBGrB = new QGroupBox(tr("��� �������� - �������:"), tabsCl);
    QGridLayout *lineBlay = new QGridLayout(lineBGrB);

    _delete(vvv5);
    vvv5 = new QTreeView; vvv5->setModel(linesModelCLB);vvv5->setFont(QFont("Arial", 10, QFont::Bold));
    vvv5->header()->setDefaultAlignment(Qt::AlignCenter);
    _delete(vvv6);
    vvv6 = new QTreeView; vvv6->setModel(linesModelCLBW);vvv6->setFont(QFont("Arial", 10, QFont::Bold));
    vvv6->header()->setDefaultAlignment(Qt::AlignCenter);

    QGroupBox *lineGrB1 = new QGroupBox(tr("������ ����������� ���� � ��������������� ��������:"));
    QHBoxLayout *lineBRun1 = new QHBoxLayout;
    lineBRun1->addWidget(vvv6);
    lineGrB1->setLayout(lineBRun1);

    lineBlay->addWidget(vvv5, 0, 0, 2, 5);
    lineBlay->addWidget(lineGrB1, 2, 0, 2, 5);

    /*_delete(butsLinesRunCL); butsLinesRunCL = new QPushButton(tr("Create"));
    QObject::connect(butsLinesRunCL, SIGNAL(clicked()), this, SLOT(createButsCLThread()));
    QHBoxLayout *lineBRun = new QHBoxLayout;
    lineBRun->addWidget(butsLinesRunCL, 1, Qt::AlignCenter);*/

    _delete(linesCLBPrB); linesCLBPrB = new QProgressBar;

    //lineBlay->addLayout(lineBRun, 4, 0, 1, 5);
    lineBlay->addWidget(linesCLBPrB, 5, 0, 1, 5);

    lineBGrB->setLayout(lineBlay);

    //-----������ ��� ����������...- �������-------------------------------------

    QGroupBox *lineNGrB = new QGroupBox(tr("��� ������� ������������ ����������� �������������"), tabsCl);

    QGridLayout *lineNlay = new QGridLayout(lineNGrB);

    _delete(vvv7);
    vvv7 = new QTreeView; vvv7->setModel(linesModelCLN);vvv7->setFont(QFont("Arial", 10, QFont::Bold));
    vvv7->header()->setDefaultAlignment(Qt::AlignCenter);
    _delete(vvv8);
    vvv8 = new QTreeView; vvv8->setModel(linesModelCLNW);vvv8->setFont(QFont("Arial", 10, QFont::Bold));
    vvv8->header()->setDefaultAlignment(Qt::AlignCenter);

    QGroupBox *lineNGrB1 = new QGroupBox(tr("������ ����������� ���� � ��������������� ��������:"));
    QHBoxLayout *lineNRun1 = new QHBoxLayout;
    lineNRun1->addWidget(vvv8);
    lineNGrB1->setLayout(lineNRun1);

    lineNlay->addWidget(vvv7, 0, 0, 2, 5);
    lineNlay->addWidget(lineNGrB1, 2, 0, 2, 5);

    /*_delete(normLinesRunCL); normLinesRunCL = new QPushButton(tr("Create"));
    QObject::connect(normLinesRunCL, SIGNAL(clicked()), this, SLOT(createNormCLThread()));
    QHBoxLayout *lineNRun = new QHBoxLayout;
    lineNRun->addWidget(normLinesRunCL, 1, Qt::AlignCenter);*/

    _delete(linesCLNPrB); linesCLNPrB = new QProgressBar;


    lineNlay->addWidget(linesCLNPrB, 5, 0 , 1, 5);

    lineNGrB->setLayout(lineNlay);

    //-----������ - QSplitter ��� ����������� �������� �������------------------
    _delete(butsLinesRunCL); butsLinesRunCL = new QPushButton(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
    butsLinesRunCL->setFont(QFont("Arial", 10, QFont::Bold));
    QObject::connect(butsLinesRunCL, SIGNAL(clicked()), this, SLOT(createButsCLThread()));

    QSplitter *sp_linesCl = new QSplitter(Qt::Horizontal, tabsCl);

    sp_linesCl->addWidget(lineGrB);sp_linesCl->setStretchFactor(0, 0);
    sp_linesCl->addWidget(lineBGrB);sp_linesCl->setStretchFactor(1, 4);
    sp_linesCl->addWidget(lineNGrB);sp_linesCl->setStretchFactor(2, 4);

    QVBoxLayout *lineSeriesCl = new QVBoxLayout;
    lineSeriesCl->addWidget(sp_linesCl);
    lineSeriesCl->addWidget(butsLinesRunCL);

    QTabWidget *clTabs = new QTabWidget(tabsCl);

    QWidget *clTab = new QWidget;
    clTab->setLayout(lineSeriesCl);

    QWidget *clMGKTab = new QWidget;

    QWidget *clRegreTab = new QWidget;

    clTabs->addTab(clTab, tr("������� � ���������� ��������"));
    clTabs->addTab(clMGKTab, tr("������� ����������"));
    clTabs->addTab(clRegreTab, tr("������������� �������"));

    clTabs->setTabShape(QTabWidget::Triangular);

    connect( clTabs, SIGNAL(currentChanged(int)), Vars, SLOT(setModeChanged(int)) );

    QVBoxLayout *allcl = new QVBoxLayout;
    allcl->addWidget(clTabs);

    tabsCl->setLayout(allcl);


}

void MainWin::deleteRowCl()
{
    int hhh = iClaster.row(), ggg = tableviewCl->selectionModel()->currentIndex().row();
    groupsHCl[hhh]->children.remove(ggg, 1);
    groupsMCl[hhh]->children.remove(ggg, 1);
    groupsHWCl[hhh]->children.remove(ggg, 1);
    groupsMWCl[hhh]->children.remove(ggg, 1);
    _delete(treeProxyModelCl);treeProxyModelCl = new QSortFilterProxyModel(this);
    treeProxyModelCl->setSourceModel(mmodelCl);
    treeProxyModelCl->setFilterRole(Qt::DisplayRole);
    treeProxyModelCl->setFilterKeyColumn(5);
    treeProxyModelCl->setFilterFixedString("1"); //������ ��� ���������

    _delete(tableProxyModelCl);tableProxyModelCl = new QSortFilterProxyModel(this);
    tableProxyModelCl->setSourceModel(mmodelCl);

    treeviewCl->reset();treeviewCl->setModel(treeProxyModelCl);treeviewCl->expandAll();
    tableviewCl->reset();tableviewCl->setModel(tableProxyModelCl);
}

void MainWin::createLinesSCl()
{
    //*********�������� ���������*************************************************
    /*
    _delete(mmodelCl); mmodelCl = new TreeModel(this);
    mmodelCl->setRootNode(InitTreeCl());

    countGraphsCl = 0;

    _delete(treeProxyModelCl);treeProxyModelCl = new QSortFilterProxyModel(this);
    treeProxyModelCl->setSourceModel(mmodelCl);
    treeProxyModelCl->setFilterRole(Qt::DisplayRole);
    treeProxyModelCl->setFilterKeyColumn(5);
    treeProxyModelCl->setFilterFixedString("1"); //������ ��� ���������

    _delete(tableProxyModelCl);tableProxyModelCl = new QSortFilterProxyModel(this);
    tableProxyModelCl->setSourceModel(mmodelCl);

    _delete(treeviewCl);treeviewCl = new QTreeView(ClasterTabs);
    treeviewCl->setSelectionMode(QAbstractItemView::SingleSelection);
    treeviewCl->setSelectionBehavior(QAbstractItemView::SelectRows);
    treeviewCl->setModel(treeProxyModelCl);
    treeviewCl->hideColumn(2);
    treeviewCl->hideColumn(3);
    treeviewCl->hideColumn(4);
    treeviewCl->hideColumn(5);
    treeviewCl->expandAll();treeviewCl->header()->hide();
    treeviewCl->header()->setStretchLastSection(true);


    checkGraphsCl = new QCheckBox(CorrTabs);
    checkGraphsCl->setText(tr("����� ���������� ��������"));

    QObject::connect(checkGraphsCl, SIGNAL(toggled(bool)), this, SLOT(setCheckedGraphsCl(bool)));
    checkGraphsCl->setChecked(false);

    QSplitter *__split = new QSplitter(Qt::Vertical, ClasterTabs);
    __split->addWidget(treeviewCl);
    __split->addWidget(checkGraphsCl);

    //QColor color = QColor(200, 230, 240);
    //treeview->setStyleSheet(QString("QTreeView{ background-color: %1 }").arg(color.name()));

    _delete(tableviewCl);tableviewCl = new MyTableView(ClasterTabs);
    tableviewCl->setModel(tableProxyModelCl);
    tableviewCl->hideColumn(5);
    tableviewCl->hideColumn(6);
    tableviewCl->resizeColumnsToContents();
    tableviewCl->horizontalHeader()->setStretchLastSection(true);
    QObject::connect(tableviewCl->deleteRow, SIGNAL(triggered()), this, SLOT(deleteRowCl()));

    _delete(clGraph);clGraph = new Curve();

    QSplitter *_split = new QSplitter(Qt::Vertical, ClasterTabs);

    _delete(splitCl);splitCl = new QSplitter(Qt::Horizontal, _split);
    splitCl->addWidget(__split);splitCl->setStretchFactor(0, 2);
    splitCl->addWidget(clGraph);splitCl->setStretchFactor(1, 2);

    _split->addWidget(splitCl);
    _split->addWidget(tableviewCl);
    _split->setStretchFactor(0, 2);
    _split->setStretchFactor(1, 1);

    connect( treeviewCl, SIGNAL(clicked(const QModelIndex &)), this, SLOT(groupClChanged(const QModelIndex &)) );

    _delete(layCl);layCl = new QVBoxLayout(ClasterTabs);
    layCl->addWidget(_split);

    ClasterTabs->setLayout(layCl);*/

    //30.03.2012   ���������� ������� ����������� ������� ���� �����



}

void MainWin::setCheckedGraphsCl(const bool &in)
{
    clCheckedGraphs = in;
}

Node* MainWin::InitTreeCl(){

    vecII groupVar;
    groupVar = vecClas;

    int countGroups = groupVar.count();


    Node* _rootCl = new Node();

    Node *group1 = new Node( _rootCl,  tr("1"), tr("������� ����������� �����"), "","", "", GROUP);
    _rootCl->children.append(group1);

        Node *group11 = new Node( group1,  tr("1.1"), tr("HOTELLING"), "","", "", GROUP);
        group1->children.append(group11);

        groupsHCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHCl[i] = new Node( group11,  tr("1.1.%1").arg(i+1), str, "", "", "", GROUP);
            group11->children.append(groupsHCl[i]);
            str = "";
        }


        Node *group12 = new Node( group1, tr("1.2"), tr("MEWMA"), "", "", "", GROUP);
        group1->children.append(group12);

        groupsMCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMCl[i] = new Node( group12, tr("1.2.%1").arg(i+1), str, "", "", "", GROUP);
            group12->children.append(groupsMCl[i]);
            str = "";
        }

    Node *group2 = new Node( _rootCl, tr("2"), tr("����������� ����� � ��������������� ��������"), "", "", "", GROUP);
    _rootCl->children.append(group2);

        Node *group21 = new Node( group2, tr("2.1"), tr("HOTELLING"), "", "", "", GROUP);
        group2->children.append(group21);

        groupsHWCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsHWCl[i] = new Node( group21, tr("2.1.%1").arg(i+1), str, "", "", "", GROUP);
            group21->children.append(groupsHWCl[i]);
            str = "";
        }

        Node *group22 = new Node( group2, tr("2.2"), tr("MEWMA"), "", "", "", GROUP);
        group2->children.append(group22);

        groupsMWCl.resize(countGroups);
        for (int i = 0; i < countGroups; i++)
        {
            QString str = "";
            for (int j = 0; j < groupVar[i].count(); j++)
                str += tr("x%1").arg(groupVar[i][j] + 1);
            groupsMWCl[i] = new Node( group22, tr("2.2.%1").arg(i+1), str, "", "", "", GROUP);
            group22->children.append(groupsMWCl[i]);
            str = "";
        }



    return _rootCl;
}

void MainWin::groupClChanged(const QModelIndex& index){

    QModelIndex i = treeProxyModelCl->mapToSource(index);
    iClaster = i;

    int countRows = mmodelCl->rowCount(i);
    if (countRows > 0)
    {

        QModelIndex j = tableProxyModelCl->mapFromSource(i);
        tableviewCl->setRootIndex(j);


        vecR temp_data(countRows), temp_sp;
        for (int ii = 0; ii < countRows; ii++)
        {
            temp_data[ii].setX(mmodelCl->data(mmodelCl->index(ii, 4, i),Qt::EditRole).toFloat());
            temp_data[ii].setY(mmodelCl->data(mmodelCl->index(ii, 2, i),Qt::EditRole).toFloat());
        }

        float tempX = 0.0, tempY = 0.0;

        for (int ii = 0; ii < countRows; ii++)
           for (int jj = ii; jj < countRows; jj++)
               if (temp_data[jj].x() < temp_data[ii].x())
               {
                    tempX = temp_data[ii].x(); tempY = temp_data[ii].y();
                    temp_data[ii].setX(temp_data[jj].x());
                    temp_data[ii].setY(temp_data[jj].y());
                    temp_data[jj].setX(tempX);
                    temp_data[jj].setY(tempY);
               }
        tempX = __null; tempY = __null;

        if (!clCheckedGraphs)
        {
            _delete(clGraph);
            clGraph = new Curve();
            countGraphsCl = 0;
        }

        if (temp_data.count() < 3)
            clGraph->setCurveData(countGraphsCl, temp_data);
        else
        {
            /*cubic_spline *spline = new cubic_spline;

            vecF XX, YY;

            for (int j = 0; j < temp_data.count(); j++)
            {
                XX.push_back(temp_data[j].x()); YY.push_back(temp_data[j].y());
            }
            spline->build_spline(XX, YY);

            for (qreal j = XX[0];j <= XX[XX.count()-1]; j+=0.01 )
            {

                temp_sp.push_back(QPointF(j, (qreal)spline->f(j)));
            }*/
            power_funct *power = new power_funct;
            power->build_funct(temp_data);
            for (qreal j = temp_data[0].x();j <= temp_data[temp_data.count()-1].x(); j+=0.01 )
                temp_sp.push_back(QPointF(j, power->f(j)));


            clGraph->setCurveData(countGraphsCl, temp_sp);
        }

        countGraphsCl++;

        temp_data.clear();temp_sp.clear();
        clGraph->setVarsName(tr("������� ����� �����"));
        clGraph->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));

        splitCl->addWidget(clGraph);splitCl->setStretchFactor(1, 2);

        clGraph->hasFocus();

    }
    countRows = __null;


}

void MainWin::updateClLS()
{

    vecF avSLHot, avSLMewma, avSLWHot, avSLWMewma, skoSLHot, skoSLMewma, skoSLWHot, skoSLWMewma, lambda;
    float tmin = 0.0, tmax = 0.0, sqrtn = sqrt(linesHotCl[0].count());
    //if (mode == 0)
    {
        avSLHot = _mean(linesHotCl); skoSLHot = _sko(linesHotCl);
        avSLMewma = _mean(linesMewmaCl); skoSLMewma = _sko(linesMewmaCl);
        avSLWHot = _mean(linesHotWCl); skoSLWHot = _sko(linesHotWCl);
        avSLWMewma = _mean(linesMewmaWCl); skoSLWMewma = _sko(linesMewmaWCl);
        lambda = Vars->getLambdaClaster();

    }/*
    countCl++;
    for (int i = 0; i < vecClas.count(); i++)
    {
        tmin = avSLHot[i] - (1.67 * skoSLHot[i] / sqrtn); tmax = avSLHot[i] + (1.67 * skoSLHot[i] / sqrtn);
        groupsHCl[i]->children.append( new Node( groupsHCl[i], tr("1.1.%1   �%2").arg(i + 1).arg(countCl), tr("%1").arg(tmin), tr("%1").arg(avSLHot[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
        tmin = avSLMewma[i] - (1.67 * skoSLMewma[i] / sqrtn); tmax = avSLMewma[i] + (1.67 * skoSLMewma[i] / sqrtn);
        groupsMCl[i]->children.append( new Node( groupsMCl[i], tr("1.2.%1   �%2").arg(i + 1).arg(countCl), tr("%1").arg(tmin), tr("%1").arg(avSLMewma[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
        tmin = avSLWHot[i] - (1.67 * skoSLWHot[i] / sqrtn); tmax = avSLWHot[i] + (1.67 * skoSLWHot[i] / sqrtn);
        groupsHWCl[i]->children.append( new Node( groupsHWCl[i], tr("2.1.%1   �%2").arg(i + 1).arg(countCl), tr("%1").arg(tmin), tr("%1").arg(avSLWHot[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
        tmin = avSLWMewma[i] - (1.67 * skoSLWMewma[i] / sqrtn); tmax = avSLWMewma[i] + (1.67 * skoSLWMewma[i] / sqrtn);
        groupsMWCl[i]->children.append( new Node( groupsMWCl[i], tr("2.2.%1   �%2").arg(i + 1).arg(countCl), tr("%1").arg(tmin), tr("%1").arg(avSLWMewma[i]), tr("%1").arg(tmax), tr("%1").arg(lambda[i]), ELEMENT ) );
    }

    avSLHot.clear(); avSLMewma.clear(); avSLWHot.clear(); avSLWMewma.clear();
    skoSLHot.clear(); skoSLMewma.clear(); skoSLWHot.clear(); skoSLWMewma.clear();
    lambda.clear(); tmin = __null; tmax = __null;

    _delete(treeProxyModelCl);treeProxyModelCl = new QSortFilterProxyModel(this);
    treeProxyModelCl->setSourceModel(mmodelCl);
    treeProxyModelCl->setFilterRole(Qt::DisplayRole);
    treeProxyModelCl->setFilterKeyColumn(5);
    treeProxyModelCl->setFilterFixedString("1"); //������ ��� ���������

    _delete(tableProxyModelCl);tableProxyModelCl = new QSortFilterProxyModel(this);
    tableProxyModelCl->setSourceModel(mmodelCl);

    treeviewCl->reset();treeviewCl->setModel(treeProxyModelCl);treeviewCl->expandAll();
    tableviewCl->reset();tableviewCl->setModel(tableProxyModelCl);*/

    vecII clVec = vecClas;

    vecSS tempS = _createS(7, clVec.count());

    _delete(linesClResult); linesClResult = new LinesResultsModel(this, "LinesResults");
    linesClResult->toModel(tempS);
    _delete(linesClResultW); linesClResultW = new LinesResultsModel(this, "LinesResults");
    linesClResultW->toModel(tempS);
    tempS.clear();

    vecS str(clVec.count());

    for (int i = 0; i < clVec.count(); i++)
        for (int j = 0; j < clVec[i].count(); j++)
            str[i] += QString("x%1").arg(clVec[i][j] + 1);

    for (int i = 0; i < clVec.count(); i++)
    {
        tmin = avSLHot[i] - (1.67 * skoSLHot[i] / sqrtn); tmax = avSLHot[i] + (1.67 * skoSLHot[i] / sqrtn);
        linesClResult->setData(linesClResult->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesClResult->setData(linesClResult->index(i, 1, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesClResult->setData(linesClResult->index(i, 2, QModelIndex()), QString("%1").arg(avSLHot[i]), Qt::EditRole);
        linesClResult->setData(linesClResult->index(i, 3, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

        tmin = avSLMewma[i] - (1.67 * skoSLMewma[i] / sqrtn); tmax = avSLMewma[i] + (1.67 * skoSLMewma[i] / sqrtn);;
        linesClResult->setData(linesClResult->index(i, 4, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesClResult->setData(linesClResult->index(i, 5, QModelIndex()), QString("%1").arg(avSLMewma[i]), Qt::EditRole);
        linesClResult->setData(linesClResult->index(i, 6, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

        tmin = avSLWHot[i] - (1.67 * skoSLWHot[i] / sqrtn); tmax = avSLWHot[i] + (1.67 * skoSLWHot[i] / sqrtn);
        linesClResultW->setData(linesClResultW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesClResultW->setData(linesClResultW->index(i, 1, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesClResultW->setData(linesClResultW->index(i, 2, QModelIndex()), QString("%1").arg(avSLWHot[i]), Qt::EditRole);
        linesClResultW->setData(linesClResultW->index(i, 3, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

        tmin = avSLWMewma[i] - (1.67 * skoSLWMewma[i] / sqrtn); tmax = avSLWMewma[i] + (1.67 * skoSLWMewma[i] / sqrtn);
        linesClResultW->setData(linesClResultW->index(i, 4, QModelIndex()), QString("%1").arg(tmin), Qt::EditRole);
        linesClResultW->setData(linesClResultW->index(i, 5, QModelIndex()), QString("%1").arg(avSLWMewma[i]), Qt::EditRole);
        linesClResultW->setData(linesClResultW->index(i, 6, QModelIndex()), QString("%1").arg(tmax), Qt::EditRole);

    }
    str.clear();
    _delete(treeResultCl);
    treeResultCl = new QTreeView; treeResultCl->setModel(linesClResult);treeResultCl->setFont(QFont("Arial", 10, QFont::Bold));
    treeResultCl->resizeColumnToContents(0);
    treeResultCl->resizeColumnToContents(1);
    treeResultCl->resizeColumnToContents(2);
    treeResultCl->resizeColumnToContents(3);
    treeResultCl->resizeColumnToContents(4);
    treeResultCl->resizeColumnToContents(5);
    treeResultCl->resizeColumnToContents(6);
    treeResultCl->header()->setDefaultAlignment(Qt::AlignCenter);

    QVBoxLayout *lineCl = new QVBoxLayout;
    lineCl->addWidget(treeResultCl);

    QGroupBox *lineGrB = new QGroupBox(tr("���������� ���������� ������� ���� �����:"));
    lineGrB->setLayout(lineCl);

    //-------------------------------

    _delete(treeResultWCl);
    treeResultWCl = new QTreeView; treeResultWCl->setModel(linesClResultW);treeResultWCl->setFont(QFont("Arial", 10, QFont::Bold));
    treeResultWCl->resizeColumnToContents(0);
    treeResultWCl->resizeColumnToContents(1);
    treeResultWCl->resizeColumnToContents(2);
    treeResultWCl->resizeColumnToContents(3);
    treeResultWCl->resizeColumnToContents(4);
    treeResultWCl->resizeColumnToContents(5);
    treeResultWCl->resizeColumnToContents(6);
    treeResultWCl->header()->setDefaultAlignment(Qt::AlignCenter);

    QVBoxLayout *lineClW = new QVBoxLayout;
    lineClW->addWidget(treeResultWCl);

    QGroupBox *lineGrBW = new QGroupBox(tr("���������� ���������� ������� ���� ����� ��� ����������� ���� � ��������������� ��������:"));
    lineGrBW->setLayout(lineClW);

    //----------------------------------

    QSplitter *sp_linesCl = new QSplitter(Qt::Vertical, ClasterTabs);
    sp_linesCl->addWidget(lineGrB);
    sp_linesCl->addWidget(lineGrBW);

    QVBoxLayout *lineSeriesCl = new QVBoxLayout;
    lineSeriesCl->addWidget(sp_linesCl);


    ClasterTabs->setLayout(lineSeriesCl);







}

void MainWin::setDendroBt(const QString &str)
{
    createDendro->setText(str);
}

void MainWin::createDendrogramm()
{
    qRegisterMetaType<TDenroGramm *>("TDenroGramm *");
    dendroGramma = new Dendrogramm(Vars);
    tabsCl->setCursor(Qt::BusyCursor);
    //����� � �������� ������
    QObject::connect(dendroGramma, SIGNAL(processSetTextBt(QString)), this, SLOT(setDendroBt(QString)));
    //��������� � ������ ���������
    QObject::connect(dendroGramma, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));
    QObject::connect(dendroGramma, SIGNAL(getData(TDenroGramm*)), this, SLOT(setDendroClasters(TDenroGramm*)));
    QObject::connect(dendroGramma, SIGNAL(terminated()), this, SLOT(getDendrogramm()));

    if (createDendro->text() == tr("������������"))
    {
        dendroGramma->start();
        QObject::connect(createDendro, SIGNAL(clicked()), dendroGramma, SLOT(setFlag()));
    }
}

void MainWin::setDendroClasters(TDenroGramm *source)
{
    _delete(clastersForDendro);
    clastersForDendro = new TDenroGramm;
    clastersForDendro = source;
}

void MainWin::getDendrogramm()
{
    _delete(graphD);
    graphD = new PaintDenrogramm();
    graphD->setCurveData(Vars->getFileCountVars(), clastersForDendro);    
    graphD->hasFocus();

    //graphD->setWindowTitle(tr("������������ ��� %1 �����������.").arg(Vars->getFileCountVars()));
    graphD->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));
    graphD->show();
    tabsCl->setCursor(Qt::ArrowCursor);    
}


void MainWin::calc_clasters(const int &countGroups)
{
    vecSS tempS = _createS(5, countGroups);

    //������ ��� ��������������� �������
    linesModelCLB->toModel(tempS);
    linesModelCLBW->toModel(tempS);
    linesModelCLN->toModel(tempS);
    linesModelCLNW->toModel(tempS);

    tempS.clear();
    Vars->setCountClasters(countGroups);

    qRegisterMetaType<vecII>("vecII");

    grCl = new ClasterGroup(Vars);
    grCl->start();
    QObject::connect(grCl, SIGNAL(getData(vecII)), this, SLOT(setCLStr(vecII)));

}

void MainWin::setCLStr(vecII in)
{
    vecClas = in;
    Vars->setCountClasters(in.count());
    vecS str(in.count());
    for (int i = 0; i < in.count(); i++)
        for (int j = 0; j < in[i].count(); j++)
            str[i] += QString("x%1").arg(in[i][j] + 1);

    for (int i = 0; i < str.count(); i++)
    {
        linesModelCLBW->setData(linesModelCLBW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelCLB->setData(linesModelCLB->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelCLNW->setData(linesModelCLNW->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
        linesModelCLN->setData(linesModelCLN->index(i, 0, QModelIndex()), str[i], Qt::EditRole);
    }
    vvv5->reset();vvv6->reset();vvv7->reset();vvv8->reset();
    vvv5->setModel(linesModelCLB);vvv6->setModel(linesModelCLBW);vvv7->setModel(linesModelCLN);vvv8->setModel(linesModelCLNW);
    str.clear();
    QObject::connect(spbLambdaCl, SIGNAL(valueChanged(int)), this, SLOT(setLbLambdaCl(int)));
    connect( listLinesVarCl, SIGNAL(clicked(const QModelIndex &)), this, SLOT(setListBLambdaCl(const QModelIndex &)) );
    createLinesSCl();
    createLinesModCl();
}

void MainWin::drawLines(const vecF data, QWidget *parent)
{
}

void MainWin::paintEvent(QPaintEvent *pe)
{
}

void MainWin::createHotGraph()
{
    hotMon = false;
    vecFF in_data = model->toArray();

    ChangeGrB = new QGroupBox(tr("����� ����������:"), tabsHot);
    ChangeGrB->setFont(QFont("Arial", 10, QFont::Bold));

        QGridLayout *hotlay = new QGridLayout(ChangeGrB);

        QLabel *listVars = new QLabel;
        listVars->setText(tr("����������:"));
        QLabel *groupVars = new QLabel;
        groupVars->setText(tr("������:"));

        QHBoxLayout *labelsLay = new QHBoxLayout;
        labelsLay->addWidget(listVars);
        labelsLay->addWidget(groupVars);

        _delete(inList);inList = new ProjectListWidget(this);
        inList->setFixedSize(80, 220);
        inList->setSortingEnabled(true);
        inList->setFont(QFont("Arial", 10, QFont::Bold));
        inList->setStatusTip(tr("��������� ������ �������� ����� ������� ���� � ���������� ��� � ������ ������."));
        inList->setToolTip(tr("������ ��������� ����������"));
        //inList->setSelectionMode(QAbstractItemView::MultiSelection);

        for (int i = 0; i < in_data.count(); i++)
            new QListWidgetItem(QString("x%1").arg(i + 1), inList);

        _delete(groupList);
        groupList = new ProjectListWidget(this);
        //groupList->setSelectionMode(QAbstractItemView::MultiSelection);
        groupList->setFixedSize(80, 220);
        groupList->setSortingEnabled(true);
        groupList->setFont(QFont("Arial", 10, QFont::Bold));
        groupList->setToolTip(tr("�������� ����� - ������ ���������� ��� ������� � ���������� ���������� ����������"));
        groupList->setStatusTip(tr("������� �������� �� ������ �������� ��������� ��� ������� � ������ ��������� ����������."));        
        QObject::connect(groupList, SIGNAL(itemSelectionChanged()), this, SLOT(setHotMon()));


        //t2->setText(tr("<font size=\"+2\" color=\"#0000ff\">T2 = </font>"));

        t2->setText(tr("T2 = "));
        t2->setChecked(true);
        t2->setToolTip(tr("���������� / ������ �������� ����������� ������� ����������� ����� ����������"));
        t2->setStatusTip(tr("���������� / ������ �������� ����������� ������� ����������� ����� ����������"));
        t2->setPalette(QPalette(QColor(0, 240, 255)));
        t2->setFont(QFont("Times", 12, QFont::Bold));
        //t2->animateClick(1000);
        //t2->setForegroundRole(palette().text().color().blue());
        QObject::connect(t2, SIGNAL(toggled(bool)), this, SLOT(setT2Hot(bool)));

        //t2->setFrameStyle(QFrame::Panel | QFrame::Sunken);
        //t2w->setText(tr("<font size=\"+2\" color=\"#008000\">T2-W = </font>"));

        t2w->setText(tr("T2-W = "));
        //t2w->setFrameStyle(QFrame::Panel | QFrame::Sunken);
        t2w->setChecked(true);
        t2w->setStatusTip(tr("���������� / ������ �������� ��������������� ������� ����������� ����� ����������"));
        t2w->setToolTip(tr("���������� / ������ �������� ��������������� ������� ����������� ����� ����������"));
        t2w->setFont(QFont("Times", 12, QFont::Bold));
        //t2w->animateClick(1000);
        QObject::connect(t2w, SIGNAL(toggled(bool)), this, SLOT(setT2WHot(bool)));

        QPushButton *createGraph = new QPushButton(ChangeGrB);
        createGraph->setText(tr("���������"));
        createGraph->setStatusTip(tr("������������ ����������� ����������� ���������� ���������� ��� ��������� ������ ����������."));
        createGraph->setToolTip(tr("������������ ����������� ����������� ���������� ���������� ��� ��������� ������ ����������"));

        QPushButton *loadFiles = new QPushButton(ChangeGrB);
        loadFiles->setText(tr("��������� ����"));
        loadFiles->setStatusTip(tr("��������� ���� ������������ ������� � �������� ������� ����������."));
        loadFiles->setToolTip(tr("��������� ���� ������������ ������� � �������� ������� ����������"));

        hotlay->addWidget(loadFiles, 0, 0, 1, 2, Qt::AlignBottom);
        hotlay->addWidget(listVars, 1, 0, 1, 1, Qt::AlignBottom);
        hotlay->addWidget(groupVars, 1, 1, 1, 1, Qt::AlignBottom);
        hotlay->addWidget(inList, 2, 0, 3, 1, Qt::AlignTop);
        hotlay->addWidget(groupList, 2, 1, 3, 1, Qt::AlignTop);
        hotlay->addWidget(createGraph, 5, 0, 1, 2, Qt::AlignVCenter);
        hotlay->addWidget(t2, 6, 0, 1, 2);
        hotlay->addWidget(t2w, 7, 0, 1, 2);

    ChangeGrB->setLayout(hotlay);

    HotGrB = new QGroupBox(tr("�������:"), tabsHot);
    HotGrB->setFont(QFont("Arial", 10, QFont::Bold));

        graph = new Plotter();

        HotLayGr = new QHBoxLayout;
        HotLayGr->addWidget(graph);

        HotGrB->setLayout(HotLayGr);

    QObject::connect(createGraph, SIGNAL(clicked()), this, SLOT(drawHotelling()));
    QObject::connect(loadFiles, SIGNAL(clicked()), this, SLOT(openFileForMonH()));

    QHBoxLayout *HotLay = new QHBoxLayout;
    HotLay->addWidget(ChangeGrB, 0, Qt::AlignLeft);
    HotLay->addWidget(HotGrB, 10);

    tabsHot->setLayout(HotLay);
}

void MainWin::setHotMon()
{
    hotMon = false;
    _delete(graph);
}

void MainWin::setT2Hot(bool _in)
{
    if (!_in)
    {
        graph->clearCurve(1);
        t2->setText(tr("T2 ="));
    }
    else emit drawHotelling();
}

void MainWin::setT2WHot(bool _in)
{
    if (!_in)
    {
        graph->clearCurve(2);
        t2w->setText(tr("T2-W ="));
    }
    else emit drawHotelling();
}

void MainWin::createDockWin()
{
    /*QDockWidget *dock = new QDockWidget(tr("���� %1").arg(++countWinHot), cannonBox);
    dock->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea );
    addDockWidget(Qt::RightDockWidgetArea, dock);*/
}

void MainWin::drawHotelling()
{
    _delete(graph);
    graph = new Plotter();

    vecI vvv;
    if (groupList->count() > 0)
    {
        for (int i = 0; i < groupList->count(); i++)
            vvv << groupList->item(i)->text().remove('x').toInt() - 1;
        QString sss = tr("����������� ����� ����������\n");

        vecF hot;
        if (hotMon)
            hot = _HOTELLING_MON(model->toArray(), loadModelH->toArray(),  vvv, loadModelH->n);
        else
        {
            sss += tr("��������� �������");
            hot = _HOTELLING(model->toArray(), vvv, model->n);
        }
        sss += tr(" �� ���������� :");
        for (int i = 0; i < vvv.count(); i++)
            sss += QString(tr("x%1")).arg(vvv[i] + 1);

        graph->setVarsName(sss);

        sss.clear();
        float hh = _GetHOTTELING_Kr_High(vvv.count());
        //t2->setText(tr("<font size=\"+2\" color=\"#0000ff\">T2 = %1</font>").arg(hh));
        //if (t2->checkState())
        if (t2->isChecked()) t2->setText(tr("T2 = %1").arg(hh));
        float hw = _GetHOTTELING_Kr_Middle(vvv.count());
        //t2w->setText(tr("<font size=\"+2\" color=\"#008000\">T2-W = %1</font>").arg(hw));
        if (t2w->isChecked()) t2w->setText(tr("T2-W = %1").arg(hw));
        vvv.clear();
        vecR ggg, wwwgg, wgg;
        for (int i = 1; i <= hot.count(); i++)
        {
            ggg << QPointF(float(i), hot[i - 1]);
            wwwgg << QPointF(float(i), hh);
            wgg << QPointF(float(i), hw);
        }

        //t2->c

        graph->setCurveData(0, ggg);
        if (t2->isChecked()) graph->setCurveData(1, wwwgg);
        if (t2w->isChecked()) graph->setCurveData(2, wgg);
        ggg.clear();wwwgg.clear();wgg.clear();

        _delete(HotLayGr);
        HotLayGr = new QHBoxLayout;

        HotLayGr->addWidget(graph);

        HotGrB->setLayout(HotLayGr);

        graph->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));
        graph->hasFocus();
        graph->show();
    }
}

void MainWin::createMEWMAGraph()
{
    mewMon = false;
    vecFF in_data = model->toArray();

    ChangeWEMGrB = new QGroupBox(tr("����� ����������:"), tabsMew);
    ChangeWEMGrB->setFont(QFont("Arial", 10, QFont::Bold));

        QGridLayout *hotlay = new QGridLayout(ChangeWEMGrB);

        QLabel *listVars = new QLabel;listVars->setText(tr("����������:"));
        QLabel *groupVars = new QLabel;groupVars->setText(tr("������:"));

        QHBoxLayout *labelsLay = new QHBoxLayout;
        labelsLay->addWidget(listVars);
        labelsLay->addWidget(groupVars);

        _delete(inMList);inMList = new ProjectListWidget(this);
        inMList->setFixedSize(80, 220);
        inMList->setSortingEnabled(true);
        inMList->setFont(QFont("Arial", 10, QFont::Bold));
        inMList->setStatusTip(tr("��������� ������ �������� ����� ������� ���� � ���������� ��� � ������ ������."));
        inMList->setToolTip(tr("������ ��������� ����������"));
        for (int i = 0; i < in_data.count(); i++)
            new QListWidgetItem(QString("x%1").arg(i + 1), inMList);

        _delete(groupMList);groupMList = new ProjectListWidget(this);
        groupMList->setFixedSize(80, 220);
        groupMList->setSortingEnabled(true);
        groupMList->setFont(QFont("Arial", 10, QFont::Bold));
        groupMList->setToolTip(tr("�������� ����� - ������ ���������� ��� ������� � ���������� ���������� MEWMA"));
        groupMList->setStatusTip(tr("������� �������� �� ������ �������� ��������� ��� ������� � ������ ��������� ����������."));
        QObject::connect(groupMList, SIGNAL(itemSelectionChanged()), this, SLOT(setMEWMAMon()));


        me2->setText(tr("ME = "));
        me2->setChecked(true);
        me2->setToolTip(tr("���������� / ������ �������� ����������� ������� ����������� ����� MEWMA"));
        me2->setStatusTip(tr("���������� / ������ �������� ����������� ������� ����������� ����� MEWMA"));
        me2->setFont(QFont("Times", 12, QFont::Bold));
        //me2->adjustSize();

        QObject::connect(me2, SIGNAL(toggled(bool)), this, SLOT(setME2check(bool)));
        //me2->setFrameStyle(QFrame::Panel | QFrame::Sunken);
        me2w->setChecked(true);
        me2w->setText(tr("ME-W = "));
        me2w->setToolTip(tr("���������� / ������ �������� ��������������� ������� ����������� ����� MEWMA"));
        me2w->setStatusTip(tr("���������� / ������ �������� ��������������� ������� ����������� ����� MEWMA"));
        me2w->setFont(QFont("Times", 12, QFont::Bold));

        QObject::connect(me2w, SIGNAL(toggled(bool)), this, SLOT(setME2Wcheck(bool)));
        //me2w->setFrameStyle(QFrame::Panel | QFrame::Sunken);

        QPushButton *createGraph = new QPushButton(MEWGrB);
        createGraph->setText(tr("���������"));
        createGraph->setStatusTip(tr("������������ ����������� ����������� ���������� MEWMA ��� ��������� ������ ����������."));
        createGraph->setToolTip(tr("������������ ����������� ����������� ���������� MEWMA ��� ��������� ������ ����������"));

        QPushButton *loadFiles = new QPushButton(MEWGrB);
        loadFiles->setText(tr("��������� ����"));
        loadFiles->setStatusTip(tr("��������� ���� ������������ ������� � �������� ������� ����������."));
        loadFiles->setToolTip(tr("��������� ���� ������������ ������� � �������� ������� ����������"));

        hotlay->addWidget(loadFiles, 0, 0, 1, 2, Qt::AlignBottom);
        hotlay->addWidget(listVars, 1, 0, 1, 1, Qt::AlignBottom);
        hotlay->addWidget(groupVars, 1, 1, 1, 1, Qt::AlignBottom);
        hotlay->addWidget(inMList, 2, 0, 3, 1, Qt::AlignTop);
        hotlay->addWidget(groupMList, 2, 1, 3, 1, Qt::AlignTop);
        hotlay->addWidget(createGraph, 5, 0, 1, 2, Qt::AlignVCenter);
        hotlay->addWidget(me2, 6, 0, 1, 2);
        hotlay->addWidget(me2w, 7, 0, 1, 2);


    ChangeWEMGrB->setLayout(hotlay);

    MEWGrB = new QGroupBox(tr("�������:"), tabsMew);
    MEWGrB->setFont(QFont("Arial", 10, QFont::Bold));

        graphM = new Plotter();

        MEWLayGr = new QHBoxLayout;
        MEWLayGr->addWidget(graphM);

        MEWGrB->setLayout(MEWLayGr);


    QObject::connect(createGraph, SIGNAL(clicked()), this, SLOT(drawMewma()));
    QObject::connect(loadFiles, SIGNAL(clicked()), this, SLOT(openFileForMonW()));

    QHBoxLayout *HotLay = new QHBoxLayout;
    HotLay->addWidget(ChangeWEMGrB, 0, Qt::AlignLeft);
    HotLay->addWidget(MEWGrB, 10);

    tabsMew->setLayout(HotLay);
}

void MainWin::setMEWMAMon()
{
    mewMon = false;_delete(graphM);
}

void MainWin::setME2check(bool _in)
{
    if (!_in)
    {
        graphM->clearCurve(1);
        me2->setText(tr("ME ="));
    }
    else emit drawMewma();
}

void MainWin::setME2Wcheck(bool _in)
{
    if (!_in)
    {
        graphM->clearCurve(2);
        me2w->setText(tr("ME-W ="));
    }
    else emit drawMewma();
}

void MainWin::drawMewma()
{
    _delete(graphM);
    graphM = new Plotter();

    vecI vvv;
    if (groupMList->count() > 0)
    {
        for (int i = 0; i < groupMList->count(); i++)
            vvv << groupMList->item(i)->text().remove('x').toInt() - 1;
        QString sss = tr("����������� ����� ������������� ���������� ���������� �������");

        vecF hot;

        if (mewMon)
            hot = _MEWMA_MON(model->toArray(), loadModelW->toArray(),  vvv, loadModelW->n);
        else
        {
            sss += tr("\n��������� �������");
            hot = _MEWMA(model->toArray(), vvv, model->n);
        }
        sss += tr(" �� ���������� :");
        for (int i = 0; i < vvv.count(); i++)
            sss += QString(tr("x%1")).arg(vvv[i] + 1);
        graphM->setVarsName(sss);
        sss.clear();

        float hh = _GetMEWMA_Kr_High(vvv.count(), 0.005);
        if (me2->isChecked()) me2->setText(tr("ME = %1").arg(hh));
        float hw = _GetMEWMA_Kr_Middle(vvv.count(), 0.005);
        if (me2w->isChecked()) me2w->setText(tr("ME-W = %1").arg(hw));
        vvv.clear();
        vecR ggg, wwwgg, wgg;
        for (int i = 1; i <= hot.count(); i++)
        {
            ggg << QPointF(float(i), hot[i - 1]);
            wwwgg << QPointF(float(i), hh);
            wgg << QPointF(float(i), hw);
        }

        graphM->setCurveData(0, ggg);
        if (me2->isChecked()) graphM->setCurveData(1, wwwgg);
        if (me2w->isChecked()) graphM->setCurveData(2, wgg);

        ggg.clear();wwwgg.clear();wgg.clear();

        _delete(MEWLayGr);
        MEWLayGr = new QHBoxLayout;
        MEWLayGr->addWidget(graphM);

        MEWGrB->setLayout(MEWLayGr);

        graphM->setToolTip(tr("��� ���������� ������� �� ����������� ������ ������� ����"));
        graphM->hasFocus();
        graphM->show();
    }
}

bool MainWin::openFileForMonH()
{
    QString fileName = QFileDialog::getOpenFileName(
                            this,
                            tr("����� �����"),
                            QString(),
                            tr("��������� (*.txt);;��� ����� (*.*)")
                        );
    if (!fileName.isEmpty())
    {
        _delete(loadModelH);
        loadModelH = new TableModel(this, "Load");
        loadModelH->loadData(fileName);
        hotMon = true;
        return true;
    }
    else
        return false;
}

bool MainWin::openFileForMonW()
{
    QString fileName = QFileDialog::getOpenFileName(
                            this,
                            tr("����� �����"),
                            QString(),
                            tr("��������� (*.txt);;��� ����� (*.*)")
                        );
    if (!fileName.isEmpty())
    {
        _delete(loadModelW);
        loadModelW = new TableModel(this, "Load");
        loadModelW->loadData(fileName);
        mewMon = true;
        return true;
    }
    else
        return false;
}

bool MainWin::openFile()
{    
    fileOpen = QFileDialog::getOpenFileName(
                this,
                tr("����� �����"),
                QString(),
                tr("��������� (*.txt);;��� ����� (*.*)")
            );

    if (!fileOpen.isEmpty())
    {
        corrBootstr = false; corrNorm = false; countCorr = 0;
        clBootstr = false; clNorm = false;
        corrCheckedGraphs = false; clCheckedGraphs = false;

        regression.clear(); lwremainsRegre = __null; tvRemains = __null;  btnClearRegre = __null;

        listLambdaVars.clear(); listLambdaClVars.clear();
        lineSeriesCorr = __null;

        dialog = __null; btnSetRegre = __null;

        groupsH.clear(); groupsM.clear(); groupsHW.clear(); groupsMW.clear();
        groupsHMod.clear(); groupsMMod.clear(); groupsHWMod.clear(); groupsMWMod.clear();
        groupsHModCl.clear(); groupsMModCl.clear(); groupsHWModCl.clear(); groupsMWModCl.clear();
        spbLambda = __null;
        groupsHCl.clear(); groupsMCl.clear(); groupsHWCl.clear(); groupsMWCl.clear(); //spbLambda = __null;
        root = __null; rootCl = __null; countCl = 0;
        //rootModCorr = __null;
        spbFactors = __null;

        countWinHot = __null; lbLambda = __null; listLinesVar = __null;

        mainWidget = __null;
        listStage = __null; listState = __null;

        free_factorList = __null; factorsList = __null; regressorsList = __null; responseList = __null;  varsList = __null;

        model = __null; tvn = __null;  NORMIR = __null;  CORR = __null;  COVV = __null;  CHANGE = __null;  INVERSE = __null;
        linesModelB = __null; linesModelBW = __null; linesModelN = __null; linesModelNW = __null;
        linesModel = __null; linesModelW = __null;
        linesModelCLB = __null; linesModelCLBW = __null; linesModelCLN = __null; linesModelCLNW = __null;
        loadModelH = __null; loadModelW = __null;
        _delete(loadSecondData);
        listModelCorr = __null; listModelCl = __null;
        treeListChangedModel = __null;
        linesCorrResult = __null;  linesCorrResultW = __null;
        treeResultCorr = __null; treeResultWCorr = __null;

        linesClResult = __null; linesClResultW = __null;
        treeResultCl = __null; treeResultWCl = __null;

        listCorrLambda = __null;
        modelCorrModel = __null;

        mmodel = __null; treeview = __null; tableview = __null; treeProxyModel = __null; tableProxyModel = __null; split = __null; layCorr = __null;
        mmodelCl = __null; treeviewCl = __null; tableviewCl = __null; treeProxyModelCl = __null; tableProxyModelCl = __null; splitCl = __null; layCl = __null;
        treeModProxyModel = __null; tableModProxyModel = __null;

        nextStackP = __null;

        MOSKO = __null; tvMOSKO = __null; tvNORMIR = __null; tvCORR = __null; tvCOVV = __null; tvCHANGE = __null; tvINVERSE = __null;

        vvv1 = __null; vvv2 = __null; vvv3 = __null; vvv4 = __null;
        vvv5 = __null; vvv6 = __null; vvv7 = __null; vvv8 = __null;
        treeCorr = __null; treeCorrW = __null;
        d = __null; sp = __null; sp_list = __null; sp_main = __null;
        layout = __null;
        layout1 = __null; layout2 = __null; layout3 = __null; layout4 = __null; layout5 = __null; lay1WT = __null; lay2WT = __null;
        mainlay = __null;  lay0L = __null;  lay = __null;  lay00R = __null;  lay0R = __null;
        stackmy = __null;  stack0 = __null; tabs = __null; tabsGeneration = __null; tabsLines = __null;
        tabsCor = __null; CorrTabs = __null;  CorrTabModelling = __null;
        ClTabModelling = __null; tabsCl = __null; ClasterTabs = __null;

        //�������
        graphL = __null; LinesLayGr = __null; corrGraph = __null; LinesLayGrCorr = __null; clGraph = __null;
        checkGraphs = __null; checkGraphsCl = __null;


        inList = __null; groupList = __null;
        graph = __null; scene = __null; view = __null;
        ChangeGrB = __null; HotGrB = __null;
        tabsGraph = __null; tabsHot = __null;

        inMList = __null; groupMList = __null;
        graphM = __null; sceneM = __null; viewM = __null;
        ChangeWEMGrB = __null; MEWGrB = __null;
        tabsMew = __null;
        graphD = __null;
        //--------

        mymain = __null;
        m_tubw = __null;        m_tubw0 = __null;

        butstrrun = __null; normrun = __null;
        normPrB = __null; normDirBt = __null; butstrPrB = __null; butstrDirBt = __null;

        butsLinesRun = __null; normLinesRun = __null;
        linesCorrBPrB = __null;linesCorrNPrB = __null;
        normDirLine = __null; butstrDirLine = __null;
        grCorr = __null;
        listLambda = __null;
        treeCorrModel = __null; tableModelling = __null;
        modelSimplePrB = __null; modelNSimplePrB = __null;
        modelBtRun = __null;

        //������ ���������
        butsLinesRunCL = __null;normLinesRunCL = __null;
        linesCLBPrB = __null;linesCLNPrB = __null;createDendro = __null;
        grCl = __null; spbCl = __null;clastersForDendro = __null; lbLambdaCl = __null;spbLambdaCl = __null;
        listLinesVarCl = __null;layCl = __null;
        listLambdaCl = __null; listClLambda = __null;

        modelClModel = __null; treeModProxyModelCl = __null; treeClModel = __null;
        modelSimplePrBCl = __null;  modelBtRunCl = __null;
        rootModCl = __null; layClModel = __null;

        meanLambdaCorr = __null; meanLambdaCl = __null;


        if (Vars != __null)
        {
            workDirectory.rmdir(Vars->getAppWorkDir());
            Vars = __null;
        }

        Vars = new ExternVariables;
        Vars->setFileCountButs(20);
        Vars->setFileCountNorm(20);

        Vars->addListState(getCurrentTime() + tr("   :   ") + tr("�������� ����������: '") + QCoreApplication::applicationFilePath() + tr(" '"));

        Vars->setAppTempDir(fileOpen);

        model = new TableModel(this, "Load");

        model->loadData(fileOpen);
        vecFF temp = model->toArray();

        vecFF temp1 = _create(temp.count(), temp[0].count()/2);
        for (int i = 0; i < temp.count(); i++)
            for (int j = 0; j < temp[0].count()/2; j++)
                temp1[i][j] = temp[i][j];

        //bool covvTo = true;
        bool covvTo = _compareCovvDiff(temp, temp1);

        if (covvTo)
        {

            createStack();
            createBegin();
            createGeneration();


            calc_begin();


            Vars->setData(temp);
            //VarsLines->setData(temp);
            temp.clear();

            Vars->setFileName(fileOpen);
            Vars->setFileCountVars(model->p);
            Vars->setFileCountStepV(model->n);
            Vars->setFileCountView(model->m);
            Vars->setVarCorrNorm(25);
            Vars->setVarChNorm(false);
            Vars->setVarCovvNorm(false);
            Vars->setView(2);
            Vars->setAlyfa(0.005);

            int ppp = model->p, numberCl = 0;

            if ((ppp < 51)&&(ppp > 40)) numberCl = 7;
            if ((ppp < 41)&&(ppp > 30)) numberCl = 6;
            if ((ppp < 31)&&(ppp > 20)) numberCl = 5;
            if ((ppp < 21)&&(ppp > 10)) numberCl = 4;
            if ((ppp < 11)&&(ppp > 4)) numberCl = 3;
            if ((ppp < 5)&&(ppp > 1)) numberCl = 2;
            if (ppp == 1) numberCl = 1;
            if (ppp > 50) numberCl = 8;
            Vars->setCountClasters(numberCl);
            numberCl = __null; ppp = __null;

            vecF temp_; temp_.resize(model->p);
            for(int i = 0; i < model->p; i++) temp_[i] = 1.0;
            Vars->setListVar(temp_); temp_.clear();

            statusBar()->showMessage(Vars->getDirFile());

            normDirLine->setText(Vars->getDirForSamples());
            butstrDirLine->setText(Vars->getDirForSamples());

            setListState(tr("�������� ���� : ' ") + Vars->getDirFileName() + tr(" '"));

            qRegisterMetaType<const vecLines*>("const vecLines*");

            Vars->setModeChangedX();

            createLinesSeries();
            createLinesSerCorr(3);

            createLinesSerCl(3);
            createHotGraph();
            createMEWMAGraph();
        }

        return true;
    }
    else
        return false;
}

bool MainWin::saveFile()
{
    fileSave = QFileDialog::getSaveFileName(
                this,
                tr("���������� � ����"),
                QString(),
                tr("��������� (*.txt);;��� ����� (*.*)")
            );

    if (!fileSave.isEmpty())
        return model->saveData(true, fileSave);
    else
        return false;
}

void MainWin::setListState(const QString &str)
{
    Vars->addListState(getCurrentTime() + tr("   :   '") + str + tr(" '"));

    listState->clear();
    listState->addItems(Vars->getListState());
}

void MainWin::finishedFuture(const QString &str)
{
    setListState(str);
}

//*****��� ������������ �������� - �������*****************************************************
//*********************************************************************************************
void MainWin::setDirForButs()
{
    QString directory = QFileDialog::getExistingDirectory(this,
                               tr("������� �������: "), Vars->getDirForButs());

    if (directory != "")
    {
        Vars->setDirForButs(directory);
        butstrDirLine->setText(Vars->getDirForButs());
    }
}

void MainWin::setButsBt(const QString &str)
{
    butstrrun->setText(str);
}

void MainWin::createButsThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    butsFut = new ButstrTread(Vars);
    QObject::connect(butsFut, SIGNAL(processChanged(int)), butstrPrB, SLOT(setValue(int)));
    butstrPrB->setMaximum(Vars->getFileCountButStr());
    QObject::connect(butsFut, SIGNAL(processSetTextBt(QString)), this, SLOT(setButsBt(QString)));
    QObject::connect(butsFut, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));

    if (butstrrun->text() == tr("Create"))
    {
        butsFut->start();
        QObject::connect(butstrrun, SIGNAL(clicked()), butsFut, SLOT(setFlag()));
    }
}

//*****��� ��������� �������� - �������********************************************************
//*****�������� ����������� � �������� �� ������ ��������������� �������***********************
//*********************************************************************************************

void MainWin::setBLineCorrBt(const QString &str)
{
    butsLinesRun->setText(str);
}

void MainWin::createButsCorrThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    Vars->setGroups(vecGr);
    corrBootstr = false;
    linesHotCorr.clear(); linesMewmaCorr.clear();linesHotWCorr.clear(); linesMewmaWCorr.clear();
    linesHotCorr.resize(vecGr.count());linesHotWCorr.resize(vecGr.count());
    linesMewmaCorr.resize(vecGr.count());linesMewmaWCorr.resize(vecGr.count());
    butsCorrThread = new LineSeriesCorr(Vars);

    //����� � �������� - �����
    QObject::connect(butsCorrThread, SIGNAL(processChanged(int)), linesCorrBPrB, SLOT(setValue(int)));
    linesCorrBPrB->setMaximum(Vars->getFileCountButStr());
    //����� � �������� ������
    QObject::connect(butsCorrThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setBLineCorrBt(QString)));
    //��������� � ������ ���������
    QObject::connect(butsCorrThread, SIGNAL(getLinesW(const vecLines*)), this, SLOT(setCorrBW(const vecLines*)));
    QObject::connect(butsCorrThread, SIGNAL(getLines(const vecLines*)), this, SLOT(setCorrB(const vecLines*)));

    QObject::connect(butsCorrThread, SIGNAL(getResLines(const vecLines*)), this, SLOT(setResCorrB(const vecLines*)));
    QObject::connect(butsCorrThread, SIGNAL(getResLinesW(const vecLines*)), this, SLOT(setResCorrBW(const vecLines*)));
    QObject::connect(butsCorrThread, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));


    //Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    //Vars->setGroups(vecGr);
    corrNorm = false;
    normCorrThread = new LineSeriesCorrN(Vars);

    //����� � �������� - �����
    QObject::connect(normCorrThread, SIGNAL(processChanged(int)), linesCorrNPrB, SLOT(setValue(int)));
    linesCorrNPrB->setMaximum(Vars->getFileCountNorm());
    //����� � �������� ������
    QObject::connect(normCorrThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setBLineCorrBt(QString)));
    //��������� � ������ ���������


    QObject::connect(normCorrThread, SIGNAL(getLinesW(const vecLines*)), this, SLOT(setCorrNW(const vecLines*)));
    QObject::connect(normCorrThread, SIGNAL(getLines(const vecLines*)), this, SLOT(setCorrN(const vecLines*)));

    QObject::connect(normCorrThread, SIGNAL(getResLines(const vecLines*)), this, SLOT(setResCorrN(const vecLines*)));
    QObject::connect(normCorrThread, SIGNAL(getResLinesW(const vecLines*)), this, SLOT(setResCorrNW(const vecLines*)));
    QObject::connect(normCorrThread, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));




    if (butsLinesRun->text() == tr("������ ����������� ������� ���� ����� ��� �������� ���������"))
    {
        butsCorrThread->start();
        butsCorrThread->setPriority(QThread::LowPriority);
        normCorrThread->start();
        normCorrThread->setPriority(QThread::LowPriority);
        QObject::connect(butsLinesRun, SIGNAL(clicked()), butsCorrThread, SLOT(setFlag()));
        QObject::connect(butsLinesRun, SIGNAL(clicked()), normCorrThread, SLOT(setFlag()));
    }


}



void MainWin::setCorrB(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    //in->Line_SeriesHArray
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelB->setData(linesModelB->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelB->setData(linesModelB->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelB->setData(linesModelB->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelB->setData(linesModelB->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelB->setData(linesModelB->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelB->setData(linesModelB->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}

void MainWin::setResCorrB(const vecLines *in)
{    
    for (int i = 0; i < vecGr.count(); i++)
    {        
        linesHotCorr[i] += in->Line_SeriesHArray[i];
        linesMewmaCorr[i] += in->Line_SeriesWArray[i];
    }
}

void MainWin::setCorrBW(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelBW->setData(linesModelBW->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelBW->setData(linesModelBW->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelBW->setData(linesModelBW->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelBW->setData(linesModelBW->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelBW->setData(linesModelBW->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelBW->setData(linesModelBW->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}

void MainWin::setResCorrBW(const vecLines *in)
{    
    for (int i = 0; i < vecGr.count(); i++)
    {        
        linesHotWCorr[i] += in->Line_SeriesHArray[i];
        linesMewmaWCorr[i] += in->Line_SeriesWArray[i];
    }
    corrBootstr = true;
    if (corrBootstr && corrNorm)
    {
        butsLinesRun->setText(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
        updateCorrLS();
    }
}

//���������� ������
void MainWin::setBLineCLBt(const QString &str)
{
    butsLinesRunCL->setText(str);
}

void MainWin::createButsCLThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    Vars->setGroups(vecClas);

    clBootstr = false;
    linesHotCl.clear(); linesMewmaCl.clear();linesHotWCl.clear(); linesMewmaWCl.clear();
    linesHotCl.resize(vecClas.count());linesHotWCl.resize(vecClas.count());
    linesMewmaCl.resize(vecClas.count());linesMewmaWCl.resize(vecClas.count());

    butsCLThread = new LineSeriesCorr(Vars);

    //����� � �������� - �����
    QObject::connect(butsCLThread, SIGNAL(processChanged(int)), linesCLBPrB, SLOT(setValue(int)));
    linesCLBPrB->setMaximum(Vars->getFileCountButStr());
    //����� � �������� ������
    QObject::connect(butsCLThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setBLineCLBt(QString)));
    //��������� � ������ ���������
    QObject::connect(butsCLThread, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));

    QObject::connect(butsCLThread, SIGNAL(getLinesW(const vecLines*)), this, SLOT(setCLBW(const vecLines*)));
    QObject::connect(butsCLThread, SIGNAL(getLines(const vecLines*)), this, SLOT(setCLB(const vecLines*)));
    QObject::connect(butsCLThread, SIGNAL(getResLines(const vecLines*)), this, SLOT(setResClB(const vecLines*)));
    QObject::connect(butsCLThread, SIGNAL(getResLinesW(const vecLines*)), this, SLOT(setResClBW(const vecLines*)));

    //Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    //Vars->setGroups(vecClas);
    clNorm = false;
    normCLThread = new LineSeriesCorrN(Vars);

    //����� � �������� - �����
    QObject::connect(normCLThread, SIGNAL(processChanged(int)), linesCLNPrB, SLOT(setValue(int)));
    linesCLNPrB->setMaximum(Vars->getFileCountNorm());
    //����� � �������� ������
    QObject::connect(normCLThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setBLineCLBt(QString)));
    //��������� � ������ ���������
    QObject::connect(normCLThread, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));

    QObject::connect(normCLThread, SIGNAL(getLinesW(const vecLines*)), this, SLOT(setCLNW(const vecLines*)));
    QObject::connect(normCLThread, SIGNAL(getLines(const vecLines*)), this, SLOT(setCLN(const vecLines*)));
    QObject::connect(normCLThread, SIGNAL(getResLines(const vecLines*)), this, SLOT(setResClN(const vecLines*)));
    QObject::connect(normCLThread, SIGNAL(getResLinesW(const vecLines*)), this, SLOT(setResClNW(const vecLines*)));



    if (butsLinesRunCL->text() == tr("������ ����������� ������� ���� ����� ��� �������� ���������"))
    {
        butsCLThread->start();
        butsCLThread->setPriority(QThread::LowPriority);
        normCLThread->start();
        normCLThread->setPriority(QThread::LowPriority);
        QObject::connect(butsLinesRunCL, SIGNAL(clicked()), butsCLThread, SLOT(setFlag()));
        QObject::connect(butsLinesRunCL, SIGNAL(clicked()), normCLThread, SLOT(setFlag()));
    }
}

void MainWin::setResClBW(const vecLines *in)
{
    for (int i = 0; i < vecClas.count(); i++)
    {
        linesHotWCl[i] += in->Line_SeriesHArray[i];
        linesMewmaWCl[i] += in->Line_SeriesWArray[i];
    }
    clBootstr = true;
    if (clBootstr && clNorm)
    {
        butsLinesRunCL->setText(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
        updateClLS();
    }
}

void MainWin::setCLBW(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelCLBW->setData(linesModelCLBW->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelCLBW->setData(linesModelCLBW->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLBW->setData(linesModelCLBW->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelCLBW->setData(linesModelCLBW->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelCLBW->setData(linesModelCLBW->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLBW->setData(linesModelCLBW->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}

void MainWin::setResClB(const vecLines *in)
{
    for (int i = 0; i < vecClas.count(); i++)
    {
        linesHotCl[i] += in->Line_SeriesHArray[i];
        linesMewmaCl[i] += in->Line_SeriesWArray[i];
    }
}

void MainWin::setCLB(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelCLB->setData(linesModelCLB->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelCLB->setData(linesModelCLB->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLB->setData(linesModelCLB->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelCLB->setData(linesModelCLB->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelCLB->setData(linesModelCLB->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLB->setData(linesModelCLB->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}

//*********************************************************************************************
//*****��� ������������ ������� ���************************************************************
//*********************************************************************************************
void MainWin::setDirForNorm()
{
    QString directory = QFileDialog::getExistingDirectory(this,
                               tr("������� �������: "), Vars->getDirForNorm());

    if (directory != "")
    {
        Vars->setDirForNorm(directory);
        normDirLine->setText(Vars->getDirForNorm());
    }
}

void MainWin::setNormBt(const QString &str)
{
    normrun->setText(str);
}

void MainWin::createNormThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    normFut = new NormThread(Vars);
    QObject::connect(normFut, SIGNAL(processChanged(int)), normPrB, SLOT(setValue(int)));
    normPrB->setMaximum(Vars->getFileCountNorm());
    QObject::connect(normFut, SIGNAL(processSetTextBt(QString)), this, SLOT(setNormBt(QString)));
    QObject::connect(normFut, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));

    if (normrun->text() == tr("Create"))
    {
        normFut->start();
        QObject::connect(normrun, SIGNAL(clicked()), normFut, SLOT(setFlag()));
    }
}
//*********************************************************************************************
//*****��� ��������� ������� ���********************************************************
//*****�������� ����������� � �������� �� ������ ��������������� �������***********************
//*********************************************************************************************

void MainWin::setNLineCorrBt(const QString &str)
{
    normLinesRun->setText(str);
}

void MainWin::createNormCorrThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    Vars->setGroups(vecGr);
    corrNorm = false;
    normCorrThread = new LineSeriesCorrN(Vars);
    //����� � �������� - �����
    QObject::connect(normCorrThread, SIGNAL(processChanged(int)), linesCorrNPrB, SLOT(setValue(int)));
    linesCorrNPrB->setMaximum(Vars->getFileCountButStr());
    //����� � �������� ������
    QObject::connect(normCorrThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setNLineCorrBt(QString)));
    //��������� � ������ ���������


    QObject::connect(normCorrThread, SIGNAL(getLinesW(const vecLines*)), this, SLOT(setCorrNW(const vecLines*)));
    QObject::connect(normCorrThread, SIGNAL(getLines(const vecLines*)), this, SLOT(setCorrN(const vecLines*)));

    QObject::connect(normCorrThread, SIGNAL(getResLines(const vecLines*)), this, SLOT(setResCorrN(const vecLines*)));
    QObject::connect(normCorrThread, SIGNAL(getResLinesW(const vecLines*)), this, SLOT(setResCorrNW(const vecLines*)));
    QObject::connect(normCorrThread, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));

    if (normLinesRun->text() == tr("Create"))
    {
        normCorrThread->start();
        QObject::connect(normLinesRun, SIGNAL(clicked()), normCorrThread, SLOT(setFlag()));
    }
}



void MainWin::setResCorrNW(const vecLines *in)
{
    for (int i = 0; i < vecGr.count(); i++)
    {
        linesHotWCorr[i] += in->Line_SeriesHArray[i];
        linesMewmaWCorr[i] += in->Line_SeriesWArray[i];
    }
    corrNorm = true;
    if (corrBootstr && corrNorm)
    {
        butsLinesRun->setText(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
        updateCorrLS();
    }
}

void MainWin::setCorrNW(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelNW->setData(linesModelNW->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelNW->setData(linesModelNW->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelNW->setData(linesModelNW->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelNW->setData(linesModelNW->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelNW->setData(linesModelNW->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelNW->setData(linesModelNW->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }

    count = __null;
}

void MainWin::setResCorrN(const vecLines *in)
{
    for (int i = 0; i < vecGr.count(); i++)
    {
        linesHotCorr[i] += in->Line_SeriesHArray[i];
        linesMewmaCorr[i] += in->Line_SeriesWArray[i];
    }
}

void MainWin::setCorrN(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelN->setData(linesModelN->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelN->setData(linesModelN->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelN->setData(linesModelN->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelN->setData(linesModelN->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelN->setData(linesModelN->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelN->setData(linesModelN->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}

void MainWin::setNLineCLBt(const QString &str)
{
    normLinesRunCL->setText(str);
}

void MainWin::createNormCLThread()
{
    Vars->setCurTime(QDateTime::currentDateTime().toString("dd_hh_mm_ss"));
    Vars->setGroups(vecClas);
    normCLThread = new LineSeriesCorrN(Vars);
    //����� � �������� - �����
    QObject::connect(normCLThread, SIGNAL(processChanged(int)), linesCLNPrB, SLOT(setValue(int)));
    linesCLNPrB->setMaximum(Vars->getFileCountButStr());
    //����� � �������� ������
    QObject::connect(normCLThread, SIGNAL(processSetTextBt(QString)), this, SLOT(setNLineCLBt(QString)));
    //��������� � ������ ���������
    QObject::connect(normCLThread, SIGNAL(finishedThread(QString)), this, SLOT(finishedFuture(QString)));

    QObject::connect(normCLThread, SIGNAL(getLinesW(const vecLines*)), this, SLOT(setCLNW(const vecLines*)));
    QObject::connect(normCLThread, SIGNAL(getLines(const vecLines*)), this, SLOT(setCLN(const vecLines*)));

    if (normLinesRunCL->text() == tr("Create"))
    {
        normCLThread->start();
        QObject::connect(normLinesRunCL, SIGNAL(clicked()), normCLThread, SLOT(setFlag()));
    }
}

void MainWin::setResClNW(const vecLines *in)
{
    for (int i = 0; i < vecClas.count(); i++)
    {
        linesHotWCl[i] += in->Line_SeriesHArray[i];
        linesMewmaWCl[i] += in->Line_SeriesWArray[i];
    }
    clNorm = true;
    if (clBootstr && clNorm)
    {
        butsLinesRunCL->setText(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
        updateClLS();
    }
}

void MainWin::setCLNW(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelCLNW->setData(linesModelCLNW->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelCLNW->setData(linesModelCLNW->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLNW->setData(linesModelCLNW->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelCLNW->setData(linesModelCLNW->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelCLNW->setData(linesModelCLNW->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLNW->setData(linesModelCLNW->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}

void MainWin::setResClN(const vecLines *in)
{
    for (int i = 0; i < vecClas.count(); i++)
    {
        linesHotCl[i] += in->Line_SeriesHArray[i];
        linesMewmaCl[i] += in->Line_SeriesWArray[i];
    }
}

void MainWin::setCLN(const vecLines *in)
{
    int count = std::min(in->Line_SeriesH.count(), in->Line_SeriesW.count());
    for (int i = 0; i < count; i++)
    {
        if (in->Line_SeriesH[i] > 0)
            linesModelCLN->setData(linesModelCLN->index(i, 1, QModelIndex()), QString("%1").arg(in->Line_SeriesH[i]), Qt::EditRole);
        else
            linesModelCLN->setData(linesModelCLN->index(i, 1, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLN->setData(linesModelCLN->index(i, 2, QModelIndex()), QString("%1").arg(in->Line_SeriesHResult[i]), Qt::EditRole);

        if (in->Line_SeriesW[i] > 0)
            linesModelCLN->setData(linesModelCLN->index(i, 3, QModelIndex()), QString("%1").arg(in->Line_SeriesW[i]), Qt::EditRole);
        else
            linesModelCLN->setData(linesModelCLN->index(i, 3, QModelIndex()), QString("OK"), Qt::EditRole);
        linesModelCLN->setData(linesModelCLN->index(i, 4, QModelIndex()), QString("%1").arg(in->Line_SeriesWResult[i]), Qt::EditRole);
    }
    count = __null;
}


void MainWin::readSettings()
{
    //����� ������� ������
    QDesktopWidget desk;
    QRect rect = desk.availableGeometry();
    m_settings->beginGroup("MainWin");              //� ������ [MainWin]
    QPoint pos = m_settings->value("pos", QPoint(0, 0)).toPoint();
    QSize size = m_settings->value("size", rect.size()).toSize();
    //count = m_settings->value("count", count).toInt();
    if (pos.x() < -4)
        pos.setX(-4);
    if (pos.y() < -4)
        pos.setY(-4);
    if (size.width() > rect.width())
        size.setWidth(rect.width());
    if (size.height() > rect.height())
        size.setHeight(rect.height());
    m_settings->endGroup();

    //�������� ������� � ��������� �������� ����:
    resize(size);
    move(pos);
}

void MainWin::writeSettings()
{
    //�������� � ������ [MainWin]
    m_settings->beginGroup("MainWin");

    m_settings->setValue("pos", pos());
    m_settings->setValue("size", size());
    m_settings->setValue("count", count);
    m_settings->endGroup();

    m_settings->sync();         //�������� ��������� �� ����
}

void MainWin::closeEvent(QCloseEvent *event)
{
    //if (QMessageBox::question(this, tr("�����������"), tr("��������� ������?"), QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes) == QMessageBox::Yes)
    {
        writeSettings();        //�������� ��������� ����

        groupsH.clear(); groupsM.clear(); groupsHW.clear(); groupsMW.clear();
        _delete(model); _delete(tvn); _delete(MOSKO); _delete(tvMOSKO); _delete(NORMIR);
        _delete(tvNORMIR); _delete(CORR); _delete(tvCORR); _delete(COVV); _delete(tvCOVV); _delete(INVERSE); _delete(tvINVERSE);

        _delete(linesModelB); _delete(linesModelBW); _delete(linesModelN); _delete(linesModelNW);
        _delete(linesModelCLB); _delete(linesModelCLBW); _delete(linesModelCLN); _delete(linesModelCLNW);
        _delete(loadModelH); _delete(loadModelW);

        _delete(d); _delete(sp); _delete(layout);
        _delete(layout1); _delete(layout2); _delete(layout3); _delete(layout4); _delete(layout5);
        _delete(m_tubw);  tabN.clear();
        _delete(m_settings);
        _delete(openAct);_delete(saveAct);_delete(quitAct);
        _delete(fileMenu);_delete(viewMenu);
        _delete(m_tb);
        fileOpen = ""; fileSave = ""; str = "";
        p = __null; n = __null; m = __null;
        count = __null;
        nextStackP = __null;

        if (Vars != __null)
        {
            workDirectory.rmdir(Vars->getAppWorkDir());
            workDirectory = __null;
        }

        _delete(vvv1);_delete(vvv2);_delete(vvv3);_delete(vvv4);
        _delete(vvv5);_delete(vvv6);_delete(vvv7);_delete(vvv8);
        _delete(butstrrun);_delete(normrun);_delete(normPrB); _delete(normDirBt);
        _delete(butsLinesRun); _delete(normLinesRun);
        _delete(butstrPrB); _delete(butstrDirBt);
        _delete(linesCorrBPrB);_delete(linesCorrNPrB);
        _delete(normDirLine);_delete(butstrDirLine);

        //������ ���������
        _delete(graphD);
        _delete(butsLinesRunCL);_delete(normLinesRunCL);_delete(linesCLBPrB);_delete(createDendro);
        _delete(spbCl);

        //�������
        _delete(graphL);
        _delete(graph);
        _delete(tabsGraph);

        ///_delete(scene);
        //_delete(view);
        //_delete(cannonBox);
        _delete(ChangeGrB); //_delete(HotGrB);


        _delete(tabsHot);
        _delete(tabsMew);
        countWinHot = __null;


        //_delete(lay00R);_delete(lay0R);
        _delete(stack0);
        _delete(lay);//_delete(lay0L);_delete(lay0R);
        _delete(stackmy);
        _delete(mainlay);
        _delete(mymain);
        _delete(clockTimer);_delete(timeLabel);

        _delete(listStage);_delete(listState);_delete(sp_list);_delete(sp_main);
        _delete(mainWidget);
        delete Vars;
        vecGr.clear();vecClas.clear();



        event->accept();        //��������� ����� �� ���������
    }
    //else
    {
        //event->ignore();
    }
}

//--------------------------------------------
MyDelegate::MyDelegate(QObject *parent)
             : QItemDelegate(parent) { }

QWidget *MyDelegate::createEditor(
            QWidget *parent,
            const QStyleOptionViewItem& /* option */,
            const QModelIndex& /* index */) const {
    QLineEdit *editor = new QLineEdit(parent);
    editor->installEventFilter(const_cast<MyDelegate*>(this));
    editor->setStyleSheet(QString(
        "QLineEdit{ background-color: %1 }")
           .arg(QColor(230,250,255).name()));
    return editor;
}

void MyDelegate::setEditorData(
                QWidget *editor,
                const QModelIndex& index) const {
    QString t = index.model()->data(
            index, Qt::EditRole).toString();
    QLineEdit *le = static_cast<QLineEdit*>(editor);
    le->setText(t);
}

void MyDelegate::setModelData(
            QWidget *editor,
            QAbstractItemModel *model,
            const QModelIndex& index) const {
    QLineEdit *le = static_cast<QLineEdit*>(editor);
    QString t = le->text();
    model->setData(index, t);
}

void MyDelegate::updateEditorGeometry(
            QWidget *editor,
            const QStyleOptionViewItem &option,
            const QModelIndex& /* index */) const {
    editor->setGeometry(option.rect.adjusted(-1,-1,1,1));
}





