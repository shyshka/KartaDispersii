#include "externvariables.h"

ExternVariables::ExternVariables(QObject *parent) :
    QObject(parent)
{
    fileCountButStr = __null; fileCountNorm = __null;modeChanged = __null;
    p = __null; n = __null; m = __null;countClasters = __null; intensity = __null;
    appTempDir = ""; dirForNorm = ""; dirForButs = "";currenTime = "";
    dirForSamples = ""; countModelCorr = 0; countModelCl = 0;
    lambdaCorr.clear(); lambdaClaster.clear();delta.clear();regression.clear();
    forDelta = false;

}

ExternVariables::~ExternVariables()
{
    fileCountButStr = __null; fileCountNorm = __null;modeChanged = __null;
    p = __null; n = __null; m = __null;countClasters = __null; intensity = __null;
    lambdaCorr.clear(); lambdaClaster.clear(); countModelCorr = __null; countModelCl = __null;
    appTempDir = ""; dirForNorm = ""; dirForButs = "";currenTime = "";dirForSamples = "";
    listState.clear();groupVars.clear();listLambda.clear();regression.clear();
    data.clear();delta.clear();
    fileName.~QFileInfo();
}

QString ExternVariables::getDirForButs()
{
    QMutexLocker locker(&mutex);

    if (dirForButs == "")
    {
        dirForButs = fileName.absolutePath() + tr("/") +
            QString(tr("%1_%2_%3")).arg(p).arg(n).arg(m) + QObject::tr("/Bootstr");
    }

    return dirForButs;
}

QString ExternVariables::getDirForNorm()
{
    QMutexLocker locker(&mutex);

    if (dirForNorm == "")
    {
        dirForNorm = fileName.absolutePath() + tr("/") +
            QString(tr("%1_%2_%3")).arg(p).arg(n).arg(m) + QObject::tr("/Norm");
    }

    return dirForNorm;
}

QString ExternVariables::getDirForSamples()
{
    QMutexLocker locker(&mutex);

    if (dirForSamples == "")
    {
        dirForSamples = fileName.absolutePath() + tr("/") +
            QString(tr("%1_%2_%3")).arg(p).arg(n).arg(m) + QObject::tr("/Samples");
    }

    return dirForSamples;
}
