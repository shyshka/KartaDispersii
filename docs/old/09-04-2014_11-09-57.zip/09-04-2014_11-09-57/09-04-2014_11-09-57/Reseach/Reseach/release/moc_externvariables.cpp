/****************************************************************************
** Meta object code from reading C++ file 'externvariables.h'
**
** Created: Thu 17. May 09:26:27 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../externvariables.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'externvariables.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ExternVariables[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      35,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      23,   17,   16,   16, 0x0a,
      45,   17,   16,   16, 0x0a,
      68,   17,   16,   16, 0x0a,
      90,   17,   16,   16, 0x0a,
     112,   17,   16,   16, 0x0a,
     134,   17,   16,   16, 0x0a,
     154,   17,   16,   16, 0x0a,
     174,   16,   16,   16, 0x0a,
     192,   17,   16,   16, 0x0a,
     213,   16,   16,   16, 0x0a,
     231,   17,   16,   16, 0x0a,
     257,  253,   16,   16, 0x0a,
     276,  253,   16,   16, 0x0a,
     301,  297,   16,   16, 0x0a,
     324,  297,   16,   16, 0x0a,
     347,  297,   16,   16, 0x0a,
     370,  297,   16,   16, 0x0a,
     404,  396,   16,   16, 0x0a,
     419,  396,   16,   16, 0x0a,
     436,  396,   16,   16, 0x0a,
     468,  459,   16,   16, 0x0a,
     503,  396,   16,   16, 0x0a,
     522,  459,   16,   16, 0x0a,
     559,   17,   16,   16, 0x0a,
     572,  396,   16,   16, 0x0a,
     593,  589,   16,   16, 0x0a,
     609,  297,   16,   16, 0x0a,
     632,  629,   16,   16, 0x0a,
     652,  629,   16,   16, 0x0a,
     675,  629,   16,   16, 0x0a,
     695,  629,   16,   16, 0x0a,
     713,   17,   16,   16, 0x0a,
     736,   17,   16,   16, 0x0a,
     766,  757,   16,   16, 0x0a,
     787,  396,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ExternVariables[] = {
    "ExternVariables\0\0count\0setFileCountVars(int)\0"
    "setFileCountStepV(int)\0setFileCountView(int)\0"
    "setFileCountButs(int)\0setFileCountNorm(int)\0"
    "setVarCorrNorm(int)\0setModeChanged(int)\0"
    "setModeChangedX()\0setModeChangedM(int)\0"
    "setModeChangedR()\0setCountClasters(int)\0"
    "var\0setVarChNorm(bool)\0setVarCovvNorm(bool)\0"
    "str\0setAppTempDir(QString)\0"
    "setDirForNorm(QString)\0setDirForButs(QString)\0"
    "setDirForSamples(QString)\0in_data\0"
    "setData(vecFF)\0setListVar(vecF)\0"
    "setListLambdaVar(vecF)\0item,ind\0"
    "setListVarCh(QTreeWidgetItem*,int)\0"
    "setListClVar(vecF)\0"
    "setListClVarCh(QTreeWidgetItem*,int)\0"
    "setView(int)\0setGroups(vecII)\0in_\0"
    "setAlyfa(float)\0setCurTime(QString)\0"
    "in\0setLambdaCorr(vecF)\0setLambdaClaster(vecF)\0"
    "setDeltaList(vecFF)\0setForDelta(bool)\0"
    "setCountModelCorr(int)\0setCountModelCl(int)\0"
    "in_inten\0setIntensity(double)\0"
    "setRegression(vecRegression)\0"
};

void ExternVariables::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ExternVariables *_t = static_cast<ExternVariables *>(_o);
        switch (_id) {
        case 0: _t->setFileCountVars((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 1: _t->setFileCountStepV((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 2: _t->setFileCountView((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 3: _t->setFileCountButs((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 4: _t->setFileCountNorm((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 5: _t->setVarCorrNorm((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 6: _t->setModeChanged((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 7: _t->setModeChangedX(); break;
        case 8: _t->setModeChangedM((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 9: _t->setModeChangedR(); break;
        case 10: _t->setCountClasters((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 11: _t->setVarChNorm((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 12: _t->setVarCovvNorm((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 13: _t->setAppTempDir((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->setDirForNorm((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->setDirForButs((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->setDirForSamples((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->setData((*reinterpret_cast< const vecFF(*)>(_a[1]))); break;
        case 18: _t->setListVar((*reinterpret_cast< const vecF(*)>(_a[1]))); break;
        case 19: _t->setListLambdaVar((*reinterpret_cast< const vecF(*)>(_a[1]))); break;
        case 20: _t->setListVarCh((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 21: _t->setListClVar((*reinterpret_cast< const vecF(*)>(_a[1]))); break;
        case 22: _t->setListClVarCh((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 23: _t->setView((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 24: _t->setGroups((*reinterpret_cast< const vecII(*)>(_a[1]))); break;
        case 25: _t->setAlyfa((*reinterpret_cast< const float(*)>(_a[1]))); break;
        case 26: _t->setCurTime((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 27: _t->setLambdaCorr((*reinterpret_cast< const vecF(*)>(_a[1]))); break;
        case 28: _t->setLambdaClaster((*reinterpret_cast< const vecF(*)>(_a[1]))); break;
        case 29: _t->setDeltaList((*reinterpret_cast< const vecFF(*)>(_a[1]))); break;
        case 30: _t->setForDelta((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 31: _t->setCountModelCorr((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 32: _t->setCountModelCl((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 33: _t->setIntensity((*reinterpret_cast< const double(*)>(_a[1]))); break;
        case 34: _t->setRegression((*reinterpret_cast< const vecRegression(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ExternVariables::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ExternVariables::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ExternVariables,
      qt_meta_data_ExternVariables, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ExternVariables::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ExternVariables::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ExternVariables::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ExternVariables))
        return static_cast<void*>(const_cast< ExternVariables*>(this));
    return QObject::qt_metacast(_clname);
}

int ExternVariables::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 35)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 35;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
