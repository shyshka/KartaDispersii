/****************************************************************************
** Meta object code from reading C++ file 'sourcegraph.h'
**
** Created: Thu 17. May 09:27:10 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sourcegraph.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sourcegraph.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Plotter[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       9,    8,    8,    8, 0x0a,
      18,    8,    8,    8, 0x0a,
      28,    8,    8,    8, 0x0a,
      41,    8,    8,    8, 0x0a,
      61,   54,    8,    8, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Plotter[] = {
    "Plotter\0\0zoomIn()\0zoomOut()\0savePixmap()\0"
    "copyPixmap()\0action\0slotActivated(QAction*)\0"
};

void Plotter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Plotter *_t = static_cast<Plotter *>(_o);
        switch (_id) {
        case 0: _t->zoomIn(); break;
        case 1: _t->zoomOut(); break;
        case 2: _t->savePixmap(); break;
        case 3: _t->copyPixmap(); break;
        case 4: _t->slotActivated((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Plotter::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Plotter::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Plotter,
      qt_meta_data_Plotter, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Plotter::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Plotter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Plotter::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Plotter))
        return static_cast<void*>(const_cast< Plotter*>(this));
    return QWidget::qt_metacast(_clname);
}

int Plotter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
static const uint qt_meta_data_Curve[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       7,    6,    6,    6, 0x0a,
      16,    6,    6,    6, 0x0a,
      26,    6,    6,    6, 0x0a,
      39,    6,    6,    6, 0x0a,
      59,   52,    6,    6, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Curve[] = {
    "Curve\0\0zoomIn()\0zoomOut()\0savePixmap()\0"
    "copyPixmap()\0action\0slotActivated(QAction*)\0"
};

void Curve::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Curve *_t = static_cast<Curve *>(_o);
        switch (_id) {
        case 0: _t->zoomIn(); break;
        case 1: _t->zoomOut(); break;
        case 2: _t->savePixmap(); break;
        case 3: _t->copyPixmap(); break;
        case 4: _t->slotActivated((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Curve::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Curve::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_Curve,
      qt_meta_data_Curve, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Curve::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Curve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Curve::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Curve))
        return static_cast<void*>(const_cast< Curve*>(this));
    return QWidget::qt_metacast(_clname);
}

int Curve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
static const uint qt_meta_data_PaintDenrogramm[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   16,   16,   16, 0x0a,
      26,   16,   16,   16, 0x0a,
      36,   16,   16,   16, 0x0a,
      49,   16,   16,   16, 0x0a,
      69,   62,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_PaintDenrogramm[] = {
    "PaintDenrogramm\0\0zoomIn()\0zoomOut()\0"
    "savePixmap()\0copyPixmap()\0action\0"
    "slotActivated(QAction*)\0"
};

void PaintDenrogramm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        PaintDenrogramm *_t = static_cast<PaintDenrogramm *>(_o);
        switch (_id) {
        case 0: _t->zoomIn(); break;
        case 1: _t->zoomOut(); break;
        case 2: _t->savePixmap(); break;
        case 3: _t->copyPixmap(); break;
        case 4: _t->slotActivated((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData PaintDenrogramm::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject PaintDenrogramm::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_PaintDenrogramm,
      qt_meta_data_PaintDenrogramm, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &PaintDenrogramm::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *PaintDenrogramm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *PaintDenrogramm::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_PaintDenrogramm))
        return static_cast<void*>(const_cast< PaintDenrogramm*>(this));
    return QWidget::qt_metacast(_clname);
}

int PaintDenrogramm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
