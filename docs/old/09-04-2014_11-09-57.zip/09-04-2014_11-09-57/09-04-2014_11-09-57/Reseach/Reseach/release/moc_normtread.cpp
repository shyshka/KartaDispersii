/****************************************************************************
** Meta object code from reading C++ file 'normtread.h'
**
** Created: Thu 17. May 09:26:33 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../normtread.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'normtread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NormThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: signature, parameters, type, tag, flags
      17,   12,   11,   11, 0x05,
      41,   37,   11,   11, 0x05,
      77,   67,   11,   11, 0x05,
     100,   37,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
     124,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NormThread[] = {
    "NormThread\0\0iter\0processChanged(int)\0"
    "str\0processSetTextBt(QString)\0minn,maxx\0"
    "processRanged(int,int)\0finishedThread(QString)\0"
    "setFlag()\0"
};

void NormThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NormThread *_t = static_cast<NormThread *>(_o);
        switch (_id) {
        case 0: _t->processChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->processSetTextBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->processRanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->finishedThread((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->setFlag(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData NormThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NormThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_NormThread,
      qt_meta_data_NormThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NormThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NormThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NormThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NormThread))
        return static_cast<void*>(const_cast< NormThread*>(this));
    return QThread::qt_metacast(_clname);
}

int NormThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void NormThread::processChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void NormThread::processSetTextBt(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void NormThread::processRanged(int _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void NormThread::finishedThread(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
