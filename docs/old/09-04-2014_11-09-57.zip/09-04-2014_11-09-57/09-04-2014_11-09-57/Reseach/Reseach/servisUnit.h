#ifndef SERVISUNIT_H
#define SERVISUNIT_H

#include <QVector>
#include <QWidget>
#include <QAbstractTableModel>
#include <QFileIconProvider>
#include "mathstat.h"

typedef QVector<QWidget*> vecW;


enum NodeType {  // ��� ����:
    ELEMENT = 0, // �������
    GROUP,       // ������.
};



class Node {
public:
    Node( Node *parentNode = 0,
          const QString& s1 = "",
          const QString& s2 = "",
          const QString& s3 = "",
          const QString& s4 = "",
          const QString& s5 = "",
          NodeType nt = ELEMENT );
    ~Node();

    QString str1, str2, str3, str4, str5;
    NodeType nodeType;
    Node *parent;
    QVector<Node*> children;
};

class NodeModel {
public:
    NodeModel( NodeModel *parentNode = 0,
          const QString& s1 = "",
          const QString& s2 = "",
          const QString& s3 = "",
          const QString& s4 = "",
          const QString& s5 = "",
          const QString& s6 = "",
          NodeType nt = ELEMENT );
    ~NodeModel();

    QString str1, str2, str3, str4, str5, str6;
    NodeType nodeType;
    NodeModel *parent;
    QVector<NodeModel*> children;
};

typedef QVector<Node*> vecN;
typedef QVector<NodeModel*> vecNM;

//----------------------------------------------
class TreeModel : public QAbstractItemModel {
    Q_OBJECT
public:
    TreeModel(QObject *parent = 0);
    ~TreeModel();
    QModelIndex index(int row, int column, const QModelIndex& parent = QModelIndex()) const;
    bool hasChildren(const QModelIndex& parent = QModelIndex()) const;
    QModelIndex parent(const QModelIndex& index) const;
    int rowCount(const QModelIndex& index = QModelIndex()) const;
    int columnCount(const QModelIndex& index = QModelIndex()) const;
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const;
    void setRootNode(Node *node);
    Qt::ItemFlags flags(const QModelIndex& index) const;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole);
    // Qt::DropActions supportedDropActions() const;
    Node *nodeFromIndex(const QModelIndex& index) const;
private:

    Node *rootNode;
    QFileIconProvider ip;
};

class TreeModelling : public QAbstractItemModel {
    Q_OBJECT
public:
    TreeModelling(QObject *parent = 0);
    ~TreeModelling();
    QModelIndex index(int row, int column, const QModelIndex& parent = QModelIndex()) const;
    bool hasChildren(const QModelIndex& parent = QModelIndex()) const;
    QModelIndex parent(const QModelIndex& index) const;
    int rowCount(const QModelIndex& index = QModelIndex()) const;
    int columnCount(const QModelIndex& index = QModelIndex()) const;
    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const;
    void setRootNode(NodeModel *node);
    Qt::ItemFlags flags(const QModelIndex& index) const;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const;
    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole);
    // Qt::DropActions supportedDropActions() const;
    NodeModel *nodeFromIndex(const QModelIndex& index) const;
private:

    NodeModel *rootNodeMod;
    QFileIconProvider ip;
};

//--------------------------------
class MyTableView : public QTableView {
    Q_OBJECT
public:
    MyTableView(QWidget *parent=0);
    ~MyTableView();
    QMenu *menu;
    QAction *deleteRow;
private:
    virtual void contextMenuEvent(QContextMenuEvent *e){
        menu->exec(e->globalPos());}
public slots :
    void slotActivated(QAction *action) {}

protected:
    void mousePressEvent(QMouseEvent *event);
};

//--------------------------------

class ProjectListWidget : public QListWidget
{
    Q_OBJECT

public:
    ProjectListWidget(QWidget *parent = 0):QListWidget(parent){setAcceptDrops(true);}

protected :
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void dragEnterEvent(QDragEnterEvent *event);
    void dragMoveEvent(QDragMoveEvent *event);
    void dropEvent(QDropEvent *event);
    //void keyPressEvent(QKeyEvent *event);
    //void wheelEvent(QWheelEvent *event);

private:
    QPoint startPos;
    void startDrag();
    void sorting();

signals:

    void itemMoved(QListWidgetItem *in_item);
    void itemDropped(const int &ind);

};


class ListModel : public QAbstractListModel
{
    Q_OBJECT

    private:

        vecF        m_records;            //������ nn * 1 = (n * m) * p
        int         p, n, m, nn;            //p - ����� ����������



    public:
        ListModel(QObject *parent = 0, const QString &name = 0);
        ~ListModel();

        int rowCount(const QModelIndex& parent = QModelIndex()) const;

        QVariant headerData(    int             section,
                                Qt::Orientation orientation,
                                int             role = Qt::DisplayRole
                            ) const;

        Qt::ItemFlags flags(const QModelIndex &index) const;

        QVariant data(const QModelIndex& index, int role) const;


        bool setData(       const QModelIndex& index,
                            const QVariant&    value,
                            int                role
                    );


        void toModel_vecF(vecF array);

        QString     nameModel;
};



class TableModel : public QAbstractTableModel
{
    Q_OBJECT

private:
    vecFF       m_records;            //������� nn * p = (n * m) * p (������� ����������� ������, ����� �������)
    //int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������
    QFileIconProvider ip;
public:

    int         p, n, m, nn, in_nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������

    TableModel(QObject *parent = 0, const QString &name = 0);
    ~TableModel();

    int rowCount(const QModelIndex& parent = QModelIndex()) const;
    int columnCount(const QModelIndex& parent = QModelIndex()) const;

    QVariant headerData(int section,
                        Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;
    QVariant data(const QModelIndex& index,
                  int role = Qt::DisplayRole) const;

    bool hasChildren(const QModelIndex& parent = QModelIndex()) const;
    bool setData(const QModelIndex& index,
                 const QVariant& value,
                 int role=Qt::EditRole);
    bool insertRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    bool removeRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    bool loadData(const QString& fileName);
    bool saveData(const bool mode, const QString& fileName);
    vecFF toArray();
    void toModel(const vecFF &array, int viborka, const int &nn_);


    QString     nameModel;
};

class LinesSeriesModel : public QAbstractTableModel
{
    Q_OBJECT

private:
    vecSS       m_records;            //������� nn * p = (n * m) * p (������� ����������� ������, ����� �������)
    //int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������
    QFileIconProvider ip;
public:

    int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������

    LinesSeriesModel(QObject *parent = 0, const QString &name = 0);
    ~LinesSeriesModel();

    int rowCount(const QModelIndex& parent = QModelIndex()) const;
    int columnCount(const QModelIndex& parent = QModelIndex()) const;

    QVariant headerData(int section,
                        Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;
    QVariant data(const QModelIndex& index,
                  int role = Qt::DisplayRole) const;

    bool hasChildren(const QModelIndex& parent = QModelIndex()) const;
    bool setData(const QModelIndex& index,
                 const QString& value,
                 int role=Qt::EditRole);
    bool insertRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    bool removeRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    //bool loadData(const QString& fileName);
    //bool saveData(const bool mode, const QString& fileName);
    //vecSS toArray();
    void toModel(const vecSS &array);


    QString     nameModel;
};

class LinesResultsModel : public QAbstractTableModel
{
    Q_OBJECT

private:
    vecSS       m_records;            //������� nn * p = (n * m) * p (������� ����������� ������, ����� �������)
    //int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������
    QFileIconProvider ip;
public:

    int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������

    LinesResultsModel(QObject *parent = 0, const QString &name = 0);
    ~LinesResultsModel();

    int rowCount(const QModelIndex& parent = QModelIndex()) const;
    int columnCount(const QModelIndex& parent = QModelIndex()) const;

    QVariant headerData(int section,
                        Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;
    QVariant data(const QModelIndex& index,
                  int role = Qt::DisplayRole) const;

    bool hasChildren(const QModelIndex& parent = QModelIndex()) const;
    bool setData(const QModelIndex& index,
                 const QString& value,
                 int role=Qt::EditRole);
    bool insertRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    bool removeRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    //bool loadData(const QString& fileName);
    //bool saveData(const bool mode, const QString& fileName);
    //vecSS toArray();
    void toModel(const vecSS &array);


    QString     nameModel;
};

class ListChangedModel : public QAbstractTableModel
{
    Q_OBJECT

private:
    vecSS       m_records;            //������� nn * p = (n * m) * p (������� ����������� ������, ����� �������)
    //int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������
    QFileIconProvider ip;
public:

    int         p, n, m, nn;            //p - ����� ����������
                                //n - ������ ���������� �������
                                //m - ����� �������

    ListChangedModel(QObject *parent = 0, const QString &name = 0);
    ~ListChangedModel();

    int rowCount(const QModelIndex& parent = QModelIndex()) const;
    int columnCount(const QModelIndex& parent = QModelIndex()) const;

    QVariant headerData(int section,
                        Qt::Orientation orientation,
                        int role = Qt::DisplayRole) const;
    Qt::ItemFlags flags(const QModelIndex &index) const;
    QVariant data(const QModelIndex& index,
                  int role = Qt::DisplayRole) const;

    bool hasChildren(const QModelIndex& parent = QModelIndex()) const;
    bool setData(const QModelIndex& index,
                 const QVariant& value,
                 int role=Qt::EditRole);
    bool insertRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    bool removeRows(int row, int count,
                    const QModelIndex& parent=QModelIndex());
    //bool loadData(const QString& fileName);
    //bool saveData(const bool mode, const QString& fileName);
    //vecSS toArray();
    void toModel(const vecSS &array);


    QString     nameModel;
};




#endif // SERVISUNIT_H
