#ifndef GLDRAW_H
#define GLDRAW_H

//#include <QGLWidget>

/*class SourceGraph;
QT_BEGIN_NAMESPACE
class QPaintEvent;
class QWidget;
QT_END_NAMESPACE

class GLDraw : public QGLWidget
{
    Q_OBJECT



public:
    GLDraw(QWidget *parent = 0);

protected:
    void paintEvent(QPaintEvent *event);

private:
    SourceGraph *helper;
    int elapsed;
};*/

#endif // GLDRAW_H
