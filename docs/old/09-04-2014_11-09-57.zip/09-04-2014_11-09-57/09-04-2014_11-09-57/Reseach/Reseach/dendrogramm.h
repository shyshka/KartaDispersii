#ifndef DENDROGRAMM_H
#define DENDROGRAMM_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"

class Dendrogramm : public QThread
{
    Q_OBJECT

    QWaitCondition cond;
    QMutex mutex;

    ExternVariables *Vars_;
    int p, n, m, nn;
    vecFF in_data;
    vecDCl  clasters;
    bool flag;


    void run();

    float _distance(const float &n1, const float &n2);
    float __distance(const vecF &n1, const vecF &n2);
    float __pirson(const vecF &n1, const vecF &n2);
    void _claster();
    void _claster_p();
    bool _inListDiff(const vecDif &data, const int &n1, const int &n2);

public:

    explicit Dendrogramm(ExternVariables *vars);
    ~Dendrogramm();

public slots:

    void setFlag(){QMutexLocker locker(&mutex); flag = true;}


signals:

    void finishedThread(const QString &str);
    void processSetTextBt(const QString &str);
    void getData(TDenroGramm *out);
};


#endif // DENDROGRAMM_H
