#include "linesvariables.h"

LinesVariables::LinesVariables(QObject *parent) :
    QObject(parent)
{
    p = 0; n = 0; m = 0;
    fileCountButStr = 0; fileCountNorm = 0;
    appTempDir = ""; dirForNorm = ""; dirForButs = "";
}

LinesVariables::~LinesVariables()
{
    vectorVarCh.clear();
    p = __null; n = __null; m = __null;
    fileCountButStr = __null; fileCountNorm = __null;
    appTempDir = ""; dirForNorm = ""; dirForButs = "";
    data.clear();
}

