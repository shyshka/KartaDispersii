#ifndef LINESERIESCL_H
#define LINESERIESCL_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"
#include "linesvariables.h"

class LineSeriesCl : public QThread
{
    QWaitCondition cond;
    QMutex mutex;

    ExternVariables *Vars_;
    int p, n, m, nn, count;
    vecII data, gr_data;
    vecFF in_data, corr_data;

    void run();

public:
    explicit LineSeriesCl(ExternVariables *Vars_);
    ~LineSeriesCl();

signals:

    void processChanged(int iter);
    void processSetTextBt(const QString &str);
    void processRanged(int minn, int maxx);
    void finishedThread(const QString &str);

    void getLinesW(const vecLines *lines);
    void getLines(const vecLines *lines);

public slots:

    void setFlag(){QMutexLocker locker(&mutex); flag = true;}
};

#endif // LINESERIESCL_H
