#ifndef NORMTREAD_H
#define NORMTREAD_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"

class NormThread : public QThread
{
    Q_OBJECT

    QString nameWorkDirF, currenTime;
    vecFF data;
    int p, n, m, nn, iterCount, varCorr;

    QMutex mutex;

    volatile bool flag;
    bool varCorrCh, CovvVarr;

    QWaitCondition cond;

    void run();

public:

    explicit NormThread(ExternVariables *vars);
    ~NormThread();

signals:

    void processChanged(int iter);
    void processSetTextBt(const QString &str);
    void processRanged(int minn, int maxx);
    void finishedThread(const QString &str);

public slots:

    void setFlag(){QMutexLocker locker(&mutex); flag = true;}
};

#endif // NORMTREAD_H
