#ifndef CLASTERGROUP_H
#define CLASTERGROUP_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"

class ClasterGroup : public QThread
{
    Q_OBJECT

    QWaitCondition cond;
    QMutex mutex;

    ExternVariables *Vars_;
    int p, n, m, nn, count;
    vecII data, gr_data;
    vecFF in_data;
    vecCl clasters, clastersNew;

    void run();

    float _distance(const float &n1, const float &n2);
    float __distance(const vecF &n1, const vecF &n2);
    float _centroid(const vecFF &data);
    void _claster();
    void __claster();
    float _num_distance(const int &n1, const int &n2);
    bool _inListDiff(const vecDif &data, const int &n1, const int &n2);

public:

    explicit ClasterGroup(ExternVariables *vars);
    ~ClasterGroup();

signals:

    void getData(vecII out);

};

#endif // CLASTERGROUP_H
