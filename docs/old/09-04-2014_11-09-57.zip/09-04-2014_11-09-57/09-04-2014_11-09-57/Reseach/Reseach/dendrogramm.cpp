#include "dendrogramm.h"
#include "mathstat.cpp"

Dendrogramm::Dendrogramm(ExternVariables *vars):QThread()
{
    mutex.lock();

    p = vars->getFileCountVars();
    n = vars->getFileCountStepV();
    m = vars->getFileCountView();
    nn = n * m;

    //in_data = _normirovka(vars->getData());
    in_data = vars->getData();
    flag = false;

    mutex.unlock();
}

Dendrogramm::~Dendrogramm()
{
    mutex.lock();
    p = __null;  n = __null;  m = __null;  nn = __null;
    in_data.clear();clasters.clear();
    cond.wakeAll();
    mutex.unlock();
    wait();
}

void Dendrogramm::run()
{
    processSetTextBt(tr("������"));

    _claster();

    emit getData(clasters[0]);
    processSetTextBt(tr("������������"));

    emit terminated();
    emit terminate();

    exec();
}

//������ ���������� ����� ����� ����������: ������� ����������� "������������� ����������"
inline float __fastcall Dendrogramm::_distance(const float &n1, const float &n2)
{
    //���� ���� ����� - �������������
    if ((n2 < 0) && (n1 < 0))
        if (n2 <= n1)
            return fabs(n1 - n2);
        else
            return fabs(n2 - n1);
    else
        return fabs(n2 - n1);
}

//������ ���������� ����� ����� ��������� ��������: ������� ����������� "������������� ����������"
inline float __fastcall Dendrogramm::__distance(const vecF &n1, const vecF &n2)
{
    float result = __null;
    int count = std::min(n1.count(), n2.count()), i = __null;

    for (i = 0; i < count; i++)
        result += _distance(n1[i], n2[i]);
    result /= count;

    count = __null; i = __null;
    return result;
}

inline float __fastcall Dendrogramm::__pirson(const vecF &n1, const vecF &n2)
{
    float result = __null, sum1 = __null, sum2 = __null, sum1sq = __null, sum2sq = __null, psum = __null, num = __null, den = __null;
    int count = std::min(n1.count(), n2.count()), i = __null;

    for (i = 0; i < count; i++)
    {
        sum1 += n1[i];
        sum2 += n2[i];
        sum1sq += n1[i] * n1[i];
        sum2sq += n2[i] * n2[i];
        psum += n1[i] * n2[i];
    }
    num = psum - (sum1 * sum2 / count);
    den = sqrt( (sum1sq - sum1 * sum1 / count) * (sum2sq - sum2 * sum2 / count) );
    if (den == 0) result = 0.0;
    result = 1 - num / den;

    count = __null; i = __null; sum1 = __null; sum2 = __null; sum1sq = __null; sum2sq = __null; psum = __null;
    return result;
}

inline bool __fastcall Dendrogramm::_inListDiff(const vecDif &data, const int &n1, const int &n2)
{
    for (int i = 0; i < data.count(); i ++)
        if ((data[i].I == n1)&&(data[i].I == n2)&&(data[i].J == n1)&&(data[i].J == n2))
            return true;
    return false;
}

//������������� �� ������ ���� ���������� ����� ����������� �� ���� �����������
void Dendrogramm::_claster()
{
    int i = __null, j = __null, k = __null, h = __null, oldCl = __null;
    vecDif listCl;

    int currentclasterid = -1;

    //clasters.resize(p);
    for (k = 0; k < p; k++)
    {
        TDenroGramm *claster_i = new TDenroGramm;
        clasters.push_back(claster_i);

        clasters[k]->id = k;
        clasters[k]->leftNumber = __null;
        clasters[k]->rightNumber = __null;
        clasters[k]->left = __null;
        clasters[k]->right = __null;
        clasters[k]->distance = __null;
        clasters[k]->_data_.resize(nn);
        for (j = 0; j < nn; j++)
            clasters[k]->_data_[j] = in_data[k][j];
    }

    int size = clasters.count();
    while (size > 1)
    {
        if (flag)
        {
            emit processSetTextBt(tr("������������"));
            emit finishedThread(tr("�������� �������������... "));
            break;
        }

        Difference closest;
        closest.I = 0; closest.J = 1;
        closest.Distance = __distance(clasters[0]->_data_, clasters[1]->_data_);

        for (i = 0; i < size; i++)
            for (j = i + 1; j < size; j++)
            {
                Difference temp;
                temp.I = __null; temp.J = __null; temp.Distance = __null;
                if (!_inListDiff(listCl, clasters[i]->id, clasters[j]->id))
                {
                    temp.I = i; temp.J = j;
                    temp.Distance = __distance(clasters[i]->_data_, clasters[j]->_data_);
                    listCl.push_back(temp);
                }

                if (temp.Distance < closest.Distance)
                    closest = temp;

                temp.I = __null; temp.J = __null;
                temp.Distance = __null;
            }
        TDenroGramm *newClaster = new TDenroGramm;
        newClaster->id = currentclasterid;
        newClaster->left = clasters[closest.I];
        newClaster->right = clasters[closest.J];
        newClaster->leftNumber = closest.I;
        newClaster->rightNumber = closest.J;
        newClaster->distance = closest.Distance;
        newClaster->_data_.resize(nn);
        for (j = 0; j < nn; j++)
            newClaster->_data_[j] = (clasters[closest.I]->_data_[j] + clasters[closest.J]->_data_[j]) / 2;

        if (closest.J > closest.I)
        {
            clasters.remove(closest.J, 1);
            clasters.remove(closest.I, 1);
        }
        else
        {
            clasters.remove(closest.I, 1);
            clasters.remove(closest.J, 1);
        }

        clasters.push_back(newClaster);

        closest.I = __null; closest.J = __null;
        closest.Distance = __null;

        currentclasterid -= 1;

        size = clasters.count();
    }
    if (size == 1)  emit finishedThread(tr("������������ ������������� �������."));

    size = __null;
    listCl.clear();
    i = __null; j = __null; k = __null; h = __null; oldCl = __null;

}

void Dendrogramm::_claster_p()
{
    int i = __null, j = __null, k = __null, h = __null, oldCl = __null;
    vecDif listCl;

    int currentclasterid = -1;

    //clasters.resize(p);
    for (k = 0; k < p; k++)
    {
        TDenroGramm *claster_i = new TDenroGramm;
        clasters.push_back(claster_i);

        clasters[k]->id = k;
        clasters[k]->leftNumber = __null;
        clasters[k]->rightNumber = __null;
        clasters[k]->left = __null;
        clasters[k]->right = __null;
        clasters[k]->distance = __null;
        clasters[k]->_data_.resize(nn);
        for (j = 0; j < nn; j++)
            clasters[k]->_data_[j] = in_data[k][j];
    }

    int size = clasters.count();
    while (size > 1)
    {
        if (flag)
        {
            emit processSetTextBt(tr("������������"));
            emit finishedThread(tr("�������� �������������... "));
            break;
        }

        Difference closest;
        closest.I = 0; closest.J = 1;
        closest.Distance = __pirson(clasters[0]->_data_, clasters[1]->_data_);

        for (i = 0; i < size; i++)
            for (j = i + 1; j < size; j++)
            {
                Difference temp;
                temp.I = __null; temp.J = __null; temp.Distance = __null;
                if (!_inListDiff(listCl, clasters[i]->id, clasters[j]->id))
                {
                    temp.I = i; temp.J = j;
                    temp.Distance = __pirson(clasters[i]->_data_, clasters[j]->_data_);
                    listCl.push_back(temp);
                }

                if (temp.Distance < closest.Distance)
                    closest = temp;

                temp.I = __null; temp.J = __null;
                temp.Distance = __null;
            }
        TDenroGramm *newClaster = new TDenroGramm;
        newClaster->id = currentclasterid;
        newClaster->left = clasters[closest.I];
        newClaster->right = clasters[closest.J];
        newClaster->leftNumber = closest.I;
        newClaster->rightNumber = closest.J;
        newClaster->distance = closest.Distance;
        newClaster->_data_.resize(nn);
        for (j = 0; j < nn; j++)
            newClaster->_data_[j] = (clasters[closest.I]->_data_[j] + clasters[closest.J]->_data_[j]) / 2;

        if (closest.J > closest.I)
        {
            clasters.remove(closest.J, 1);
            clasters.remove(closest.I, 1);
        }
        else
        {
            clasters.remove(closest.I, 1);
            clasters.remove(closest.J, 1);
        }

        clasters.push_back(newClaster);

        closest.I = __null; closest.J = __null;
        closest.Distance = __null;

        currentclasterid -= 1;

        size = clasters.count();
    }
    if (size == 1)  emit finishedThread(tr("������������ ������������� �������."));

    size = __null;
    listCl.clear();
    i = __null; j = __null; k = __null; h = __null; oldCl = __null;

}
