/********************************************************************************
** Form generated from reading ui file 'stackedwidget.ui'
**
** Created: Thu 30. Jun 09:12:12 2011
**      by: Qt User Interface Compiler version 4.5.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_STACKEDWIDGET_H
#define UI_STACKEDWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QStackedWidget>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StackedWidget
{
public:
    QWidget *page_2;
    QWidget *page;

    void setupUi(QStackedWidget *StackedWidget)
    {
        if (StackedWidget->objectName().isEmpty())
            StackedWidget->setObjectName(QString::fromUtf8("StackedWidget"));
        StackedWidget->resize(400, 300);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        StackedWidget->addWidget(page_2);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        StackedWidget->addWidget(page);

        retranslateUi(StackedWidget);

        StackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(StackedWidget);
    } // setupUi

    void retranslateUi(QStackedWidget *StackedWidget)
    {
        StackedWidget->setWindowTitle(QApplication::translate("StackedWidget", "StackedWidget", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(StackedWidget);
    } // retranslateUi

};

namespace Ui {
    class StackedWidget: public Ui_StackedWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STACKEDWIDGET_H
