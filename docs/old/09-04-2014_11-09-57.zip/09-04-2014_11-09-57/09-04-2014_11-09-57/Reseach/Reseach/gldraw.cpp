#include <QtGui>
#include "gldraw.h"
#include "sourcegraph.h"
/*
GLDraw::GLDraw(QWidget *parent)
    : QGLWidget(parent)
{
    elapsed = 0;
}

void GLDraw::paintEvent(QPaintEvent *event)
{

}
*/
