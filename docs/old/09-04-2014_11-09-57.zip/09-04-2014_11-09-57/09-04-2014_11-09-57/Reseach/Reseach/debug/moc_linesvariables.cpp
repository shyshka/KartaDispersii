/****************************************************************************
** Meta object code from reading C++ file 'linesvariables.h'
**
** Created: Thu 17. May 01:06:32 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../linesvariables.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'linesvariables.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_LinesVariables[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      22,   16,   15,   15, 0x0a,
      44,   16,   15,   15, 0x0a,
      67,   16,   15,   15, 0x0a,
      89,   16,   15,   15, 0x0a,
     102,   16,   15,   15, 0x0a,
     124,   16,   15,   15, 0x0a,
     154,  146,   15,   15, 0x0a,
     180,  171,   15,   15, 0x0a,
     215,  146,   15,   15, 0x0a,
     234,  230,   15,   15, 0x0a,
     257,  230,   15,   15, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_LinesVariables[] = {
    "LinesVariables\0\0count\0setFileCountVars(int)\0"
    "setFileCountStepV(int)\0setFileCountView(int)\0"
    "setView(int)\0setFileCountButs(int)\0"
    "setFileCountNorm(int)\0in_data\0"
    "setListVar(vecF)\0item,ind\0"
    "setListVarCh(QTreeWidgetItem*,int)\0"
    "setData(vecFF)\0str\0setDirForNorm(QString)\0"
    "setDirForButs(QString)\0"
};

void LinesVariables::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        LinesVariables *_t = static_cast<LinesVariables *>(_o);
        switch (_id) {
        case 0: _t->setFileCountVars((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 1: _t->setFileCountStepV((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 2: _t->setFileCountView((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 3: _t->setView((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 4: _t->setFileCountButs((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 5: _t->setFileCountNorm((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 6: _t->setListVar((*reinterpret_cast< const vecF(*)>(_a[1]))); break;
        case 7: _t->setListVarCh((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 8: _t->setData((*reinterpret_cast< const vecFF(*)>(_a[1]))); break;
        case 9: _t->setDirForNorm((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->setDirForButs((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData LinesVariables::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject LinesVariables::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_LinesVariables,
      qt_meta_data_LinesVariables, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &LinesVariables::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *LinesVariables::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *LinesVariables::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LinesVariables))
        return static_cast<void*>(const_cast< LinesVariables*>(this));
    return QObject::qt_metacast(_clname);
}

int LinesVariables::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
