/****************************************************************************
** Meta object code from reading C++ file 'lineseriescorrn.h'
**
** Created: Mon 21. May 00:30:10 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../lineseriescorrn.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lineseriescorrn.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_LineSeriesCorrN[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: signature, parameters, type, tag, flags
      22,   17,   16,   16, 0x05,
      46,   42,   16,   16, 0x05,
      82,   72,   16,   16, 0x05,
     105,   42,   16,   16, 0x05,
     135,  129,   16,   16, 0x05,
     162,  129,   16,   16, 0x05,
     188,  129,   16,   16, 0x05,
     218,  129,   16,   16, 0x05,

 // slots: signature, parameters, type, tag, flags
     247,   16,   16,   16, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_LineSeriesCorrN[] = {
    "LineSeriesCorrN\0\0iter\0processChanged(int)\0"
    "str\0processSetTextBt(QString)\0minn,maxx\0"
    "processRanged(int,int)\0finishedThread(QString)\0"
    "lines\0getLinesW(const vecLines*)\0"
    "getLines(const vecLines*)\0"
    "getResLinesW(const vecLines*)\0"
    "getResLines(const vecLines*)\0setFlag()\0"
};

void LineSeriesCorrN::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        LineSeriesCorrN *_t = static_cast<LineSeriesCorrN *>(_o);
        switch (_id) {
        case 0: _t->processChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->processSetTextBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->processRanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: _t->finishedThread((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->getLinesW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 5: _t->getLines((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 6: _t->getResLinesW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 7: _t->getResLines((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 8: _t->setFlag(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData LineSeriesCorrN::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject LineSeriesCorrN::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_LineSeriesCorrN,
      qt_meta_data_LineSeriesCorrN, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &LineSeriesCorrN::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *LineSeriesCorrN::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *LineSeriesCorrN::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_LineSeriesCorrN))
        return static_cast<void*>(const_cast< LineSeriesCorrN*>(this));
    return QThread::qt_metacast(_clname);
}

int LineSeriesCorrN::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void LineSeriesCorrN::processChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LineSeriesCorrN::processSetTextBt(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void LineSeriesCorrN::processRanged(int _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void LineSeriesCorrN::finishedThread(const QString & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void LineSeriesCorrN::getLinesW(const vecLines * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void LineSeriesCorrN::getLines(const vecLines * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void LineSeriesCorrN::getResLinesW(const vecLines * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void LineSeriesCorrN::getResLines(const vecLines * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_END_MOC_NAMESPACE
