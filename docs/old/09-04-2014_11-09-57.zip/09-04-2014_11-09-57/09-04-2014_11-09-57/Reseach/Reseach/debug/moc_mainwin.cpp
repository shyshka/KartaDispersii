/****************************************************************************
** Meta object code from reading C++ file 'mainwin.h'
**
** Created: Mon 21. May 00:30:04 2012
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwin.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyDelegate[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_MyDelegate[] = {
    "MyDelegate\0"
};

void MyDelegate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData MyDelegate::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyDelegate::staticMetaObject = {
    { &QItemDelegate::staticMetaObject, qt_meta_stringdata_MyDelegate,
      qt_meta_data_MyDelegate, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyDelegate::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyDelegate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyDelegate::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyDelegate))
        return static_cast<void*>(const_cast< MyDelegate*>(this));
    return QItemDelegate::qt_metacast(_clname);
}

int MyDelegate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QItemDelegate::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_MainWin[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
     113,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,    9,    8,    8, 0x05,

 // slots: signature, parameters, type, tag, flags
      38,    8,    8,    8, 0x08,
      50,    8,    8,    8, 0x08,
      69,    8,   63,    8, 0x08,
      80,    8,   63,    8, 0x08,
     104,    8,   93,    8, 0x08,
     124,    8,   93,    8, 0x08,
     151,    8,  146,    8, 0x08,
     162,    8,  146,    8, 0x08,
     180,    8,  146,    8, 0x08,
     204,  198,    8,    8, 0x08,
     230,  198,    8,    8, 0x08,
     258,  198,    8,    8, 0x08,
     287,    8,  146,    8, 0x08,
     301,    8,  146,    8, 0x08,
     312,    8,    8,    8, 0x08,
     331,    8,    8,    8, 0x08,
     354,  350,    8,    8, 0x08,
     373,  350,    8,    8, 0x08,
     392,    8,    8,    8, 0x08,
     408,    8,    8,    8, 0x08,
     434,  424,    8,    8, 0x08,
     460,  424,    8,    8, 0x08,
     492,  484,    8,    8, 0x08,
     534,  530,    8,    8, 0x08,
     563,  530,    8,    8, 0x08,
     594,    8,    8,    8, 0x08,
     610,    8,    8,    8, 0x08,
     629,    8,    8,    8, 0x08,
     647,    8,    8,    8, 0x08,
     668,  484,    8,    8, 0x08,
     697,    8,    8,    8, 0x08,
     720,    8,    8,    8, 0x08,
     740,  350,    8,    8, 0x08,
     764,  350,    8,    8, 0x08,
     795,  787,    8,    8, 0x08,
     815,    8,    8,    8, 0x08,
     838,  350,    8,    8, 0x08,
     862,    8,    8,    8, 0x08,
     879,  876,    8,    8, 0x08,
     897,  876,    8,    8, 0x08,
     924,  876,    8,    8, 0x08,
     953,  876,    8,    8, 0x08,
     983,  876,    8,    8, 0x08,
    1027, 1009,    8,    8, 0x08,
    1064, 1009,    8,    8, 0x08,
    1102, 1009,    8,    8, 0x08,
    1140, 1009,    8,    8, 0x08,
    1179,  876,    8,    8, 0x08,
    1206,  876,    8,    8, 0x08,
    1232,  876,    8,    8, 0x08,
    1262,  876,    8,    8, 0x08,
    1297, 1291,    8,    8, 0x08,
    1314,  198,    8,    8, 0x08,
    1342,    8,    8,    8, 0x08,
    1354,    8,    8,    8, 0x08,
    1370,    8,    8,    8, 0x08,
    1400, 1385,    8,    8, 0x08,
    1427, 1385,    8,    8, 0x08,
    1455,    8,    8,    8, 0x08,
    1468,  876,    8,    8, 0x08,
    1491,    8,    8,    8, 0x08,
    1510,    8, 1502,    8, 0x08,
    1527,  350,    8,    8, 0x08,
    1549,    8,    8,    8, 0x08,
    1570,    8,    8,    8, 0x08,
    1592,  350,    8,    8, 0x08,
    1614,  876,    8,    8, 0x08,
    1641,  876,    8,    8, 0x08,
    1669,    8,    8,    8, 0x08,
    1690,  350,    8,    8, 0x08,
    1712,  876,    8,    8, 0x08,
    1740,  876,    8,    8, 0x08,
    1767, 1009,    8,    8, 0x08,
    1806, 1009,    8,    8, 0x08,
    1846, 1009,    8,    8, 0x08,
    1886, 1009,    8,    8, 0x08,
    1939, 1927,    8,    8, 0x08,
    1958, 1291,    8,    8, 0x08,
    1977,  198,    8,    8, 0x08,
    2007,    8,    8,    8, 0x08,
    2021,    8,    8,    8, 0x08,
    2039,  350,    8,    8, 0x08,
    2064,  787,    8,    8, 0x08,
    2086, 1385,    8,    8, 0x08,
    2115, 1385,    8,    8, 0x08,
    2145,  876,    8,    8, 0x08,
    2161,  876,    8,    8, 0x08,
    2186,  876,    8,    8, 0x08,
    2210,  876,    8,    8, 0x08,
    2235,  876,    8,    8, 0x08,
    2259,    8,    8,    8, 0x08,
    2279,  350,    8,    8, 0x08,
    2300,    8,    8,    8, 0x08,
    2324, 2317,    8,    8, 0x08,
    2356,  876,    8,    8, 0x08,
    2381,  350,    8,    8, 0x08,
    2405,    8,    8,    8, 0x08,
    2413,    8,    8,    8, 0x08,
    2441, 2429,    8,    8, 0x08,
    2469, 2466,    8,    8, 0x08,
    2494,    8,    8,    8, 0x08,
    2510,    8,    8,    8, 0x08,
    2526, 2522,    8,    8, 0x08,
    2541, 2522,    8,    8, 0x08,
    2557,    8,    8,    8, 0x08,
    2569,    8,    8,    8, 0x08,
    2583, 2522,    8,    8, 0x08,
    2601, 2522,    8,    8, 0x08,
    2620,    8,    8,    8, 0x08,
    2636,  876,    8,    8, 0x08,
    2658,  876,    8,    8, 0x08,
    2685, 2678,    8,    8, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWin[] = {
    "MainWin\0\0iter\0processNormChanged(int)\0"
    "createWin()\0calc_begin()\0Node*\0"
    "InitTree()\0InitTreeCl()\0NodeModel*\0"
    "InitTreeModelling()\0InitTreeModellingCl()\0"
    "bool\0openFile()\0openFileForMonH()\0"
    "openFileForMonW()\0index\0"
    "groupChanged(QModelIndex)\0"
    "groupClChanged(QModelIndex)\0"
    "groupModChanged(QModelIndex)\0openFileFor()\0"
    "saveFile()\0createButsThread()\0"
    "createNormThread()\0str\0setButsBt(QString)\0"
    "setNormBt(QString)\0setDirForButs()\0"
    "setDirForNorm()\0in_Widget\0"
    "createRegreCorr(QWidget*)\0"
    "createMGKCorr(QWidget*)\0in_item\0"
    "createDialogFWidget(QListWidgetItem*)\0"
    "ind\0createDialogFreeFWidget(int)\0"
    "createDialogFactorsWidget(int)\0"
    "acceptChanges()\0createResression()\0"
    "clearResression()\0deleteChangesRegre()\0"
    "deleteItem(QListWidgetItem*)\0"
    "createButsCorrThread()\0createModelThread()\0"
    "setBLineCorrBt(QString)\0setModelBtRun(QString)\0"
    "in_iter\0setModelPrBRun(int)\0"
    "createNormCorrThread()\0setNLineCorrBt(QString)\0"
    "calc_groups()\0in\0setCorrStr(vecII)\0"
    "setCorrBW(const vecLines*)\0"
    "setResCorrB(const vecLines*)\0"
    "setResCorrBW(const vecLines*)\0"
    "setCorrB(const vecLines*)\0in,idGroup,idIter\0"
    "setModelRes(const vecLines*,int,int)\0"
    "setModelResW(const vecLines*,int,int)\0"
    "setModelNRes(const vecLines*,int,int)\0"
    "setModelNResW(const vecLines*,int,int)\0"
    "setCorrNW(const vecLines*)\0"
    "setCorrN(const vecLines*)\0"
    "setResCorrNW(const vecLines*)\0"
    "setResCorrN(const vecLines*)\0count\0"
    "setLbLambda(int)\0setListBLambda(QModelIndex)\0"
    "deleteRow()\0resetLbLambda()\0updateCorrLS()\0"
    "idGroup,idIter\0updateModelSimple(int,int)\0"
    "updateModelSimpleW(int,int)\0updateClLS()\0"
    "setCheckedGraphs(bool)\0showTime()\0"
    "QString\0getCurrentTime()\0setListState(QString)\0"
    "createButsCLThread()\0createModelClThread()\0"
    "setBLineCLBt(QString)\0setResClB(const vecLines*)\0"
    "setResClBW(const vecLines*)\0"
    "createNormCLThread()\0setNLineCLBt(QString)\0"
    "setResClNW(const vecLines*)\0"
    "setResClN(const vecLines*)\0"
    "setModelClRes(const vecLines*,int,int)\0"
    "setModelClResW(const vecLines*,int,int)\0"
    "setModelClNRes(const vecLines*,int,int)\0"
    "setModelClNResW(const vecLines*,int,int)\0"
    "countGroups\0calc_clasters(int)\0"
    "setLbLambdaCl(int)\0setListBLambdaCl(QModelIndex)\0"
    "deleteRowCl()\0resetLbLambdaCl()\0"
    "setModelClBtRun(QString)\0setModelClPrBRun(int)\0"
    "updateModelClSimple(int,int)\0"
    "updateModelClSimpleW(int,int)\0"
    "setCLStr(vecII)\0setCLBW(const vecLines*)\0"
    "setCLB(const vecLines*)\0"
    "setCLNW(const vecLines*)\0"
    "setCLN(const vecLines*)\0createDendrogramm()\0"
    "setDendroBt(QString)\0getDendrogramm()\0"
    "source\0setDendroClasters(TDenroGramm*)\0"
    "setCheckedGraphsCl(bool)\0"
    "finishedFuture(QString)\0about()\0"
    "drawLinesCalc()\0data,parent\0"
    "drawLines(vecF,QWidget*)\0pe\0"
    "paintEvent(QPaintEvent*)\0drawHotelling()\0"
    "setHotMon()\0_in\0setT2Hot(bool)\0"
    "setT2WHot(bool)\0drawMewma()\0setMEWMAMon()\0"
    "setME2check(bool)\0setME2Wcheck(bool)\0"
    "createDockWin()\0setLambdaCbCorr(bool)\0"
    "setLambdaCbCl(bool)\0action\0"
    "slotActivated(QAction*)\0"
};

void MainWin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWin *_t = static_cast<MainWin *>(_o);
        switch (_id) {
        case 0: _t->processNormChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->createWin(); break;
        case 2: _t->calc_begin(); break;
        case 3: { Node* _r = _t->InitTree();
            if (_a[0]) *reinterpret_cast< Node**>(_a[0]) = _r; }  break;
        case 4: { Node* _r = _t->InitTreeCl();
            if (_a[0]) *reinterpret_cast< Node**>(_a[0]) = _r; }  break;
        case 5: { NodeModel* _r = _t->InitTreeModelling();
            if (_a[0]) *reinterpret_cast< NodeModel**>(_a[0]) = _r; }  break;
        case 6: { NodeModel* _r = _t->InitTreeModellingCl();
            if (_a[0]) *reinterpret_cast< NodeModel**>(_a[0]) = _r; }  break;
        case 7: { bool _r = _t->openFile();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 8: { bool _r = _t->openFileForMonH();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: { bool _r = _t->openFileForMonW();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 10: _t->groupChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 11: _t->groupClChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 12: _t->groupModChanged((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 13: { bool _r = _t->openFileFor();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 14: { bool _r = _t->saveFile();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 15: _t->createButsThread(); break;
        case 16: _t->createNormThread(); break;
        case 17: _t->setButsBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 18: _t->setNormBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->setDirForButs(); break;
        case 20: _t->setDirForNorm(); break;
        case 21: _t->createRegreCorr((*reinterpret_cast< QWidget*(*)>(_a[1]))); break;
        case 22: _t->createMGKCorr((*reinterpret_cast< QWidget*(*)>(_a[1]))); break;
        case 23: _t->createDialogFWidget((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 24: _t->createDialogFreeFWidget((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 25: _t->createDialogFactorsWidget((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 26: _t->acceptChanges(); break;
        case 27: _t->createResression(); break;
        case 28: _t->clearResression(); break;
        case 29: _t->deleteChangesRegre(); break;
        case 30: _t->deleteItem((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 31: _t->createButsCorrThread(); break;
        case 32: _t->createModelThread(); break;
        case 33: _t->setBLineCorrBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 34: _t->setModelBtRun((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 35: _t->setModelPrBRun((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 36: _t->createNormCorrThread(); break;
        case 37: _t->setNLineCorrBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 38: _t->calc_groups(); break;
        case 39: _t->setCorrStr((*reinterpret_cast< vecII(*)>(_a[1]))); break;
        case 40: _t->setCorrBW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 41: _t->setResCorrB((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 42: _t->setResCorrBW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 43: _t->setCorrB((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 44: _t->setModelRes((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 45: _t->setModelResW((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 46: _t->setModelNRes((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 47: _t->setModelNResW((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 48: _t->setCorrNW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 49: _t->setCorrN((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 50: _t->setResCorrNW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 51: _t->setResCorrN((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 52: _t->setLbLambda((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 53: _t->setListBLambda((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 54: _t->deleteRow(); break;
        case 55: _t->resetLbLambda(); break;
        case 56: _t->updateCorrLS(); break;
        case 57: _t->updateModelSimple((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 58: _t->updateModelSimpleW((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 59: _t->updateClLS(); break;
        case 60: _t->setCheckedGraphs((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 61: _t->showTime(); break;
        case 62: { QString _r = _t->getCurrentTime();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 63: _t->setListState((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 64: _t->createButsCLThread(); break;
        case 65: _t->createModelClThread(); break;
        case 66: _t->setBLineCLBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 67: _t->setResClB((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 68: _t->setResClBW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 69: _t->createNormCLThread(); break;
        case 70: _t->setNLineCLBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 71: _t->setResClNW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 72: _t->setResClN((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 73: _t->setModelClRes((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 74: _t->setModelClResW((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 75: _t->setModelClNRes((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 76: _t->setModelClNResW((*reinterpret_cast< const vecLines*(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 77: _t->calc_clasters((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 78: _t->setLbLambdaCl((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 79: _t->setListBLambdaCl((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 80: _t->deleteRowCl(); break;
        case 81: _t->resetLbLambdaCl(); break;
        case 82: _t->setModelClBtRun((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 83: _t->setModelClPrBRun((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 84: _t->updateModelClSimple((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 85: _t->updateModelClSimpleW((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 86: _t->setCLStr((*reinterpret_cast< vecII(*)>(_a[1]))); break;
        case 87: _t->setCLBW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 88: _t->setCLB((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 89: _t->setCLNW((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 90: _t->setCLN((*reinterpret_cast< const vecLines*(*)>(_a[1]))); break;
        case 91: _t->createDendrogramm(); break;
        case 92: _t->setDendroBt((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 93: _t->getDendrogramm(); break;
        case 94: _t->setDendroClasters((*reinterpret_cast< TDenroGramm*(*)>(_a[1]))); break;
        case 95: _t->setCheckedGraphsCl((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 96: _t->finishedFuture((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 97: _t->about(); break;
        case 98: _t->drawLinesCalc(); break;
        case 99: _t->drawLines((*reinterpret_cast< const vecF(*)>(_a[1])),(*reinterpret_cast< QWidget*(*)>(_a[2]))); break;
        case 100: _t->paintEvent((*reinterpret_cast< QPaintEvent*(*)>(_a[1]))); break;
        case 101: _t->drawHotelling(); break;
        case 102: _t->setHotMon(); break;
        case 103: _t->setT2Hot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 104: _t->setT2WHot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 105: _t->drawMewma(); break;
        case 106: _t->setMEWMAMon(); break;
        case 107: _t->setME2check((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 108: _t->setME2Wcheck((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 109: _t->createDockWin(); break;
        case 110: _t->setLambdaCbCorr((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 111: _t->setLambdaCbCl((*reinterpret_cast< const bool(*)>(_a[1]))); break;
        case 112: _t->slotActivated((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWin::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWin::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWin,
      qt_meta_data_MainWin, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWin::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWin::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWin))
        return static_cast<void*>(const_cast< MainWin*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 113)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 113;
    }
    return _id;
}

// SIGNAL 0
void MainWin::processNormChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
