#include<QtGui>
#include "mainUnit.h"
#include "mainwin.h"


int main(int arg, char** arc)
{
    QApplication app(arg, arc);

    QTextCodec *codec = QTextCodec::codecForName("CP1251");
    QTextCodec::setCodecForTr(codec);


    QTranslator qtTranslator;
    qtTranslator.load("tranlations/qt_ru");
    app.installTranslator(&qtTranslator);

    MainWin myw;
    myw.show();

    return app.exec();
}
