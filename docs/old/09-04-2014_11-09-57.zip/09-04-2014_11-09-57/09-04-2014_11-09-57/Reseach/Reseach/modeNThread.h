#ifndef MODECORRNTHREAD_H
#define MODECORRNTHREAD_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"
#include "linesvariables.h"

class modellingNThread : public QThread
{
    Q_OBJECT

    int p, n, m, nn, iterCount, beginView, idThread, idGroup;
    vecFF data;
    vecI group;
    vecF sigma;
    QString nameWorkDirF, currenTime;
    float alyfa;

    ExternVariables *Vars;
    vecLines *LinesW, *Lines;

    QMutex mutex;

    volatile bool flag;

    QWaitCondition cond;

    void run();
    void calcLines(const vecFF &in_data, const int &iter, const int &mode);

public:

    explicit modellingNThread(ExternVariables *Vars_, int &countGroup, int &countIter);
    ~modellingNThread();

signals:

    void processChanged(int iter);
    void processSetTextBt(const QString &str);
    void processRanged(int minn, int maxx);
    void finishedThread(const QString &str);

    void getLines(const vecLines *out_vec, const int& idGroup, const int& idThread);
    void getLinesW(const vecLines *out_vec, const int& idGroup, const int& idThread);

public slots:

    void setFlag(){QMutexLocker locker(&mutex); flag = true;}

};

#endif // MODECORRNTHREAD_H
