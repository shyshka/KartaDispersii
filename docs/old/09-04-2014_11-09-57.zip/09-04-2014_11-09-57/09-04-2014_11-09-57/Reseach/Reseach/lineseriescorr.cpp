#include "lineseriescorr.h"
#include "linesvariables.h"
#include "mathstat.cpp"

#define tr QObject::tr

LineSeriesCorr::LineSeriesCorr(ExternVariables *Vars_) : QThread()
{
    mutex.lock();

    p = Vars_->getFileCountVars();
    n = Vars_->getFileCountStepV();
    m = Vars_->getFileCountView();
    nn = n * m;
    iterBCount = Vars_->getFileCountButStr();

    data = _create(p, nn);
    data = Vars_->getData();

    //delta = Vars_->getDelta();

    //����� ����� ���������� - correlation
    groups = Vars_->getGroups();

    //����� ����� ���������� - ��������
    sigma = Vars_->getListVar();

    //����� ������� - ������ ��������
    beginView = Vars_->getView();

    //�������� �������� ������ ����������
    alyfa = Vars_->getAlyfa();

    intensity = (qreal)Vars_->getIntensity();

    currenTime = Vars_->getCurTime();

    nameWorkDirF = Vars_->getDirForSamples();

    listTimes.clear();
    //listProbilities.clear();

    modeChanged = Vars_->getModeChanged();

    regression.clear();
    regression = Vars_->getRegression();

    flag = false;
    forDelta = Vars_->getForDelta();

    Lines = new LineSeries; Lines->resizeData(groups.count(), iterBCount);
    LinesW = new LineSeries; LinesW->resizeData(groups.count(), iterBCount);

    mutex.unlock();

    emit processRanged(0, iterBCount);
}

LineSeriesCorr::~LineSeriesCorr()
{
    mutex.lock();
    nameWorkDirF = "";currenTime = "";
    data.clear();groups.clear();sigma.clear();//deltaMean.clear();
    listTimes.clear();regression.clear();//listProbilities.clear();
    delete LinesW; delete Lines;
    p = __null;  n = __null;  m = __null;  nn = __null; iterBCount = __null;
    beginView = __null; intensity = __null; modeChanged = __null;
    alyfa = __null;
    flag = __null;
    cond.wakeAll();
    mutex.unlock();
    wait();
}

void LineSeriesCorr::run()
{
    emit processSetTextBt(tr("���������� ����������"));

    QString temp =  nameWorkDirF;

    QDir directory(temp);

    directory.setPath(temp + tr("/Hotelling") + tr("/")+ currenTime);
    if (!directory.exists())
       directory.mkpath(temp + tr("/Hotelling") + tr("/")+ currenTime);

    directory.setPath(temp + tr("/Mewma") + tr("/")+ currenTime);
    if (!directory.exists())
       directory.mkpath(temp + tr("/Mewma") + tr("/")+ currenTime);

    int i = __null, iter = __null;

    Lines->Line_SeriesHResult.resize(groups.count());
    LinesW->Line_SeriesHResult.resize(groups.count());
    Lines->Line_SeriesWResult.resize(groups.count());
    LinesW->Line_SeriesWResult.resize(groups.count());

    vecFF remains;
    if (modeChanged == 2)
        remains = __getData_Regre(regression, data);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    //try
    {
        for (i = 0; i < groups.count(); i++)
            if (groups[i].count() > 0)
            {
                mutex.lock();
                if (modeChanged == 0)
                {
                    LinesW->Line_SeriesH[i] = _lines_Series_W(data, groups[i], n, beginView, 0, alyfa);
                    Lines->Line_SeriesH[i] = _lines_Series(data, groups[i], n, beginView, 0, alyfa);
                    LinesW->Line_SeriesW[i] = _lines_Series_W(data, groups[i], n, beginView, 1, alyfa);
                    Lines->Line_SeriesW[i] = _lines_Series(data, groups[i], n, beginView, 1, alyfa);
                }
                if (modeChanged == 1)
                {
                    LinesW->Line_SeriesH[i] = _lines_Series_W(data, groups[i], n, beginView, 0, alyfa);
                    Lines->Line_SeriesH[i] = _lines_Series(data, groups[i], n, beginView, 0, alyfa);
                    LinesW->Line_SeriesW[i] = _lines_Series_W(data, groups[i], n, beginView, 1, alyfa);
                    Lines->Line_SeriesW[i] = _lines_Series(data, groups[i], n, beginView, 1, alyfa);
                }
                if (modeChanged == 2)
                {
                    LinesW->Line_SeriesH[i] = _lines_Series_W(remains, groups[i], n, beginView, 0, alyfa);
                    Lines->Line_SeriesH[i] = _lines_Series(remains, groups[i], n, beginView, 0, alyfa);
                    LinesW->Line_SeriesW[i] = _lines_Series_W(remains, groups[i], n, beginView, 1, alyfa);
                    Lines->Line_SeriesW[i] = _lines_Series(remains, groups[i], n, beginView, 1, alyfa);
                }
                mutex.unlock();

                Lines->Line_SeriesHArray[i].resize(iterBCount);
                Lines->Line_SeriesWArray[i].resize(iterBCount);
                LinesW->Line_SeriesHArray[i].resize(iterBCount);
                LinesW->Line_SeriesWArray[i].resize(iterBCount);
            }

        for (iter = 0; iter < iterBCount; iter++)
        {
            if (flag)
            {
                emit processChanged(0);
                emit processSetTextBt(tr("������ ����������� ������� ���� ����� ��� �������� ���������"));
                emit finishedThread(tr("������. �� ������ ��������������� ������� ���������� �������� - ������� : ") + QString(tr("%1").arg(iter)));
                break;
            }

            QString str_file = temp + tr("/X0/") + QString(tr("b00%1.txt")).arg(iter + 1);
            mutex.lock();
            vecFF in_data = _create(p, nn);
            mutex.unlock();

            QFile file(str_file);
            if ( file.open(QIODevice::ReadOnly | QIODevice::Text | QIODevice::Truncate) )
            {
                QTextStream in(&file);
                int var = __null;

                in >> var; if (var != p) {var = __null; in.reset(); file.close(); str_file = ""; break;}
                in >> var; if (var != n) {var = __null; in.reset(); file.close(); str_file = ""; break;}
                in >> var; if (var != m) {var = __null; in.reset(); file.close(); str_file = ""; break;}
                var = __null;

                float temp = __null;
                int k = __null, h = __null;

                for (k = 0; k < nn; k++)
                    for (h = 0; h < p; h++)
                    {
                        in >> temp;
                        in_data[h][k] = temp;
                        temp = __null;
                    }

                temp = __null;k = __null; h = __null;
                in.reset();
            }

            file.close();
            str_file = "";

            if (modeChanged == 0)
            {
                calcLines(temp, in_data, iter, 0, 0);
                calcLines(temp, in_data, iter, 0, 1);
                calcLines(temp, in_data, iter, 1, 0);
                calcLines(temp, in_data, iter, 1, 1);
            }
            if (modeChanged == 1)
            {
                calcLines(temp, in_data, iter, 0, 0);
                calcLines(temp, in_data, iter, 0, 1);
                calcLines(temp, in_data, iter, 1, 0);
                calcLines(temp, in_data, iter, 1, 1);
            }
            if (modeChanged == 2)
            {
                calcLinesR(temp, in_data, iter, 0, 0);
                calcLinesR(temp, in_data, iter, 0, 1);
                calcLinesR(temp, in_data, iter, 1, 0);
                calcLinesR(temp, in_data, iter, 1, 1);
            }

            emit getLines(Lines);
            emit getLinesW(LinesW);

            emit processChanged(iter + 1);

            if (iter == (iterBCount - 1))
            {
                emit finishedThread(tr("��������� �������. ���������� �������� - ������� : ") + QString(tr("%1")).arg(iter + 1));
                emit getResLines(Lines);
                emit getResLinesW(LinesW);
            }
            in_data.clear();
        }
    }

    i = __null; iter = __null;

    directory.rmpath(temp + tr("/Hotelling") + tr("/")+ currenTime);
    directory.rmpath(temp + tr("/Mewma") + tr("/")+ currenTime);
    directory = __null;

    //emit processSetTextBt(tr("��������� ���������� ������� ���� ����� ��� �������� ���������"));
    emit terminate();
    exec();
}

void LineSeriesCorr::calcLines(const QString &str_in, const vecFF &in_data, const int &iter, const int &mode, const int &modeW)
{
    QString str_file = "";

    for (int i = 0; i < groups.count(); i++)    
        if (groups[i].count() > 0)
        {
            vecI listTime, listTimeCountVars;
            vecF listProbilities, sko, need_sigma, delta;
            vecFF need_data, corr;
            //TProbilityLines listLinesProbilities, listLinesProbilitiesW;
            int countTimes = 0;

            mutex.lock();
            need_data = _CopyNeedColsFromArray2D(in_data, groups[i]);
            corr = _correlation(need_data);
            sko = _sko(need_data);
            listTime = _createListTimes(groups[i].count(), m, intensity);
            countTimes = listTime.count();
            listTimeCountVars = _createListVarsCount(groups[i].count(), countTimes);
            listProbilities = _createListProbilities(listTime, intensity);
            mutex.unlock();

            float listLinesH = 0., listLinesHW = 0., listLinesW = 0., listLinesWW = 0.;

            int ii = 0;
            vecFF temp_need_data = need_data;
            float sumProbaH = 0., sumProbaHW = 0., sumProbaW = 0., sumProbaWW = 0.;
            int timesH = 0, timesHW = 0, timesW = 0, timesWW = 0;

            for (ii = 0; ii < countTimes; ii++)
            {
                int iii = 0;
                //������������� ������� �����-��������
                vecF list_delta;
                do
                {
                    mutex.lock();
                    int jj = 0, rand = qPow(2., (qreal)groups[i].count());
                    rand = qrand() % (rand);

                    //������� ���������� ������ �� ��������� ��������� � �������� ���
                    list_delta = _getDexToBin(rand, groups[i].count());
                    mutex.unlock();

                    iii = 0;
                    for (jj = 0; jj < list_delta.count(); jj++)
                        if (list_delta[jj] > 0.) iii++;
                    jj = __null; rand = __null;
                }
                //�������� ������� ��������� ���������� "1.0" ��������� ������������ ���������� ����������,
                //�� ������� ����� ����������� ��������
                while(iii != listTimeCountVars[ii]);
                iii = __null;

                //������ ������� ��������

                mutex.lock();
                delta = _getDeltaForLambda(list_delta, corr, sko);//���������!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                mutex.unlock();

                list_delta.clear();

                int iRow = __null, iCol = __null;
                for (iRow = 0; iRow < nn; iRow++)
                    for (iCol = 0; iCol < groups[i].count(); iCol++)
                    {
                        int numberRow = (listTime[ii] - 1) * n;
                        if (iRow > numberRow)  temp_need_data[iCol][iRow] += delta[iCol];
                        numberRow = __null;
                    }
                iRow = __null; iCol = __null;
                delta.clear();

                mutex.lock();

                if (mode == 0)
                {
                    if (modeW == 0)
                        listLinesH = _lines_Series_MON(in_data, temp_need_data, groups[i], n, listTime[ii], 0,  alyfa);
                    if (modeW == 1)
                        listLinesHW = _lines_Series_W_MON(in_data, temp_need_data, groups[i], n, listTime[ii], 0,  alyfa);
                }
                if (mode == 1)
                {
                    if (modeW == 0)
                        listLinesW = _lines_Series_MON(in_data, temp_need_data, groups[i], n, listTime[ii], 1,  alyfa);
                    if (modeW == 1)
                        listLinesWW = _lines_Series_W_MON(in_data, temp_need_data, groups[i], n, listTime[ii], 1,  alyfa);
                }
                mutex.unlock();

                sumProbaH += listProbilities[ii];
                sumProbaHW += listProbilities[ii];
                sumProbaW += listProbilities[ii];
                sumProbaWW += listProbilities[ii];

                if (ii == (countTimes - 1) )
                {
                    if (mode == 0)
                    {
                        if (modeW == 0)
                            //Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * (timesH + listLinesH));
                        Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * listLinesH);
                        if (modeW == 1)
                            //LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * (timesHW + listLinesHW));
                        LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * listLinesHW);
                    }
                    if (mode == 1)
                    {
                        if (modeW == 0)
                            //Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * (timesW + listLinesW));
                        Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * listLinesW);
                        if (modeW == 1)
                            //LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * (timesWW + listLinesWW));
                        LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * listLinesWW);
                    }
                }
                else
                {
                    if (mode == 0)
                    {
                        if (modeW == 0)
                        {
                            if ( (listLinesH + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * (timesH + listLinesH));
                                Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * listLinesH);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaH = 0.;
                                //timesH = 0;
                            }
                            //else timesH += (listTime[ii + 1] - listTime[ii]);
                        }
                        if (modeW == 1)
                        {
                            if ( (listLinesHW + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * (timesHW + listLinesHW));
                                LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * listLinesHW);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaHW = 0.;
                                //timesHW = 0;
                            }
                            //else                                timesHW += (listTime[ii + 1] - listTime[ii]);
                        }
                    }
                    if (mode == 1)
                    {
                        if (modeW == 0)
                        {
                            if ( (listLinesW + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * (timesW + listLinesW));
                                Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * listLinesW);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaW = 0.;
                                //timesW = 0;
                            }
                            //else                                timesW += (listTime[ii + 1] - listTime[ii]);
                        }
                        if (modeW == 1)
                        {
                            if ( (listLinesWW + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * (timesWW + listLinesWW));
                                LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * listLinesWW);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaWW = 0.;
                                //timesWW = 0;
                            }
                            //else                                timesWW += (listTime[ii + 1] - listTime[ii]);
                        }
                    }                    
                }
                listLinesWW = __null;listLinesW = __null;
                listLinesH = __null;listLinesHW = __null;
            }


            temp_need_data.clear();
            sumProbaH = __null; sumProbaHW = __null; sumProbaW = __null; sumProbaWW = __null;
            timesH = __null; timesHW = __null; timesW = __null; timesWW = __null;

            if (mode == 0)
            {
                if (modeW == 0)
                {
                    Lines->Line_SeriesHResult[i] += Lines->Line_SeriesHArray[i][iter];
                    if (iter == (iterBCount - 1))
                        Lines->Line_SeriesHResult[i] /= iterBCount;
                }
                if (modeW == 1)
                {
                    LinesW->Line_SeriesHResult[i] += LinesW->Line_SeriesHArray[i][iter];
                    if (iter == (iterBCount - 1))
                        LinesW->Line_SeriesHResult[i] /= iterBCount;
                }
            }

            if (mode == 1)
            {
                if (modeW == 0)
                {
                    Lines->Line_SeriesWResult[i] += Lines->Line_SeriesWArray[i][iter];
                    if (iter == (iterBCount - 1))
                        Lines->Line_SeriesWResult[i] /= iterBCount;
                }
                if (modeW == 1)
                {
                    LinesW->Line_SeriesWResult[i] += LinesW->Line_SeriesWArray[i][iter];
                    if (iter == (iterBCount - 1))
                        LinesW->Line_SeriesWResult[i] /= iterBCount;
                }
            }

            sko.clear(); corr.clear();  need_sigma.clear();
            need_data.clear(); listTime.clear(); listTimeCountVars.clear();
            countTimes = __null;
        }


    if (mode == 0)
    {
        if (modeW == 0)
        {
            str_file = str_in + tr("/Hotelling/") + currenTime + ("/Bootstr Lines_Series.txt");
            saveLines(str_file, Lines, iter, mode);
        }
        if (modeW == 1)
        {
            str_file = str_in + tr("/Hotelling/") + currenTime + ("/Bootstr Lines_Series_W.txt");
            saveLines(str_file, LinesW, iter, mode);
        }
    }
    if (mode == 1)
    {
        if (modeW == 0)
        {
            str_file = str_in + tr("/Mewma/") + currenTime + ("/Bootstr Lines_Series.txt");
            saveLines(str_file, Lines, iter, mode);
        }
        if (modeW == 1)
        {
            str_file = str_in + tr("/Mewma/") + currenTime + ("/Bootstr Lines_Series_W.txt");
            saveLines(str_file, LinesW, iter, mode);
        }
    }

    str_file = "";//deltaMean.clear();
}

void LineSeriesCorr::calcLinesR(const QString &str_in, const vecFF &in_data, const int &iter, const int &mode, const int &modeW)
{
    QString str_file = "";

    for (int i = 0; i < groups.count(); i++)
        if (groups[i].count() > 0)
        {
            vecI listTime, listTimeCountVars;
            vecF listProbilities, sko, need_sigma, delta;
            vecFF need_data, corr, remains;
            int countTimes = 0;

            mutex.lock();
            need_data = in_data;
            corr = _correlation(need_data);
            sko = _sko(need_data);
            listTime = _createListTimes(need_data.count(), m, intensity);
            countTimes = listTime.count();
            listTimeCountVars = _createListVarsCount(need_data.count(), countTimes);
            listProbilities = _createListProbilities(listTime, intensity);
            remains = __getData_Regre(regression, need_data);
            mutex.unlock();

            float listLinesH = 0., listLinesHW = 0., listLinesW = 0., listLinesWW = 0.;

            int ii = 0;
            vecFF temp_need_data = need_data;
            vecFF temp_remains = remains;
            float sumProbaH = 0., sumProbaHW = 0., sumProbaW = 0., sumProbaWW = 0.;
            int timesH = 0, timesHW = 0, timesW = 0, timesWW = 0;

            for (ii = 0; ii < countTimes; ii++)
            {
                int iii = 0;
                //������������� ������� �����-��������
                vecF list_delta;
                do
                {
                    mutex.lock();
                    int jj = 0, rand = qPow(2., (qreal)need_data.count());
                    rand = qrand() % (rand);

                    //������� ���������� ������ �� ��������� ��������� � �������� ���
                    list_delta = _getDexToBin(rand, need_data.count());
                    mutex.unlock();

                    iii = 0;
                    for (jj = 0; jj < list_delta.count(); jj++)
                        if (list_delta[jj] > 0.) iii++;
                    jj = __null; rand = __null;
                }
                //�������� ������� ��������� ���������� "1.0" ��������� ������������ ���������� ����������,
                //�� ������� ����� ����������� ��������
                while(iii != listTimeCountVars[ii]);
                iii = __null;

                //������ ������� ��������

                mutex.lock();
                delta = _getDeltaForLambda(list_delta, corr, sko);//���������!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                mutex.unlock();

                list_delta.clear();

                int iRow = __null, iCol = __null;
                for (iRow = 0; iRow < nn; iRow++)
                    for (iCol = 0; iCol < need_data.count(); iCol++)
                    {
                        int numberRow = (listTime[ii] - 1) * n;
                        if (iRow > numberRow)  temp_need_data[iCol][iRow] += delta[iCol];
                        numberRow = __null;
                    }
                iRow = __null; iCol = __null;
                delta.clear();


                mutex.lock();
                temp_remains = __getData_Regre(regression, temp_need_data);
                if (mode == 0)
                {
                    if (modeW == 0)
                        listLinesH = _lines_Series_MON(remains, temp_remains, groups[i], n, listTime[ii], 0,  alyfa);
                    if (modeW == 1)
                        listLinesHW = _lines_Series_W_MON(remains, temp_remains, groups[i], n, listTime[ii], 0,  alyfa);
                }
                if (mode == 1)
                {
                    if (modeW == 0)
                        listLinesW = _lines_Series_MON(remains, temp_remains, groups[i], n, listTime[ii], 1,  alyfa);
                    if (modeW == 1)
                        listLinesWW = _lines_Series_W_MON(remains, temp_remains, groups[i], n, listTime[ii], 1,  alyfa);
                }
                mutex.unlock();

                sumProbaH += listProbilities[ii];
                sumProbaHW += listProbilities[ii];
                sumProbaW += listProbilities[ii];
                sumProbaWW += listProbilities[ii];

                if (ii == (countTimes - 1) )
                {
                    if (mode == 0)
                    {
                        if (modeW == 0)
                            //Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * (timesH + listLinesH));
                        Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * listLinesH);
                        if (modeW == 1)
                            //LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * (timesHW + listLinesHW));
                        LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * listLinesHW);
                    }
                    if (mode == 1)
                    {
                        if (modeW == 0)
                            //Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * (timesW + listLinesW));
                        Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * listLinesW);
                        if (modeW == 1)
                            //LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * (timesWW + listLinesWW));
                        LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * listLinesWW);
                    }
                }
                else
                {
                    if (mode == 0)
                    {
                        if (modeW == 0)
                        {
                            if ( (listLinesH + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * (timesH + listLinesH));
                                Lines->Line_SeriesHArray[i][iter] += (int)(sumProbaH * listLinesH);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaH = 0.;
                                //timesH = 0;
                            }
                            //else timesH += (listTime[ii + 1] - listTime[ii]);
                        }
                        if (modeW == 1)
                        {
                            if ( (listLinesHW + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * (timesHW + listLinesHW));
                                LinesW->Line_SeriesHArray[i][iter] += (int)(sumProbaHW * listLinesHW);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaHW = 0.;
                                //timesHW = 0;
                            }
                            //else                                timesHW += (listTime[ii + 1] - listTime[ii]);
                        }
                    }
                    if (mode == 1)
                    {
                        if (modeW == 0)
                        {
                            if ( (listLinesW + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * (timesW + listLinesW));
                                Lines->Line_SeriesWArray[i][iter] += (int)(sumProbaW * listLinesW);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaW = 0.;
                                //timesW = 0;
                            }
                            //else                                timesW += (listTime[ii + 1] - listTime[ii]);
                        }
                        if (modeW == 1)
                        {
                            if ( (listLinesWW + listTime[ii]) <= listTime[ii + 1] )
                            {
                                //LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * (timesWW + listLinesWW));
                                LinesW->Line_SeriesWArray[i][iter] += (int)(sumProbaWW * listLinesWW);
                                temp_need_data.clear();
                                temp_need_data = need_data;
                                sumProbaWW = 0.;
                                //timesWW = 0;
                            }
                            //else                                timesWW += (listTime[ii + 1] - listTime[ii]);
                        }
                    }
                }
                listLinesWW = __null;listLinesW = __null;
                listLinesH = __null;listLinesHW = __null;
            }


            temp_need_data.clear(); temp_remains.clear();
            sumProbaH = __null; sumProbaHW = __null; sumProbaW = __null; sumProbaWW = __null;
            timesH = __null; timesHW = __null; timesW = __null; timesWW = __null;

            if (mode == 0)
            {
                if (modeW == 0)
                {
                    Lines->Line_SeriesHResult[i] += Lines->Line_SeriesHArray[i][iter];
                    if (iter == (iterBCount - 1))
                        Lines->Line_SeriesHResult[i] /= iterBCount;
                }
                if (modeW == 1)
                {
                    LinesW->Line_SeriesHResult[i] += LinesW->Line_SeriesHArray[i][iter];
                    if (iter == (iterBCount - 1))
                        LinesW->Line_SeriesHResult[i] /= iterBCount;
                }
            }

            if (mode == 1)
            {
                if (modeW == 0)
                {
                    Lines->Line_SeriesWResult[i] += Lines->Line_SeriesWArray[i][iter];
                    if (iter == (iterBCount - 1))
                        Lines->Line_SeriesWResult[i] /= iterBCount;
                }
                if (modeW == 1)
                {
                    LinesW->Line_SeriesWResult[i] += LinesW->Line_SeriesWArray[i][iter];
                    if (iter == (iterBCount - 1))
                        LinesW->Line_SeriesWResult[i] /= iterBCount;
                }
            }

            sko.clear(); corr.clear();  need_sigma.clear();
            need_data.clear(); listTime.clear(); listTimeCountVars.clear();
            countTimes = __null;
        }


    if (mode == 0)
    {
        if (modeW == 0)
        {
            str_file = str_in + tr("/Hotelling/") + currenTime + ("/Bootstr Lines_Series.txt");
            saveLines(str_file, Lines, iter, mode);
        }
        if (modeW == 1)
        {
            str_file = str_in + tr("/Hotelling/") + currenTime + ("/Bootstr Lines_Series_W.txt");
            saveLines(str_file, LinesW, iter, mode);
        }
    }
    if (mode == 1)
    {
        if (modeW == 0)
        {
            str_file = str_in + tr("/Mewma/") + currenTime + ("/Bootstr Lines_Series.txt");
            saveLines(str_file, Lines, iter, mode);
        }
        if (modeW == 1)
        {
            str_file = str_in + tr("/Mewma/") + currenTime + ("/Bootstr Lines_Series_W.txt");
            saveLines(str_file, LinesW, iter, mode);
        }
    }

    str_file = "";//deltaMean.clear();
}

void LineSeriesCorr::saveLines(const QString &str_in, vecLines *Lines, const int &iter, const int &mode)
{
    QFile file(str_in);

    if (mode == 0)
    {
        if ( file.open(QIODevice::Append | QIODevice::Text ) )
        {
            QTextStream outLh(&file);
            outLh.setFieldWidth(5);
            outLh.setRealNumberPrecision(5);
            outLh.setFieldAlignment(QTextStream::AlignRight);
            outLh.setRealNumberNotation(QTextStream::FixedNotation);

            if (iter == 0)
                outLh << "N\t" << "r>0.75\t" << "r>0.5\t" << "ALL\n";

            for (int i = 0; i < groups.count(); i++)
            {
                if (i == 0) outLh << QString("%1\t").arg(iter + 1);
                if (Lines->Line_SeriesHArray[i][iter] >= 0) outLh << QString("%1\t").arg(Lines->Line_SeriesHArray[i][iter]);
                else outLh << "" << "\t";
            }
            outLh << "\n";
            if (iter == (iterBCount - 1))
            {
                outLh << "Means of ALL series:\n";
                for (int i = 0; i < groups.count(); i++)
                    outLh << QString("\t%1").arg(Lines->Line_SeriesHResult[i]);
            }
            outLh.reset();
        }
        file.close();
    }
    if (mode == 1)
    {
        if ( file.open(QIODevice::Append | QIODevice::Text ) )
        {
            QTextStream outL(&file);
            outL.setFieldWidth(5);
            outL.setRealNumberPrecision(5);
            outL.setFieldAlignment(QTextStream::AlignRight);
            outL.setRealNumberNotation(QTextStream::FixedNotation);

            if (iter == 0)
                outL << "N\t" << "r>0.75\t" << "r>0.5\t" << "ALL\n";

            for (int i = 0; i < groups.count(); i++)
            {
                if (i == 0) outL << QString("%1\t").arg(iter + 1);
                if (Lines->Line_SeriesWArray[i][iter] >= 0) outL << QString("%1\t").arg(Lines->Line_SeriesWArray[i][iter]);
                else outL << "" << "\t";
            }
            outL << "\n";
            if (iter == (iterBCount - 1))
            {
                outL << "\tMeans of ALL series:\n";
                for (int i = 0; i < groups.count(); i++)
                    outL << QString("\t%1").arg(Lines->Line_SeriesWResult[i]);
            }
            outL.reset();
        }
        file.close();
    }
}
