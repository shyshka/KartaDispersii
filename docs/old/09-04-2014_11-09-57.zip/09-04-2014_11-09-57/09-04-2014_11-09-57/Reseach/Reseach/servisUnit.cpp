#include "servisUnit.h"
#include "mathstat.cpp"

#include <QtGui>


Node::Node(Node *parentNode,
           const QString& s1,
           const QString& s2,
           const QString& s3,
           const QString& s4,
           const QString& s5,
           NodeType nt )
    : str1(s1), str2(s2), str3(s3), str4(s4), str5(s5),
      nodeType(nt), parent(parentNode) {}

Node::~Node(){
    qDeleteAll(children);
}

NodeModel::NodeModel(NodeModel *parentNode,
           const QString& s1,
           const QString& s2,
           const QString& s3,
           const QString& s4,
           const QString& s5,
           const QString& s6,
           NodeType nt )
    : str1(s1), str2(s2), str3(s3), str4(s4), str5(s5), str6(s6),
      nodeType(nt), parent(parentNode) {}

NodeModel::~NodeModel(){
    qDeleteAll(children);
}

TreeModel::TreeModel(QObject *parent)
         : QAbstractItemModel(parent){
    rootNode = 0;
}

TreeModel::~TreeModel(){
    delete rootNode;
}

QModelIndex TreeModel::index(int row, int column,
                             const QModelIndex& parent) const {
    if (rootNode) {
        Node *parentNode = nodeFromIndex(parent);
        if (parentNode)
            return createIndex(row, column,
                               parentNode->children[row]);
    }
    return QModelIndex();
}

bool TreeModel::hasChildren(const QModelIndex& parent) const {
    Node *parentNode = nodeFromIndex(parent);
    if (!parentNode) return false;
    else return (parentNode->children.count() > 0);
}

QModelIndex TreeModel::parent(const QModelIndex& index) const {
    Node *node = nodeFromIndex(index);
    if (!node)
        return QModelIndex();

    Node *parentNode = node->parent;
    if (!parentNode)
        return QModelIndex();

    Node *grandparentNode = parentNode->parent;
    if (!grandparentNode)
        return QModelIndex();

    int row = grandparentNode->children.indexOf(parentNode);
    return createIndex(row, index.column(), parentNode);
}

int TreeModel::rowCount(const QModelIndex& index) const {
    Node *node = nodeFromIndex(index);
    if ( node )
        return node->children.count();
    else
        return 0;
}

int TreeModel::columnCount(const QModelIndex& /* index */ ) const {
    return 5;
}

QVariant TreeModel::data(const QModelIndex& index, int role) const {
    int col = index.column();
    Node *node = nodeFromIndex(index);
    switch (role) {
        case Qt::DisplayRole: // ������ ��� �����������
        case Qt::EditRole: {   // ������ ��� ��������������
            if (!node) return QVariant();
            else if (col == 0) return node->str1;
            else if (col == 1) return node->str2;
            else if (col == 2) return node->str3;
            else if (col == 3) return node->str4;
            else if (col == 4) return node->str5;
            else if (col == 5) return node->nodeType;
            //else if (col == 4) return node->parent;
            else return QVariant();
        }
        case Qt::TextColorRole: // ���� ������
            return qVariantFromValue(QColor(0, 0, 0));

        case Qt::TextAlignmentRole: // ������������
            if (node->children.count() > 0)
                if (col == 0)
                    return int(Qt::AlignLeft | Qt::AlignVCenter);
                else if (col == 1)
                    return int(Qt::AlignLeft | Qt::AlignVCenter);
                else if (col == 2)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 3)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 4)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else
                    return QVariant();
            else
                if (col == 0)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 1)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 2)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 3)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 4)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else
                    return QVariant();

        case Qt::FontRole: { // �����            
            if (node->children.count() > 0)
                return qVariantFromValue(QFont("Arial",
                                         10, QFont::Bold));
            else
                return qVariantFromValue(QFont("Helvetica", 9, QFont::Bold));
        }
        case Qt::BackgroundColorRole:  { // ���� ����
            /*if (node->children.count() > 0)
                return qVariantFromValue(QColor(200, 230, 240));
            else*/
                return qVariantFromValue(QColor(255, 255, 255));
        }
        case Qt::CheckStateRole:  // �������
            return QVariant();

        case Qt::SizeHintRole:  // ������ ������
            return QSize(150, 18);

        case Qt::DecorationRole: { // ������
            if (col == 0 && node->children.count() > 0)
                return ip.icon(QFileIconProvider::Folder);
            else
                return QVariant();
        }
    }
    return QVariant();
}

void TreeModel::setRootNode(Node *node){
    delete rootNode;
    rootNode = node;
    reset();
}

Node* TreeModel::nodeFromIndex(const QModelIndex& index) const {
    if (index.isValid()) {
        return static_cast<Node*>(index.internalPointer());
    }else{
        return rootNode;
    }
}

Qt::ItemFlags TreeModel::flags(const QModelIndex& index) const {
    if ( index.isValid() )
        return Qt::ItemIsEnabled | Qt::ItemIsEditable |
               Qt::ItemIsSelectable;
               // | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled;
    else
        return 0; //Qt::ItemIsDropEnabled;
}

QVariant TreeModel::headerData(int section,
                               Qt::Orientation orientation,
                               int role) const {
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole) {
        if (section == 0)
            return tr("�����");
        else if (section == 1)
            return tr("������ ������� �������������� ���������");
        else if (section == 2)
            return tr("������� ����� �����");
        else if (section == 3)
            return tr("������� ������� �������������� ���������");
        else if (section == 4)
            return tr("�������� ���������������");
    }
    return QVariant();
}

bool TreeModel::setData(const QModelIndex& index,
                        const QVariant& value, int role){
    if ( role != Qt::EditRole )
        return false;

    int col = index.column();
    Node *node = nodeFromIndex(index);
    if (col == 0)
        node->str1 = value.toString();
    else if (col == 1)
        node->str2 = value.toString();
    else if (col == 2)
        node->str3 = value.toString();
    else if (col == 3)
        node->str4 = value.toString();
    else if (col == 4)
        node->str5 = value.toString();

    return true;
}

//--------------------------------------------
TreeModelling::TreeModelling(QObject *parent)
         : QAbstractItemModel(parent){
    rootNodeMod = 0;
}

TreeModelling::~TreeModelling(){
    delete rootNodeMod;

}

QModelIndex TreeModelling::index(int row, int column,
                             const QModelIndex& parent) const {
    if (rootNodeMod) {
        NodeModel *parentNode = nodeFromIndex(parent);
        if (parentNode)
            return createIndex(row, column,
                               parentNode->children[row]);
    }
    return QModelIndex();
}

bool TreeModelling::hasChildren(const QModelIndex& parent) const {
    NodeModel *parentNode = nodeFromIndex(parent);
    if (!parentNode) return false;
    else return (parentNode->children.count() > 0);
}

QModelIndex TreeModelling::parent(const QModelIndex& index) const {
    NodeModel *node = nodeFromIndex(index);
    if (!node)
        return QModelIndex();

    NodeModel *parentNode = node->parent;
    if (!parentNode)
        return QModelIndex();

    NodeModel *grandparentNode = parentNode->parent;
    if (!grandparentNode)
        return QModelIndex();

    int row = grandparentNode->children.indexOf(parentNode);
    return createIndex(row, index.column(), parentNode);
}

int TreeModelling::rowCount(const QModelIndex& index) const {
    NodeModel *node = nodeFromIndex(index);
    if ( node )
        return node->children.count();
    else
        return 0;
}

int TreeModelling::columnCount(const QModelIndex& /* index */ ) const {
    return 6;
}

QVariant TreeModelling::data(const QModelIndex& index, int role) const {
    int col = index.column();
    NodeModel *node = nodeFromIndex(index);
    switch (role) {
        case Qt::DisplayRole: // ������ ��� �����������
        case Qt::EditRole: {   // ������ ��� ��������������
            if (!node) return QVariant();
            else if (col == 0) return node->str1;
            else if (col == 1) return node->str2;
            else if (col == 2) return node->str3;
            else if (col == 3) return node->str4;
            else if (col == 4) return node->str5;
            else if (col == 5) return node->str6;
            else if (col == 6) return node->nodeType;
            //else if (col == 4) return node->parent;
            else return QVariant();
        }
        case Qt::TextColorRole: // ���� ������
            return qVariantFromValue(QColor(0, 0, 0));

        case Qt::TextAlignmentRole: // ������������
            if (node->children.count() > 0)
                if (col == 0)
                    return int(Qt::AlignLeft | Qt::AlignVCenter);
                else if (col == 1)
                    return int(Qt::AlignLeft | Qt::AlignVCenter);
                else if (col == 2)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 3)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 4)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 5)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else
                    return QVariant();
            else
                if (col == 0)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 1)
                    return int(Qt::AlignRight | Qt::AlignVCenter);
                else if (col == 2)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 3)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 4)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else if (col == 5)
                    return int(Qt::AlignCenter | Qt::AlignVCenter);
                else
                    return QVariant();

        case Qt::FontRole: { // �����

            if (node->children.count() > 0)
                return qVariantFromValue(QFont("Helvetica", 10, QFont::Bold));
            else
                return qVariantFromValue(QFont("Arial", 9, QFont::Bold));
        }
        case Qt::BackgroundColorRole:  { // ���� ����
            if (node->children.count() > 0)
                return qVariantFromValue(QColor(235, 235, 235));
            else  return ((index.row() + 1) % 2 == 0)
                ? qVariantFromValue(QColor(245, 245, 245))
                        : qVariantFromValue(QColor(255, 255, 255));

        }
        case Qt::CheckStateRole:  // �������
            return QVariant();

        case Qt::SizeHintRole:  // ������ ������
            return QSize(150, 18);

        case Qt::DecorationRole: { // ������
            if (col == 0 && node->children.count() > 0)
                return ip.icon(QFileIconProvider::Folder);
            else
                return QVariant();
        }
    }    
    return QVariant();
}

void TreeModelling::setRootNode(NodeModel *node){
    delete rootNodeMod;
    rootNodeMod = node;
    reset();
}

NodeModel* TreeModelling::nodeFromIndex(const QModelIndex& index) const {
    if (index.isValid()) {
        return static_cast<NodeModel*>(index.internalPointer());
    }else{
        return rootNodeMod;
    }
}

Qt::ItemFlags TreeModelling::flags(const QModelIndex& index) const {
    if ( index.isValid() )
        return Qt::ItemIsEnabled | //Qt::ItemIsEditable |
               Qt::ItemIsSelectable;
               // | Qt::ItemIsDragEnabled | Qt::ItemIsDropEnabled;
    else
        return 0; //Qt::ItemIsDropEnabled;
}

QVariant TreeModelling::headerData(int section,
                               Qt::Orientation orientation,
                               int role) const {
    if (orientation == Qt::Horizontal && role == Qt::DisplayRole) {
        if (section == 0)
            return tr("�����");
        else if (section == 1)
            return tr("������������");
        else if (section == 2)
            return tr("������� ����� �����");
        else if (section == 3)
            return tr("������������� �������� ���");
        else if (section == 4)
            return tr("�������� ���������������");
        else if (section == 5)
            return tr("������ �������� (� �����)");
    }
    return QVariant();
}

bool TreeModelling::setData(const QModelIndex& index,
                        const QVariant& value, int role){
    if ( role != Qt::EditRole )
        return false;

    int col = index.column();
    NodeModel *node = nodeFromIndex(index);
    if (col == 0)
        node->str1 = value.toString();
    else if (col == 1)
        node->str2 = value.toString();
    else if (col == 2)
        node->str3 = value.toString();
    else if (col == 3)
        node->str4 = value.toString();
    else if (col == 4)
        node->str5 = value.toString();
    else if (col == 5)
        node->str6 = value.toString();

    return true;
}



//--------------------------------------------
MyTableView::MyTableView(QWidget *parent) : QTableView(parent)
{
    deleteRow = new QAction(this->style()->standardIcon(QStyle::SP_DialogCancelButton), tr("&������� ���������� ������"), this);
    menu = __null;
}

MyTableView::~MyTableView()
{
    _delete(menu);
    _delete(deleteRow);
}

void MyTableView::mousePressEvent(QMouseEvent *event)
{
    QRect rect(0, 0, this->width(), this->height());
    if (event->button() == Qt::RightButton)
        if (rect.contains(event->pos()))
        {
            _delete(menu);menu = new QMenu;
            menu->addAction(deleteRow);
            connect(menu, SIGNAL(triggered(QAction*)), this, SLOT(slotActivated(QAction*)));
        }
}

//--------------------------------------------------------------------
ListModel::ListModel(QObject *parent, const QString &name)
            : QAbstractListModel(parent)
{

    nameModel = name;
    nameModel = "";
}

ListModel::~ListModel()
{
    m_records.clear();
}

int ListModel::rowCount(const QModelIndex& parent) const
{
    if ( parent.isValid() || (m_records.count() == 0) )
        return 0;
    else
        return m_records.count();
}

QVariant ListModel::headerData(     int             section,
                                    Qt::Orientation orientation,
                                    int             role
                                ) const
{
    if (!m_records.count() || role != Qt::DisplayRole)
        return QVariant();

    return (orientation == Qt::Horizontal) ? QString("X%L1").arg(++section)
                                            :QString(this->nameModel);
}

Qt::ItemFlags ListModel::flags(const QModelIndex &index) const
{
    Qt::ItemFlags flags = QAbstractListModel::flags(index);
    return (index.isValid() || !m_records.count()) ? (flags | Qt::ItemIsEditable):
            flags;
}

QVariant ListModel::data(const QModelIndex&  index,
                            int                 role
                            ) const
{
    if (!index.isValid())
    {
        return QVariant();
    }

    return (role == Qt::DisplayRole || role == Qt::EditRole)
            ? m_records[index.row()]
            : QVariant();

}

bool ListModel::setData(     const QModelIndex& index,
                                const QVariant& value,
                                int                role
                                )
{
    if (index.isValid() && (role == Qt::EditRole || role == Qt::DisplayRole))
    {
        m_records[index.row()] = value.toFloat();
        emit dataChanged(index, index);
        return true;
    }

    return false;

}

void ListModel::toModel_vecF(vecF array)
{
    m_records.clear();

    nn = array.size();

    m_records.resize(nn);

    for (int j = 0; j < nn; j++)
        m_records[j] = array[j];
}


//------------------------------------------
TableModel::TableModel(QObject *parent, const QString &name)
            : QAbstractTableModel(parent)
{
    nameModel = name;
    p = 0; n = 0; m = 0; nn = 0; in_nn = 0;
}

TableModel::~TableModel()
{
    m_records.clear();
    this->nameModel = "";
    p = __null; n = __null; m = __null; nn = __null; in_nn = __null;
}

int TableModel::rowCount(const QModelIndex& parent) const
{
    return ( parent.isValid() || m_records.size() ) ? m_records.size() - 1 : 0;
}

int TableModel::columnCount(const QModelIndex& /* parent */ ) const
{
    return (m_records.size()) ? m_records[0].size() : 0;
}

QVariant TableModel::headerData( int section,
                                 Qt::Orientation orientation,
                                 int role) const
{
    if (!m_records.size())
        return QVariant();

    if (role == Qt::DisplayRole)
    {
        if (nameModel == "Load" || nameModel == "Normirovka")
            switch(orientation)
            {
                case Qt::Horizontal : return QString("X%L1").arg(++section);
                case Qt::Vertical   : return ++section;
            }
        if (nameModel == "MO SKO")
            switch(orientation)
            {
                case Qt::Horizontal : return QString("X%L1").arg(++section);
                case Qt::Vertical   : switch (section)
                                       {
                                           case 0 : return QString("MO");
                                           case 1 : return QString("SKO");
                                       }
            }
        if (nameModel == "Correlations" || nameModel == "Covariations" || nameModel == "Cholesky" || nameModel == "Inverse")
            switch(orientation)
            {
                case Qt::Horizontal : return QString("X%L1").arg(++section);
                case Qt::Vertical   : return QString("X%L1").arg(++section);
            }
    }
    return QAbstractTableModel::headerData(
        section, orientation, role);
}

Qt::ItemFlags TableModel::flags(const QModelIndex &index) const
{
    if (!index.isValid() || !m_records.size())
        return 0;
    return QAbstractTableModel::flags(index) | Qt::ItemIsEditable;
}

QVariant TableModel::data( const QModelIndex &index,
                         int role) const {

    if (!index.isValid() || !m_records.size())
        return QVariant();

    vecF record = m_records[index.row()];

    switch (role)
    {
        case Qt::SizeHintRole :             // ������ ������
            return QSize(20, 15);
        case Qt::DisplayRole:               // ������ ��� �����������
        //    return record[index.column()];



        case Qt::EditRole :                 // ������ ��� ��������������
            return record[index.column()];

        case Qt::TextAlignmentRole:         // ������������
                return int(Qt::AlignCenter);

        case Qt::FontRole:                  // �����
            if (nameModel == "Correlations")
            {
                float value = record[index.column()];
                if ((_Corr_Signification(value, in_nn))&&(index.row() != index.column()))
                    return qVariantFromValue(QFont("Arial", 9, QFont::Bold));
                else
                    return qVariantFromValue(QFont("Arial", 9, QFont::Normal));
            }
            else
                return qVariantFromValue(QColor(0, 0, 0));
            //return qVariantFromValue(
            //        QFont("Arial", 9, QFont::Normal));


        case Qt::ToolTipRole :              // ���������
            {
                QString tip, key, keyr;

                tip = "<table>";

                key = headerData(index.column(), Qt::Horizontal, Qt::DisplayRole).toString();
                keyr = headerData(index.row(), Qt::Vertical, Qt::DisplayRole).toString();
                float value = record[index.column()];

                tip += QString("<tr><td><b>( %1, %2 ) = %L3</b></td></tr>").arg(key).arg(keyr).arg(value);

                tip += "</table>";
                return tip;
            }

        //case Qt::CheckStateRole:          // �������
        //    return QVariant();

        case Qt::BackgroundColorRole:       // ���� ����
            return (m_records.size() && ((index.row() + 1) % 2 == 0)) ?
                    qVariantFromValue(QColor(240, 240, 240))
                                : qVariantFromValue(QColor(255, 255, 255));

        case Qt::TextColorRole:             // ���� ������
        //return (index.row() == 1 && index.column() == 2) ? qVariantFromValue(QColor(255, 0, 0))
        //                         : qVariantFromValue(QColor(0, 0, 0));
        {
            if (nameModel == "Correlations")
            {
                float value = record[index.column()];
                if ((_Corr_Signification(value, in_nn))&&(index.row() != index.column()))
                    return qVariantFromValue(QColor(255, 0, 0));
                else
                    return qVariantFromValue(QColor(0, 0, 0));
            }
            else
                return qVariantFromValue(QColor(0, 0, 0));
        }



        //case Qt::DecorationRole:            // ������
        //    return ip.icon(QFileIconProvider::Folder);

    }

    record.clear();

    return QVariant();
}

bool TableModel::hasChildren(const QModelIndex& parent ) const
{
    return !parent.isValid();
}

bool TableModel::setData(
            const QModelIndex &index,
            const QVariant &value,
            int role)
{

    if (index.isValid() &&
       (role == Qt::EditRole || role == Qt::DisplayRole))
    {
        m_records[index.row()][index.column()] = value.toFloat();
        emit dataChanged(index, index);
        return true;
    }
    return false;
}

bool TableModel::insertRows( int row, int count,                //  ���������!
                             const QModelIndex& parent)
{
    Q_UNUSED(parent);
    vecF emptyRecord;
    emptyRecord.resize(columnCount(QModelIndex()));

    beginInsertRows(QModelIndex(), row, row + count);
    for (int i = 0; i < count; i++)
        m_records.insert(row + 1, emptyRecord);

    endInsertRows();
    return true;
}

bool TableModel::removeRows( int row, int count,                //  ���������!
                           const QModelIndex& parent)
{
    Q_UNUSED(parent);
    if (row + count > m_records.size())
        return false;

    //int colCount = m_records[0].count();

    beginRemoveRows(QModelIndex(), row, row + count);

    for(int i = 0; i < count; i++)
        //for(int j = 0; i < colCount; i++)
            //m_records[row + 1].remove(j);
        m_records.remove(row + 1);

    endRemoveRows();
    return true;
}

bool TableModel::loadData(const QString& fileName)
{
    QFile file(fileName);
    if ( !file.open(QIODevice::ReadOnly|QIODevice::Text) )
        return false;

    m_records.clear();
    QTextStream in(&file);
    in.setCodec("CP1251");

    in >> p >> n >> m;
    nn = n * m;

    m_records = _create(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
        {
            float x;
            in >> x;

            m_records[j][i] = x;
        }

    file.close();
    reset();
    return in.status() == QTextStream::Ok;
}

bool TableModel::saveData(const bool mode, const QString& fileName)
{
    QFile file(fileName);
    if ( !file.open(QIODevice::WriteOnly |
                    QIODevice::Text |
                    QIODevice::Truncate) )
        return false;

    QTextStream out(&file);

    //���������� !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    if (mode)
        out << this->p << "\n" << this->n << "\n" << this->m << "\n";

    for (int j = 0; j < nn; j++)
    {
        out << m_records[j][0];

        for (int i = 1; i < p; i++)
            out << "\t" << m_records[j][i] ;

        out << "\n";
    }

    file.close();
    return out.status() == QTextStream::Ok;
}

vecFF TableModel::toArray()
{
    vecFF result = _create(p, nn);
    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
             result[i][j] = m_records[j][i] ;

    return result;
}

void TableModel::toModel(const vecFF &array, int viborka, const int &nn_)
{
    m_records.clear();

    p = array.count();
    nn = array[0].count();
    in_nn = nn_;
    n = viborka;
    m = nn / n;

    m_records = _create(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
            m_records[j][i] = array[i][j];
}


//------------------------------------------
LinesSeriesModel::LinesSeriesModel(QObject *parent, const QString &name)
            : QAbstractTableModel(parent)
{
    nameModel = name;
    p = 0; n = 0; m = 0; nn = 0;
}

LinesSeriesModel::~LinesSeriesModel()
{
    m_records.clear();
    this->nameModel = "";
    p = __null; n = __null; m = __null; nn = __null;
}

int LinesSeriesModel::rowCount(const QModelIndex& parent) const
{
    return ( parent.isValid() || m_records.size() ) ? m_records.size() - 1 : 0;
}

int LinesSeriesModel::columnCount(const QModelIndex& /* parent */ ) const
{
    return (m_records.size()) ? m_records[0].size() : 0;
}

QVariant LinesSeriesModel::headerData( int section,
                                 Qt::Orientation orientation,
                                 int role) const
{
    if (!m_records.size())
        return QVariant();

    if (role == Qt::DisplayRole)
    {
        if (nameModel == "Lines")
            switch(orientation)
            {
                case Qt::Horizontal : switch (section)
                                      {
                                        case 0 : return QString(tr("���������"));
                                        case 1 : return QString("L0");
                                        case 2 : return QString("HOTELLING");
                                        case 3 : return QString("L0");
                                        case 4 : return QString("MEWMA");
                                      }
                case Qt::Vertical   : return ++section;
            }
    }
    return QAbstractTableModel::headerData(
        section, orientation, role);
}

Qt::ItemFlags LinesSeriesModel::flags(const QModelIndex &index) const
{
    if (!index.isValid() || !m_records.size())
        return 0;
    return QAbstractTableModel::flags(index) | Qt::ItemIsEditable;
}

QVariant LinesSeriesModel::data( const QModelIndex &index,
                         int role) const {

    if (!index.isValid() || !m_records.size())
        return QVariant();

    vecS record = m_records[index.row()];

    switch (role)
    {
        case Qt::SizeHintRole :             // ������ ������
            return QSize(20, 15);
        case Qt::DisplayRole:               // ������ ��� �����������
        //    return record[index.column()];



        case Qt::EditRole :                 // ������ ��� ��������������
            return record[index.column()];

        case Qt::TextAlignmentRole:         // ������������
                return int(Qt::AlignCenter);

        case Qt::FontRole:                  // �����
            if (nameModel == "Lines")
                return qVariantFromValue(QFont("Arial", 9, QFont::Bold));
            else
                return qVariantFromValue(QFont("Arial", 9, QFont::Normal));

        case Qt::ToolTipRole :              // ���������
            {
                QString tip, key, keyr;

                tip = "<table>";

                key = headerData(index.column(), Qt::Horizontal, Qt::DisplayRole).toString();
                keyr = headerData(index.row(), Qt::Vertical, Qt::DisplayRole).toString();
                QString value = record[index.column()];

                tip += QString("<tr><td><b>( %1, %2 ) = %L3</b></td></tr>").arg(key).arg(keyr).arg(value);

                tip += "</table>";
                return tip;
            }

        //case Qt::CheckStateRole:          // �������
        //    return QVariant();

        case Qt::BackgroundColorRole:       // ���� ����
            return (m_records.size() && ((index.row() + 1) % 2 == 0))
                    ? qVariantFromValue(QColor(240, 240, 240))
                            : qVariantFromValue(QColor(255, 255, 255));

        case Qt::TextColorRole:             // ���� ������
            return qVariantFromValue(QColor(0, 0, 0));




        //case Qt::DecorationRole:            // ������
        //    return ip.icon(QFileIconProvider::Folder);

    }

    record.clear();

    return QVariant();
}

bool LinesSeriesModel::hasChildren(const QModelIndex& parent ) const
{
    return !parent.isValid();
}

bool LinesSeriesModel::setData(
            const QModelIndex & index,
            const QString& value,
            int role)
{

    if (index.isValid() &&
       (role == Qt::EditRole || role == Qt::DisplayRole))
    {
        m_records[index.row()][index.column()] = value;
        emit dataChanged(index, index);
        return true;
    }
    return false;
}

bool LinesSeriesModel::insertRows( int row, int count,                //  ���������!
                             const QModelIndex& parent)
{
    Q_UNUSED(parent);
    vecS emptyRecord;
    emptyRecord.resize(columnCount(QModelIndex()));

    beginInsertRows(QModelIndex(), row, row + count);
    for (int i = 0; i < count; i++)
        m_records.insert(row + 1, emptyRecord);

    endInsertRows();
    return true;
}

bool LinesSeriesModel::removeRows( int row, int count,                //  ���������!
                           const QModelIndex& parent)
{
    Q_UNUSED(parent);
    if (row + count > m_records.size())
        return false;

    //int colCount = m_records[0].count();

    beginRemoveRows(QModelIndex(), row, row + count);

    for(int i = 0; i < count; i++)
        //for(int j = 0; i < colCount; i++)
            //m_records[row + 1].remove(j);
        m_records.remove(row + 1);

    endRemoveRows();
    return true;
}
/*
bool LinesSeriesModel::loadData(const QString& fileName)
{
    QFile file(fileName);
    if ( !file.open(QIODevice::ReadOnly|QIODevice::Text) )
        return false;

    m_records.clear();
    QTextStream in(&file);
    in.setCodec("CP1251");

    in >> p >> n >> m;
    nn = n * m;

    m_records = _create(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
        {
            float x;
            in >> x;

            m_records[j][i] = x;
        }

    file.close();
    reset();
    return in.status() == QTextStream::Ok;
}

bool LinesSeriesModel::saveData(const bool mode, const QString& fileName)
{
    QFile file(fileName);
    if ( !file.open(QIODevice::WriteOnly |
                    QIODevice::Text |
                    QIODevice::Truncate) )
        return false;

    QTextStream out(&file);

    //���������� !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    if (mode)
        out << this->p << "\n" << this->n << "\n" << this->m << "\n";

    for (int j = 0; j < nn; j++)
    {
        out << m_records[j][0];

        for (int i = 1; i < p; i++)
            out << "\t" << m_records[j][i] ;

        out << "\n";
    }

    file.close();
    return out.status() == QTextStream::Ok;
}

vecSS LinesSeriesModel::toArray()
{
    vecSS result = _createS(p, nn);
    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
             result[i][j] = m_records[j][i] ;

    return result;
}
*/
void LinesSeriesModel::toModel(const vecSS &array)
{
    m_records.clear();

    p = array.count();
    nn = array[0].count();
    n = 1;
    m = nn / n;

    m_records = _createS(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
            m_records[j][i] = array[i][j];
}

//------------------------------------------
LinesResultsModel::LinesResultsModel(QObject *parent, const QString &name)
            : QAbstractTableModel(parent)
{
    nameModel = name;
    p = 0; n = 0; m = 0; nn = 0;
}

LinesResultsModel::~LinesResultsModel()
{
    m_records.clear();
    this->nameModel = "";
    p = __null; n = __null; m = __null; nn = __null;
}

int LinesResultsModel::rowCount(const QModelIndex& parent) const
{
    return ( parent.isValid() || m_records.size() ) ? m_records.size() - 1 : 0;
}

int LinesResultsModel::columnCount(const QModelIndex& /* parent */ ) const
{
    return (m_records.size()) ? m_records[0].size() : 0;
}

QVariant LinesResultsModel::headerData( int section,
                                 Qt::Orientation orientation,
                                 int role) const
{
    if (!m_records.size())
        return QVariant();

    if (role == Qt::DisplayRole)
    {
        if (nameModel == "LinesResults")
            switch(orientation)
            {
                case Qt::Horizontal : switch (section)
                                      {
                                        case 0 : return QString(tr("���������"));
                                        case 1 : return QString(tr("������ ������"));
                                        case 2 : return QString(tr("HOTELLING"));
                                        case 3 : return QString(tr("������� ������"));
                                        case 4 : return QString(tr("������ ������"));
                                        case 5 : return QString(tr("MEWMA"));
                                        case 6 : return QString(tr("������� ������"));
                                      }
                case Qt::Vertical   : return ++section;
            }
    }
    return QAbstractTableModel::headerData(
        section, orientation, role);
}

Qt::ItemFlags LinesResultsModel::flags(const QModelIndex &index) const
{
    if (!index.isValid() || !m_records.size())
        return 0;
    return QAbstractTableModel::flags(index) | Qt::ItemIsEditable;
}

QVariant LinesResultsModel::data( const QModelIndex &index,
                         int role) const {

    if (!index.isValid() || !m_records.size())
        return QVariant();

    vecS record = m_records[index.row()];

    switch (role)
    {
        case Qt::SizeHintRole :             // ������ ������
            return QSize(20, 15);
        case Qt::DisplayRole:               // ������ ��� �����������
        //    return record[index.column()];



        case Qt::EditRole :                 // ������ ��� ��������������
            return record[index.column()];

        case Qt::TextAlignmentRole:         // ������������
                return int(Qt::AlignCenter);

        case Qt::FontRole:                  // �����
            if (nameModel == "LinesResults")
                return qVariantFromValue(QFont("Arial", 9, QFont::Bold));
            else
                return qVariantFromValue(QFont("Arial", 9, QFont::Normal));

        case Qt::ToolTipRole :              // ���������
            {
                QString tip, key, keyr;

                tip = "<table>";

                key = headerData(index.column(), Qt::Horizontal, Qt::DisplayRole).toString();
                keyr = headerData(index.row(), Qt::Vertical, Qt::DisplayRole).toString();
                QString value = record[index.column()];

                tip += QString("<tr><td><b>( %1, %2 ) = %L3</b></td></tr>").arg(key).arg(keyr).arg(value);

                tip += "</table>";
                return tip;
            }

        //case Qt::CheckStateRole:          // �������
        //    return QVariant();

        case Qt::BackgroundColorRole:       // ���� ����
            return (m_records.size() && ((index.row() + 1) % 2 == 0))
                    ? qVariantFromValue(QColor(240, 240, 240))
                            : qVariantFromValue(QColor(255, 255, 255));

        case Qt::TextColorRole:             // ���� ������
            return qVariantFromValue(QColor(0, 0, 0));




        //case Qt::DecorationRole:            // ������
        //    return ip.icon(QFileIconProvider::Folder);

    }

    record.clear();

    return QVariant();
}

bool LinesResultsModel::hasChildren(const QModelIndex& parent ) const
{
    return !parent.isValid();
}

bool LinesResultsModel::setData(
            const QModelIndex & index,
            const QString& value,
            int role)
{

    if (index.isValid() &&
       (role == Qt::EditRole || role == Qt::DisplayRole))
    {
        m_records[index.row()][index.column()] = value;
        emit dataChanged(index, index);
        return true;
    }
    return false;
}

bool LinesResultsModel::insertRows( int row, int count,                //  ���������!
                             const QModelIndex& parent)
{
    Q_UNUSED(parent);
    vecS emptyRecord;
    emptyRecord.resize(columnCount(QModelIndex()));

    beginInsertRows(QModelIndex(), row, row + count);
    for (int i = 0; i < count; i++)
        m_records.insert(row + 1, emptyRecord);

    endInsertRows();
    return true;
}

bool LinesResultsModel::removeRows( int row, int count,                //  ���������!
                           const QModelIndex& parent)
{
    Q_UNUSED(parent);
    if (row + count > m_records.size())
        return false;

    //int colCount = m_records[0].count();

    beginRemoveRows(QModelIndex(), row, row + count);

    for(int i = 0; i < count; i++)
        //for(int j = 0; i < colCount; i++)
            //m_records[row + 1].remove(j);
        m_records.remove(row + 1);

    endRemoveRows();
    return true;
}

void LinesResultsModel::toModel(const vecSS &array)
{
    m_records.clear();

    p = array.count();
    nn = array[0].count();
    n = 1;
    m = nn / n;

    m_records = _createS(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
            m_records[j][i] = array[i][j];
}


//------------------------------------------

//------------------------------------------
ListChangedModel::ListChangedModel(QObject *parent, const QString &name)
            : QAbstractTableModel(parent)
{
    nameModel = name;
    p = 0; n = 0; m = 0; nn = 0;
}

ListChangedModel::~ListChangedModel()
{
    m_records.clear();
    this->nameModel = "";
    p = __null; n = __null; m = __null; nn = __null;
}

int ListChangedModel::rowCount(const QModelIndex& parent) const
{
    return ( parent.isValid() || m_records.size() ) ? m_records.size() - 1 : 0;
}

int ListChangedModel::columnCount(const QModelIndex& /* parent */ ) const
{
    return (m_records.size()) ? m_records[0].size() : 0;
}

QVariant ListChangedModel::headerData( int section,
                                 Qt::Orientation orientation,
                                 int role) const
{
    if (!m_records.size())
        return QVariant();

    if (role == Qt::DisplayRole)
    {
        if (nameModel == "ListChanged")
            switch(orientation)
            {
                case Qt::Horizontal : switch (section)
                                      {
                                        case 0 : return QString(tr("���������"));
                                        case 1 : return QString(tr("��������"));
                                      }
                case Qt::Vertical   : return ++section;
            }
        if (nameModel == "ListLambda")
            switch(orientation)
            {
                case Qt::Horizontal : switch (section)
                                      {
                                        case 0 : return QString(tr("���������"));
                                        case 1 : return QString(tr("�������� ���������������"));
                                      }
                case Qt::Vertical   : return ++section;
            }
    }
    return QAbstractTableModel::headerData(
        section, orientation, role);
}

Qt::ItemFlags ListChangedModel::flags(const QModelIndex &index) const
{
    if (!index.isValid() || !m_records.size())
        return 0;
    return QAbstractTableModel::flags(index) | Qt::ItemIsEditable;
}

QVariant ListChangedModel::data( const QModelIndex &index,
                         int role) const {

    if (!index.isValid() || !m_records.size())
        return QVariant();

    vecS record = m_records[index.row()];

    switch (role)
    {
        case Qt::SizeHintRole :             // ������ ������
            return QSize(20, 15);
        case Qt::DisplayRole:               // ������ ��� �����������
        //    return record[index.column()];



        case Qt::EditRole :                 // ������ ��� ��������������
            return record[index.column()];

        case Qt::TextAlignmentRole:         // ������������
                return int(Qt::AlignCenter);

        case Qt::FontRole:                  // �����
            if ( (nameModel == "ListChanged") || (nameModel == "ListLambda") )
                return qVariantFromValue(QFont("Arial", 9, QFont::Bold));
            else
                return qVariantFromValue(QFont("Arial", 9, QFont::Normal));

        case Qt::ToolTipRole :              // ���������
            {
                QString tip, key, keyr;

                tip = "<table>";

                key = headerData(index.column(), Qt::Horizontal, Qt::DisplayRole).toString();
                keyr = headerData(index.row(), Qt::Vertical, Qt::DisplayRole).toString();
                QString value = record[index.column()];

                tip += QString("<tr><td><b>( %1, %2 ) = %L3</b></td></tr>").arg(key).arg(keyr).arg(value);

                tip += "</table>";
                return tip;
            }

        //case Qt::CheckStateRole:          // �������
        //    return QVariant();

        case Qt::BackgroundColorRole:       // ���� ����
            return (m_records.size() && ((index.row() + 1) % 2 == 0))
                    ? qVariantFromValue(QColor(240, 240, 240))
                            : qVariantFromValue(QColor(255, 255, 255));

        case Qt::TextColorRole:             // ���� ������
            return qVariantFromValue(QColor(0, 0, 0));




        //case Qt::DecorationRole:            // ������
        //    return ip.icon(QFileIconProvider::Folder);

    }

    record.clear();

    return QVariant();
}

bool ListChangedModel::hasChildren(const QModelIndex& parent ) const
{
    return !parent.isValid();
}

bool ListChangedModel::setData(
            const QModelIndex & index,
            const QVariant& value,
            int role)
{

    if (index.isValid() &&
       (role == Qt::EditRole || role == Qt::DisplayRole))
    {
        m_records[index.row()][index.column()] = value.toString();
        emit dataChanged(index, index);
        return true;
    }
    return false;
}

bool ListChangedModel::insertRows( int row, int count,                //  ���������!
                             const QModelIndex& parent)
{
    Q_UNUSED(parent);
    vecS emptyRecord;
    emptyRecord.resize(columnCount(QModelIndex()));

    beginInsertRows(QModelIndex(), row, row + count);
    for (int i = 0; i < count; i++)
        m_records.insert(row + 1, emptyRecord);

    endInsertRows();
    return true;
}

bool ListChangedModel::removeRows( int row, int count,                //  ���������!
                           const QModelIndex& parent)
{
    Q_UNUSED(parent);
    if (row + count > m_records.size())
        return false;

    //int colCount = m_records[0].count();

    beginRemoveRows(QModelIndex(), row, row + count);

    for(int i = 0; i < count; i++)
        //for(int j = 0; i < colCount; i++)
            //m_records[row + 1].remove(j);
        m_records.remove(row + 1);

    endRemoveRows();
    return true;
}
/*
bool LinesSeriesModel::loadData(const QString& fileName)
{
    QFile file(fileName);
    if ( !file.open(QIODevice::ReadOnly|QIODevice::Text) )
        return false;

    m_records.clear();
    QTextStream in(&file);
    in.setCodec("CP1251");

    in >> p >> n >> m;
    nn = n * m;

    m_records = _create(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
        {
            float x;
            in >> x;

            m_records[j][i] = x;
        }

    file.close();
    reset();
    return in.status() == QTextStream::Ok;
}

bool LinesSeriesModel::saveData(const bool mode, const QString& fileName)
{
    QFile file(fileName);
    if ( !file.open(QIODevice::WriteOnly |
                    QIODevice::Text |
                    QIODevice::Truncate) )
        return false;

    QTextStream out(&file);

    //���������� !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    if (mode)
        out << this->p << "\n" << this->n << "\n" << this->m << "\n";

    for (int j = 0; j < nn; j++)
    {
        out << m_records[j][0];

        for (int i = 1; i < p; i++)
            out << "\t" << m_records[j][i] ;

        out << "\n";
    }

    file.close();
    return out.status() == QTextStream::Ok;
}

vecSS LinesSeriesModel::toArray()
{
    vecSS result = _createS(p, nn);
    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
             result[i][j] = m_records[j][i] ;

    return result;
}
*/
void ListChangedModel::toModel(const vecSS &array)
{
    m_records.clear();

    p = array.count();
    nn = array[0].count();
    n = 1;
    m = nn / n;

    m_records = _createS(nn + 1, p);

    for (int j = 0; j < nn; j++)
        for (int i = 0; i < p; i++)
            m_records[j][i] = array[i][j];
}


//-----------------------------------------------------------
void ProjectListWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
            startPos = event->pos();
    QListWidget::mousePressEvent(event);
}

void ProjectListWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton)
    {
        int distance = (event->pos() - startPos).manhattanLength();
        if (distance >= QApplication::startDragDistance())
            startDrag();
    }
    QListWidget::mousePressEvent(event);
}

void ProjectListWidget::startDrag()
{
    QListWidgetItem *item = currentItem();

    if (item)
    {
        QMimeData *mimeData = new QMimeData;
        mimeData->setText(item->text());
        QDrag *drag = new QDrag(this);
        drag->setMimeData(mimeData);
        if (drag->start(Qt::MoveAction) == Qt::MoveAction)
        {
            emit itemMoved(item);
            delete item;
        }
    }
}

void ProjectListWidget::sorting()
{

}

void ProjectListWidget::dragEnterEvent(QDragEnterEvent *event)
{
    ProjectListWidget *source = qobject_cast<ProjectListWidget *>(event->source());
    //event->source()->o
    if (source && source != this)
    {
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }
}

void ProjectListWidget::dragMoveEvent(QDragMoveEvent *event)
{
    ProjectListWidget *source = qobject_cast<ProjectListWidget *>(event->source());
    if (source && source != this)
    {
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }
}

void ProjectListWidget::dropEvent(QDropEvent *event)
{
    ProjectListWidget *source = qobject_cast<ProjectListWidget *>(event->source());
    if (source && source != this)
    {
        addItem(event->mimeData()->text());
        emit itemDropped(event->mimeData()->text().remove('x').toInt());
        event->setDropAction(Qt::MoveAction);
        event->accept();
    }
}




