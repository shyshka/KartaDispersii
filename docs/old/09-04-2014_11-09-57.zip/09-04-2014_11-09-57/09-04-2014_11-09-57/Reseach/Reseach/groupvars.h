#ifndef GROUPVARS_H
#define GROUPVARS_H

#include <QThread>
#include <QWaitCondition>
#include "mathstat.h"
#include "externvariables.h"

class GroupVars : public QThread
{
    Q_OBJECT

    QWaitCondition cond;
    QMutex mutex;

    ExternVariables *Vars_;
    int p, n, m, nn, count, mode;
    vecII data, gr_data;
    vecFF in_data, corr_data;
    vecRegression regression;

    void run();

public:
    explicit GroupVars(ExternVariables *vars);
    ~GroupVars();

signals:

    void getData(vecII out);

public slots:

};

#endif // GROUPVARS_H
